# Sarfealam Auto-Studio

**Sarfealam Auto-Studio** is a mobile-first autonomous app & game studio designed around real secret-driven state, a dual-display assembly factory, dynamic AI team routing, call-style Live voice commands, dual Firebase separation, and real GitHub Actions Android APK pipelines (**Flutter** for apps, **Godot 4** for 3D/games).

> **Engineering Principle — Real over Fake**: Hollow demo shells with fake "Connected" badges, decorative skill toggles, and fabricated "APK Ready" checkmarks are explicitly unacceptable for this product. Every status strip item, System Map chip, skill toggle, and APK/Admin link in Sarfealam Auto-Studio reflects real persisted secrets, real job state, or an explicitly labeled **Local Blueprint Preview (Demo)** when API keys are missing.

---

## 1. Dual Firebase Architecture

Sarfealam Auto-Studio intentionally separates two distinct Firebase configurations inside **Secrets**:

1. **Studio Firebase (Section D)** — *Studio Records Only*
   - Stores Sarfealam Auto-Studio's own operational state: build jobs, Vault history, active stage index (Background Job Survivor), language preference (`en`/`hi`), and System Map status.
   - Syncs via REST (`/api/firebase/studio-sync`) while always backing up locally in `localStorage` so background jobs survive refresh or reopen.
2. **Apps Firebase (Section E)** — *Injected into Generated Apps*
   - Never used for studio metadata.
   - When you press **OK** to export a Stage 5 build (and the `Apps Firebase Inject` skill is ON), Sarfealam Auto-Studio injects your Apps Firebase config directly into:
     - **Flutter**: `lib/firebase_options.dart`
     - **Godot 4**: `scripts/apps_firebase_bridge.gd`
   - Published Android APKs therefore send end-user data strictly to your Apps Firebase server.

---

## 2. Dynamic System Map Agent Chips (Display B)

Display B does **not** freeze a hardcoded fake list of providers:
- With **0 API keys saved**, Display B shows muted department chips (`Brain AI`, `Code AI`, `Vision / QA`) with exact missing-secret reasons (`Missing General API key`, etc.).
- With **1 General API key**, that single key operates all departments cleanly (1-key mode) and appears as a named chip on Display B.
- When you add **more keys** (Gemini, Groq, Qwen, NVIDIA NIM, DeepSeek, OpenRouter, or custom OpenAI-compatible slots — including multiple slots sharing one NVIDIA NIM key for different models), **each saved key renders as its own dynamic named chip** showing its real name, provider/model, tags, active work caption, and fallback/critic status.

---

## 3. Live Call-Style Voice vs. Legacy Record-and-Wait Voice

Sarfealam Auto-Studio eliminates legacy WhatsApp-style *record → send → wait → TTS* flows:
- **Live is OFF by default.**
- Turning **Live ON** starts continuous call-style speech recognition (`SpeechRecognition` / `webkitSpeechRecognition`) in English (`en-US`) or Hindi (`hi-IN`) matching the global language toggle.
- Spoken commands drive the studio UI directly:
  - Build: *"Build a ride booking app with wallet"*, *"3D कार रेसिंग गेम बनाओ"*
  - Control: *"Cancel"*, *"OK"*, *"Home"*, *"Switch to Hindi"*, *"Switch to English"*
  - Navigate: *"Open Vault"*, *"Open Admin"*, *"Open Skills"*, *"Open Secrets"*, *"Status"*
- A secondary **Speak** button remains available on Co-Pilot replies without replacing Live mode.

---

## 4. Flutter vs. Godot 4 Engine Picker & GitHub Actions APK Export

The **Engine Picker** skill automatically routes:
- **Commercial / utility / booking / wallet / OTP apps** → **Flutter** (`pubspec.yaml`, `lib/main.dart`, `lib/firebase_options.dart`, `lib/admin_config.dart`, `.github/workflows/flutter-apk.yml`)
- **3D / racing / arcade / card-table games** → **Godot 4** (`project.godot`, `scenes/main.tscn`, `scripts/player_controller.gd`, `scripts/apps_firebase_bridge.gd`, `export_presets.cfg`, `.github/workflows/godot-android-apk.yml`)

### How Real APK & Admin Links Appear in Vault / Admin
1. Assemble your prompt on **Build** across Stages 1 → 5 (`Shell` → `Screens/World` → `Hero/Main UI` → `Controls/HUD` → `Ready to test`).
2. Test the interactive app tabs or playable game Steer/Gas/Brake controls on Display A.
3. Press **OK** (disabled until Stage 5 is reached).
4. If **Token1 (GitHub PAT)** is validated in **Secrets** (with `repo` and `workflow` scopes), Sarfealam Auto-Studio creates/updates the GitHub repository via `/api/github/export`, commits the full Flutter or Godot 4 project + workflow YAML, and triggers GitHub Actions.
5. **Vault** and **Admin** immediately publish the **Admin Final Link** and provide one-tap **Poll Actions APK** (`/api/github/poll`) so the real `.apk` GitHub Release / Artifact download URL appears directly inside Vault and Admin without hunting through GitHub.
6. If GitHub Token1 is missing, export honestly reports `blocked · missing GitHub Token1` and lets you download the complete Source + Workflow `.zip` package locally without faking an APK link.

---

## 5. Placing This Project on GitHub for Real Actions APK Builds

### Wrapping Sarfealam Auto-Studio (or any exported project) on GitHub
1. Initialize a GitHub repository and push this codebase (or click **OK** with a valid GitHub Token1 so the studio pushes generated Flutter/Godot 4 projects automatically):
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Sarfealam Auto-Studio"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. For generated **Flutter** repositories, `.github/workflows/flutter-apk.yml` automatically scaffolds Android if needed, runs `flutter build apk --release`, uploads the APK artifact, and publishes a GitHub Release with `app-release.apk`.
3. For generated **Godot 4** repositories, `.github/workflows/godot-android-apk.yml` uses `barichello/godot-ci:4.3` to run headless Android export and publish the `.apk` to Releases & Artifacts.
4. To wrap Sarfealam Auto-Studio's web UI itself into an Android APK later, run `npm run build` and package `dist/` with Capacitor (`npx cap add android`) or a Flutter `webview_flutter` wrapper pointing to your hosted URL.
