import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

interface ProviderKeyPayload {
  id: string;
  label: string;
  provider: string;
  apiKey: string;
  model: string;
  baseUrl?: string;
  tags: string[];
}

interface RouteAttempt {
  keyId: string;
  label: string;
  provider: string;
  model: string;
  ok: boolean;
  error?: string;
  statusCode?: number;
  latencyMs: number;
}

const PROVIDER_BASE_URLS: Record<string, string> = {
  groq: 'https://api.groq.com/openai/v1',
  nvidia: 'https://integrate.api.nvidia.com/v1',
  qwen: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
  openai: 'https://api.openai.com/v1',
  openrouter: 'https://openrouter.ai/api/v1',
  deepseek: 'https://api.deepseek.com/v1',
  mistral: 'https://api.mistral.ai/v1',
};

const DEFAULT_MODELS: Record<string, string> = {
  gemini: 'gemini-4-hydrogen',
  groq: 'llama-3.3-70b-versatile',
  nvidia: 'meta/llama-3.1-70b-instruct',
  qwen: 'qwen-plus',
  openai: 'gpt-4o-mini',
  openrouter: 'google/gemini-2.0-flash-001',
  deepseek: 'deepseek-chat',
  mistral: 'mistral-small-latest',
  custom: 'gpt-4o-mini',
};

function normalizeGeminiModel(model?: string): string {
  const raw = (model || '').trim();
  if (!raw) return 'gemini-4-hydrogen';
  const blocked = [
    'gemini-1.5-flash',
    'gemini-1.5-pro',
    'gemini-pro',
    'gemini-2.0-flash',
    'gemini-2.0-pro',
    'gemini-2.0-flash-thinking',
  ];
  if (blocked.includes(raw.toLowerCase())) {
    return 'gemini-4-hydrogen';
  }
  return raw;
}

async function callSingleProvider(
  keySlot: ProviderKeyPayload,
  prompt: string,
  systemInstruction?: string,
  history?: Array<{ role: 'user' | 'assistant'; text: string }>,
  jsonMode?: boolean
): Promise<{ text: string; model: string }> {
  const provider = (keySlot.provider || 'gemini').toLowerCase();
  const model =
    provider === 'gemini'
      ? normalizeGeminiModel(keySlot.model)
      : (keySlot.model || DEFAULT_MODELS[provider] || 'gpt-4o-mini').trim();

  if (provider === 'gemini') {
    const ai = new GoogleGenAI({
      apiKey: keySlot.apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const contentsParts: string[] = [];
    if (history && history.length > 0) {
      const recent = history.slice(-8);
      for (const h of recent) {
        contentsParts.push(`${h.role === 'user' ? 'User' : 'Co-Pilot'}: ${h.text}`);
      }
    }
    contentsParts.push(`User: ${prompt}`);

    const response = await ai.models.generateContent({
      model,
      contents: contentsParts.join('\n\n'),
      config: {
        ...(systemInstruction ? { systemInstruction } : {}),
        ...(jsonMode ? { responseMimeType: 'application/json' } : {}),
      },
    });

    const text = response.text?.trim();
    if (!text) {
      throw new Error('Empty response returned from Gemini API');
    }
    return { text, model };
  }

  // OpenAI-compatible providers (Groq, NVIDIA NIM, Qwen, OpenAI, OpenRouter, DeepSeek, Mistral, Custom)
  const baseUrl = (keySlot.baseUrl || PROVIDER_BASE_URLS[provider] || '').replace(/\/+$/, '');
  if (!baseUrl) {
    throw new Error(`Missing API base URL for provider "${keySlot.provider}"`);
  }

  const messages: Array<{ role: string; content: string }> = [];
  if (systemInstruction) {
    messages.push({ role: 'system', content: systemInstruction });
  }
  if (history && history.length > 0) {
    for (const h of history.slice(-8)) {
      messages.push({ role: h.role, content: h.text });
    }
  }
  messages.push({ role: 'user', content: prompt });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${keySlot.apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        ...(jsonMode ? { response_format: { type: 'json_object' } } : {}),
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const errBody = await res.text().catch(() => '');
      const snippet = errBody.slice(0, 220);
      const err = new Error(`HTTP ${res.status}: ${snippet || res.statusText}`) as Error & { statusCode?: number };
      err.statusCode = res.status;
      throw err;
    }

    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) {
      throw new Error('Empty completion text from provider');
    }
    return { text, model };
  } finally {
    clearTimeout(timeout);
  }
}

// 1) Multi-key AI routing with real fallback
app.post('/api/ai/route', async (req, res) => {
  const { prompt, systemInstruction, keys, history, jsonMode, allowFallback = true } = req.body as {
    prompt?: string;
    systemInstruction?: string;
    keys?: ProviderKeyPayload[];
    history?: Array<{ role: 'user' | 'assistant'; text: string }>;
    jsonMode?: boolean;
    allowFallback?: boolean;
  };

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ ok: false, code: 'BAD_REQUEST', error: 'Prompt is required.' });
  }

  const usableKeys = Array.isArray(keys) ? keys.filter((k) => k && k.apiKey && k.apiKey.trim().length > 0) : [];
  if (usableKeys.length === 0) {
    return res.status(200).json({
      ok: false,
      code: 'NO_KEYS',
      error: 'No API keys configured in Secrets.',
      attempts: [],
    });
  }

  const queue = allowFallback ? usableKeys : usableKeys.slice(0, 1);
  const attempts: RouteAttempt[] = [];

  for (let i = 0; i < queue.length; i++) {
    const slot = queue[i];
    const started = Date.now();
    try {
      const result = await callSingleProvider(slot, prompt, systemInstruction, history, jsonMode);
      const latencyMs = Date.now() - started;
      attempts.push({
        keyId: slot.id,
        label: slot.label,
        provider: slot.provider,
        model: result.model,
        ok: true,
        latencyMs,
      });

      return res.json({
        ok: true,
        text: result.text,
        usedKeyId: slot.id,
        usedKeyLabel: slot.label,
        usedProvider: slot.provider,
        usedModel: result.model,
        fallbackUsed: i > 0,
        attempts,
      });
    } catch (err: unknown) {
      const latencyMs = Date.now() - started;
      const e = err as Error & { status?: number; statusCode?: number };
      attempts.push({
        keyId: slot.id,
        label: slot.label,
        provider: slot.provider,
        model: slot.model || DEFAULT_MODELS[slot.provider] || 'unknown',
        ok: false,
        error: e.message || 'Provider request failed',
        statusCode: e.statusCode || e.status,
        latencyMs,
      });
    }
  }

  return res.json({
    ok: false,
    code: 'ALL_PROVIDERS_FAILED',
    error: attempts[attempts.length - 1]?.error || 'All configured API keys failed.',
    attempts,
  });
});

// 2) Test single API key slot
app.post('/api/ai/test-key', async (req, res) => {
  const { keySlot } = req.body as { keySlot?: ProviderKeyPayload };
  if (!keySlot || !keySlot.apiKey?.trim()) {
    return res.status(400).json({ ok: false, valid: false, error: 'API key value is empty.' });
  }
  const started = Date.now();
  try {
    const result = await callSingleProvider(
      keySlot,
      'Reply with exactly: OK',
      'Return only the word OK.'
    );
    return res.json({
      ok: true,
      valid: true,
      detectedModel: result.model,
      latencyMs: Date.now() - started,
      sample: result.text.slice(0, 40),
    });
  } catch (err: unknown) {
    const e = err as Error;
    return res.json({
      ok: false,
      valid: false,
      latencyMs: Date.now() - started,
      error: e.message || 'Validation failed',
    });
  }
});

// 3) Validate GitHub Token1
app.post('/api/github/validate', async (req, res) => {
  const { token } = req.body as { token?: string };
  if (!token || !token.trim()) {
    return res.json({ ok: false, valid: false, error: 'GitHub Token1 is empty.' });
  }

  try {
    const ghRes = await fetch('https://api.github.com/user', {
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Sarfealam-Auto-Studio',
      },
    });

    if (!ghRes.ok) {
      const txt = await ghRes.text().catch(() => '');
      return res.json({
        ok: false,
        valid: false,
        status: ghRes.status,
        error: `GitHub rejected token (${ghRes.status}): ${txt.slice(0, 140)}`,
      });
    }

    const user = (await ghRes.json()) as {
      login: string;
      name?: string;
      avatar_url?: string;
      html_url?: string;
    };
    const scopes = ghRes.headers.get('x-oauth-scopes') || 'fine-grained / classic';
    return res.json({
      ok: true,
      valid: true,
      username: user.login,
      name: user.name || user.login,
      avatarUrl: user.avatar_url,
      profileUrl: user.html_url,
      scopes,
    });
  } catch (err: unknown) {
    const e = err as Error;
    return res.json({ ok: false, valid: false, error: e.message || 'Network error contacting GitHub.' });
  }
});

// 4) Real GitHub repo create/update & file push (triggers GitHub Actions APK workflow)
app.post('/api/github/export', async (req, res) => {
  const { token, repoName, description, files, isPrivate = false } = req.body as {
    token?: string;
    repoName?: string;
    description?: string;
    files?: Record<string, string>;
    isPrivate?: boolean;
  };

  if (!token || !token.trim()) {
    return res.json({ ok: false, error: 'Missing GitHub Token1 in Secrets.' });
  }
  if (!repoName || !files || Object.keys(files).length === 0) {
    return res.json({ ok: false, error: 'Repository name and generated project files are required.' });
  }

  const cleanRepo = repoName
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'sarfealam-generated-app';

  const headers = {
    Authorization: `Bearer ${token.trim()}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'Sarfealam-Auto-Studio',
  };

  try {
    // 1. Identify user
    const userRes = await fetch('https://api.github.com/user', { headers });
    if (!userRes.ok) {
      return res.json({ ok: false, error: `GitHub auth failed (${userRes.status}). Check Token1.` });
    }
    const userData = (await userRes.json()) as { login: string };
    const owner = userData.login;

    // 2. Check or create repo
    let repoUrl = `https://github.com/${owner}/${cleanRepo}`;
    const checkRepoRes = await fetch(`https://api.github.com/repos/${owner}/${cleanRepo}`, { headers });
    if (checkRepoRes.status === 404) {
      const createRes = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: cleanRepo,
          description: description || 'Generated by Sarfealam Auto-Studio',
          private: isPrivate,
          auto_init: true,
        }),
      });
      if (!createRes.ok) {
        const errText = await createRes.text().catch(() => '');
        return res.json({
          ok: false,
          error: `Could not create repo "${cleanRepo}" (${createRes.status}). Ensure token has repo & workflow scopes. ${errText.slice(0, 140)}`,
        });
      }
      const created = (await createRes.json()) as { html_url: string };
      repoUrl = created.html_url;
      // Short pause for GitHub initial commit initialization
      await new Promise((r) => setTimeout(r, 900));
    } else if (!checkRepoRes.ok) {
      return res.json({ ok: false, error: `Failed checking repo (${checkRepoRes.status}).` });
    }

    // 3. Push files cleanly via Contents API (checks existing SHA if updating)
    const entries = Object.entries(files);
    const pushedFiles: string[] = [];
    let lastCommitSha = '';

    for (const [filePath, content] of entries) {
      const normalizedPath = filePath.replace(/^\/+/, '');
      let existingSha: string | undefined;

      const existingRes = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/contents/${normalizedPath}`,
        { headers }
      );
      if (existingRes.ok) {
        const existingData = (await existingRes.json()) as { sha?: string };
        existingSha = existingData.sha;
      }

      const putRes = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/contents/${normalizedPath}`,
        {
          method: 'PUT',
          headers,
          body: JSON.stringify({
            message: `Sarfealam Auto-Studio: update ${normalizedPath}`,
            content: Buffer.from(content, 'utf-8').toString('base64'),
            ...(existingSha ? { sha: existingSha } : {}),
          }),
        }
      );

      if (!putRes.ok) {
        const putErr = await putRes.text().catch(() => '');
        return res.json({
          ok: false,
          error: `Push failed on ${normalizedPath} (${putRes.status}). Note: pushing .github/workflows/* requires the 'workflow' token scope. ${putErr.slice(0, 140)}`,
          pushedFiles,
        });
      }

      const putData = (await putRes.json()) as { commit?: { sha?: string } };
      if (putData.commit?.sha) lastCommitSha = putData.commit.sha;
      pushedFiles.push(normalizedPath);
    }

    return res.json({
      ok: true,
      owner,
      repo: cleanRepo,
      repoUrl,
      actionsUrl: `${repoUrl}/actions`,
      releasesUrl: `${repoUrl}/releases`,
      commitSha: lastCommitSha,
      pushedFiles,
    });
  } catch (err: unknown) {
    const e = err as Error;
    return res.json({ ok: false, error: e.message || 'GitHub export failed.' });
  }
});

// 5) Poll GitHub Actions runs & artifacts for real APK link
app.post('/api/github/poll', async (req, res) => {
  const { token, owner, repo } = req.body as { token?: string; owner?: string; repo?: string };
  if (!token || !owner || !repo) {
    return res.json({ ok: false, error: 'Missing token, owner, or repo.' });
  }

  const headers = {
    Authorization: `Bearer ${token.trim()}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'Sarfealam-Auto-Studio',
  };

  try {
    const [runsRes, artifactsRes, releasesRes] = await Promise.all([
      fetch(`https://api.github.com/repos/${owner}/${repo}/actions/runs?per_page=3`, { headers }),
      fetch(`https://api.github.com/repos/${owner}/${repo}/actions/artifacts?per_page=5`, { headers }),
      fetch(`https://api.github.com/repos/${owner}/${repo}/releases?per_page=3`, { headers }),
    ]);

    const runsData = runsRes.ok
      ? ((await runsRes.json()) as {
          workflow_runs?: Array<{
            id: number;
            name: string;
            status: string;
            conclusion: string | null;
            html_url: string;
            updated_at: string;
          }>;
        })
      : { workflow_runs: [] };

    const artifactsData = artifactsRes.ok
      ? ((await artifactsRes.json()) as {
          artifacts?: Array<{
            id: number;
            name: string;
            size_in_bytes: number;
            expired: boolean;
            archive_download_url: string;
          }>;
        })
      : { artifacts: [] };

    const releasesData = releasesRes.ok
      ? ((await releasesRes.json()) as Array<{
          html_url: string;
          tag_name: string;
          assets?: Array<{ name: string; browser_download_url: string }>;
        }>)
      : [];

    const latestRun = runsData.workflow_runs?.[0] || null;
    let apkUrl: string | null = null;
    let apkSource: 'release' | 'artifact' | null = null;

    // Prefer direct browser_download_url for .apk from GitHub Releases
    for (const rel of releasesData) {
      const apkAsset = rel.assets?.find((a) => a.name.toLowerCase().endsWith('.apk'));
      if (apkAsset) {
        apkUrl = apkAsset.browser_download_url;
        apkSource = 'release';
        break;
      }
    }

    // Fallback to Actions artifact run link if artifact exists
    const apkArtifact = artifactsData.artifacts?.find(
      (a) => !a.expired && (a.name.toLowerCase().includes('apk') || a.name.toLowerCase().includes('android'))
    );
    if (!apkUrl && apkArtifact && latestRun) {
      apkUrl = `${latestRun.html_url}#artifacts`;
      apkSource = 'artifact';
    }

    return res.json({
      ok: true,
      latestRun,
      apkUrl,
      apkSource,
      artifactCount: artifactsData.artifacts?.length || 0,
      actionsUrl: `https://github.com/${owner}/${repo}/actions`,
    });
  } catch (err: unknown) {
    const e = err as Error;
    return res.json({ ok: false, error: e.message || 'Failed polling GitHub Actions.' });
  }
});

// 6) Studio Firebase REST sync (Realtime Database URL or Firestore check)
app.post('/api/firebase/studio-sync', async (req, res) => {
  const { databaseUrl, apiKey, projectId, action = 'test', payload } = req.body as {
    databaseUrl?: string;
    apiKey?: string;
    projectId?: string;
    action?: 'test' | 'push' | 'pull';
    payload?: unknown;
  };

  const cleanUrl = (databaseUrl || '').trim().replace(/\/+$/, '');
  if (!cleanUrl && !projectId) {
    return res.json({ ok: false, connected: false, error: 'Studio Firebase URL or Project ID is required.' });
  }

  // Case A: Realtime Database REST endpoint
  if (cleanUrl.includes('firebaseio.com') || cleanUrl.includes('firebasedatabase.app')) {
    const authParam = apiKey && apiKey.trim().length > 0 && !apiKey.startsWith('AIza') ? `?auth=${encodeURIComponent(apiKey.trim())}` : '';
    const targetUrl = `${cleanUrl}/sarfealam_auto_studio.json${authParam}`;
    try {
      if (action === 'push') {
        const putRes = await fetch(targetUrl, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            updatedAt: new Date().toISOString(),
            data: payload,
          }),
        });
        if (!putRes.ok) {
          const txt = await putRes.text().catch(() => '');
          return res.json({
            ok: false,
            connected: false,
            error: `Studio Firebase RTDB rejected write (${putRes.status}): ${txt.slice(0, 140)}`,
          });
        }
        return res.json({
          ok: true,
          connected: true,
          mode: 'rtdb',
          syncedAt: new Date().toISOString(),
        });
      }

      const getRes = await fetch(targetUrl);
      if (!getRes.ok) {
        const txt = await getRes.text().catch(() => '');
        return res.json({
          ok: false,
          connected: false,
          error: `Studio Firebase RTDB rejected read (${getRes.status}): ${txt.slice(0, 140)}`,
        });
      }
      const json = await getRes.json().catch(() => null);
      return res.json({
        ok: true,
        connected: true,
        mode: 'rtdb',
        syncedAt: new Date().toISOString(),
        data: json?.data || null,
      });
    } catch (err: unknown) {
      const e = err as Error;
      return res.json({ ok: false, connected: false, error: e.message || 'Network error reaching Studio Firebase.' });
    }
  }

  // Case B: Firestore REST endpoint using projectId + apiKey
  const pid = (projectId || '').trim();
  if (pid && apiKey?.trim()) {
    const docUrl = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(pid)}/databases/(default)/documents/sarfealam_studio/state?key=${encodeURIComponent(apiKey.trim())}`;
    try {
      if (action === 'push') {
        const patchRes = await fetch(docUrl, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fields: {
              updatedAt: { stringValue: new Date().toISOString() },
              snapshotJson: { stringValue: JSON.stringify(payload ?? {}) },
            },
          }),
        });
        if (!patchRes.ok) {
          const txt = await patchRes.text().catch(() => '');
          return res.json({
            ok: false,
            connected: false,
            error: `Studio Firestore rejected write (${patchRes.status}): ${txt.slice(0, 140)}`,
          });
        }
        return res.json({ ok: true, connected: true, mode: 'firestore', syncedAt: new Date().toISOString() });
      }

      const getRes = await fetch(docUrl);
      if (getRes.status === 404) {
        // Project exists and Firestore responded cleanly, doc just not created yet
        return res.json({ ok: true, connected: true, mode: 'firestore', syncedAt: new Date().toISOString(), data: null });
      }
      if (!getRes.ok) {
        const txt = await getRes.text().catch(() => '');
        return res.json({
          ok: false,
          connected: false,
          error: `Studio Firestore rejected read (${getRes.status}): ${txt.slice(0, 140)}`,
        });
      }
      const doc = (await getRes.json()) as { fields?: { snapshotJson?: { stringValue?: string } } };
      let parsed = null;
      if (doc.fields?.snapshotJson?.stringValue) {
        try {
          parsed = JSON.parse(doc.fields.snapshotJson.stringValue);
        } catch {
          parsed = null;
        }
      }
      return res.json({ ok: true, connected: true, mode: 'firestore', syncedAt: new Date().toISOString(), data: parsed });
    } catch (err: unknown) {
      const e = err as Error;
      return res.json({ ok: false, connected: false, error: e.message || 'Network error reaching Studio Firestore.' });
    }
  }

  return res.json({
    ok: false,
    connected: false,
    error: 'Provide either a Firebase Realtime Database URL (*.firebaseio.com / *.firebasedatabase.app) or both Project ID and Web API Key.',
  });
});

async function startServer() {
  const PORT = Number(process.env.PORT || 3000);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sarfealam Auto-Studio server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
