import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  CheckCircle2,
  Hammer,
  Home,
  KeyRound,
  MessageSquare,
  Mic,
  MicOff,
  Play,
  Shield,
  Sliders,
  XCircle,
  Loader2,
  Send,
} from 'lucide-react';
import type {
  AdminBuildControls,
  BuildJob,
  CoPilotMessage,
  EngineType,
  Language,
  PreviewBlueprint,
  StageRecord,
  StudioSecrets,
  StudioSkill,
  StudioTab,
} from './types/studio';
import { t } from './i18n/strings';
import { computeSecretsHealth, getActiveApiKeys, loadSecrets, saveSecrets } from './modules/secrets';
import { isSkillEnabled, loadSkills, matchPromptToSkills, saveSkills } from './modules/skills';
import { routeAIRequest, selectKeysForDepartment } from './modules/aiRouter';
import { buildSystemMap } from './modules/map';
import { createBlueprintFromPrompt, generateProjectBundle } from './modules/projectGenerator';
import {
  loadWorkflowTemplates,
  resetWorkflowTemplate,
  updateWorkflowTemplate,
  type WorkflowTemplateMap,
} from './modules/workflowTemplates';
import { pollGitHubActions, pushProjectToGitHub } from './modules/github';
import {
  loadActiveJobId,
  loadLanguage,
  loadMessages,
  loadVault,
  saveActiveJobId,
  saveLanguage,
  saveMessages,
  saveVault,
  syncStudioFirebase,
} from './modules/firebaseSync';
import {
  LiveVoiceController,
  parseLiveCommand,
  speakText,
  stopSpeaking,
} from './modules/voiceLive';
import { DisplayAAssembly } from './components/DisplayAAssembly';
import { DisplayBSystemMap } from './components/DisplayBSystemMap';
import { CoPilotView } from './components/CoPilotView';
import { VaultView } from './components/VaultView';
import { AdminView } from './components/AdminView';
import { SkillsView } from './components/SkillsView';
import { SecretsView } from './components/SecretsView';

function createInitialStages(): StageRecord[] {
  return [
    { index: 1, key: 'shell', label: 'Shell', labelHi: 'शेल', status: 'pending' },
    { index: 2, key: 'screens', label: 'Screens / World', labelHi: 'स्क्रीन्स / वर्ल्ड', status: 'pending' },
    { index: 3, key: 'hero', label: 'Hero / Main UI', labelHi: 'हीरो / मुख्य UI', status: 'pending' },
    { index: 4, key: 'controls', label: 'Controls / HUD', labelHi: 'कंट्रोल्स / HUD', status: 'pending' },
    { index: 5, key: 'ready', label: 'Ready to test', labelHi: 'टेस्ट के लिए तैयार', status: 'pending' },
  ];
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => loadLanguage());
  const [activeTab, setActiveTab] = useState<StudioTab>('copilot');
  const [secrets, setSecrets] = useState<StudioSecrets>(() => loadSecrets());
  const [skills, setSkills] = useState<StudioSkill[]>(() => loadSkills());
  const [workflowTemplates, setWorkflowTemplates] = useState<WorkflowTemplateMap>(() =>
    loadWorkflowTemplates()
  );
  const [vault, setVault] = useState<BuildJob[]>(() => loadVault());
  const [activeJobId, setActiveJobId] = useState<string | null>(() => loadActiveJobId());
  const [adminBuildId, setAdminBuildId] = useState<string | null>(() => loadActiveJobId());

  const [messages, setMessages] = useState<CoPilotMessage[]>(() => {
    const saved = loadMessages();
    if (saved.length > 0) return saved;
    const initLang = loadLanguage();
    return [
      {
        id: 'welcome-init',
        role: 'assistant',
        text: t(initLang).welcomeMessage,
        timestamp: new Date().toISOString(),
        sourceLabel: 'Sarfealam Co-Pilot',
      },
    ];
  });

  const [promptInput, setPromptInput] = useState('');
  const [engineOverride, setEngineOverride] = useState<'auto' | EngineType>('auto');
  const [isCopilotThinking, setIsCopilotThinking] = useState(false);
  const [isJobRunning, setIsJobRunning] = useState(false);

  // Live Call-Style Voice Mode (OFF by default per Acceptance Check)
  const [liveOn, setLiveOn] = useState(false);
  const [liveInterim, setLiveInterim] = useState('');
  const [liveStatus, setLiveStatus] = useState('');
  const [liveSimInput, setLiveSimInput] = useState('');

  const [toast, setToast] = useState<string>('');
  const runTokenRef = useRef<number>(0);
  const voiceControllerRef = useRef<LiveVoiceController | null>(null);

  const s = t(lang);
  const health = useMemo(() => computeSecretsHealth(secrets), [secrets]);
  const activeJob = useMemo(
    () => vault.find((j) => j.id === activeJobId) || null,
    [vault, activeJobId]
  );
  const mapState = useMemo(
    () => buildSystemMap(secrets, skills, activeJob, lang),
    [secrets, skills, activeJob, lang]
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((prev) => (prev === msg ? '' : prev)), 3200);
  }, []);

  // Persist core studio states automatically
  useEffect(() => {
    saveLanguage(lang);
    voiceControllerRef.current?.setLanguage(lang);
    // Keep initial welcome message synced if user hasn't chatted yet
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].id === 'welcome-init') {
        return [{ ...prev[0], text: t(lang).welcomeMessage }];
      }
      return prev;
    });
  }, [lang]);

  useEffect(() => {
    if (isSkillEnabled(skills, 'background-job-survivor')) {
      saveVault(vault);
      saveActiveJobId(activeJobId);
    }
  }, [vault, activeJobId, skills]);

  useEffect(() => {
    saveMessages(messages);
  }, [messages]);

  // Handle #admin/<jobId> direct Admin Final Link hash on load
  useEffect(() => {
    const hash = window.location.hash;
    if (hash.startsWith('#admin/')) {
      const targetId = hash.replace('#admin/', '').trim();
      if (targetId) {
        setAdminBuildId(targetId);
        setActiveTab('admin');
      }
    }
  }, []);

  // Studio Firebase automatic push when connected
  const pushToStudioFirebaseIfReady = useCallback(
    async (nextVault: BuildJob[], nextActiveId: string | null, nextLang: Language) => {
      if (
        secrets.studioFirebase.status !== 'connected' ||
        !isSkillEnabled(skills, 'studio-firebase-sync')
      ) {
        return;
      }
      await syncStudioFirebase(secrets.studioFirebase, 'push', {
        vault: nextVault.slice(0, 20),
        activeJobId: nextActiveId,
        language: nextLang,
        mapFooter: mapState.footerText,
      });
    },
    [secrets.studioFirebase, skills, mapState.footerText]
  );

  const updateJob = useCallback(
    (jobId: string, updater: (job: BuildJob) => BuildJob) => {
      setVault((prev) => {
        const next = prev.map((j) =>
          j.id === jobId ? updater({ ...j, updatedAt: new Date().toISOString() }) : j
        );
        return next;
      });
    },
    []
  );

  const appendMessage = useCallback((msg: Omit<CoPilotMessage, 'id' | 'timestamp'>) => {
    const full: CoPilotMessage = {
      ...msg,
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, full]);
    return full;
  }, []);

  // === CORE 5-STAGE AUTONOMOUS BUILD ENGINE ===
  const runAssemblyPipeline = useCallback(
    async (jobId: string, initialJob: BuildJob, startFromStage = 1) => {
      const myRun = ++runTokenRef.current;
      setIsJobRunning(true);

      const isAborted = () => runTokenRef.current !== myRun;
      const activeKeys = getActiveApiKeys(secrets);
      const hasAi = activeKeys.length > 0;
      const allowFallback = isSkillEnabled(skills, 'rate-limit-fallback');
      const useCritic = isSkillEnabled(skills, 'self-heal-critic');
      const useVisionQa = isSkillEnabled(skills, 'vision-qa-preview');
      const useResearch = isSkillEnabled(skills, 'research-bot');
      const useStagesA = isSkillEnabled(skills, 'assembly-stages-a');

      const brainKey = selectKeysForDepartment(secrets, 'brain')[0];
      const codeKey = selectKeysForDepartment(secrets, 'code')[0] || brainKey;
      const visionKey = selectKeysForDepartment(secrets, 'vision')[0] || brainKey;

      const stageOrder: Array<1 | 2 | 3 | 4 | 5> = useStagesA ? [1, 2, 3, 4, 5] : [1, 5];
      let currentBlueprint: PreviewBlueprint = initialJob.blueprint;
      const usedProviders = new Set<string>(initialJob.usedProviders);
      const fallbackEvents = [...initialJob.fallbackEvents];

      const setStageActive = (
        stageNum: 1 | 2 | 3 | 4 | 5,
        chipId: string,
        caption: string,
        workerName: string,
        contextNote?: string
      ) => {
        updateJob(jobId, (j) => {
          const stages = j.stages.map((st) => {
            if (st.index < stageNum) return { ...st, status: 'done' as const };
            if (st.index === stageNum) return { ...st, status: 'active' as const, workerName };
            return { ...st, status: 'pending' as const };
          });
          return {
            ...j,
            status: 'assembling',
            stageIndex: stageNum,
            stages,
            activeChipId: chipId,
            activeWorkCaption: caption,
            usedProviders: Array.from(usedProviders),
            fallbackEvents,
            blueprint: currentBlueprint,
            sharedContext: contextNote
              ? [
                  ...j.sharedContext,
                  {
                    stage: stageNum,
                    worker: workerName,
                    department: chipId,
                    note: contextNote,
                    timestamp: new Date().toISOString(),
                  },
                ]
              : j.sharedContext,
          };
        });
      };

      try {
        for (const stageNum of stageOrder) {
          if (stageNum < startFromStage) continue;
          if (isAborted()) return;

          if (stageNum === 1) {
            const chipId = brainKey ? `chip-key-${brainKey.id}` : 'chip-agent-brain-muted';
            const worker = brainKey ? brainKey.name : 'Brain AI (Demo)';
            setStageActive(
              1,
              chipId,
              `${worker} · scaffolding ${initialJob.engine === 'godot4' ? 'Godot 4' : 'Flutter'} shell`,
              worker
            );

            // Real AI call when user configured at least 1 key
            if (hasAi) {
              const aiRes = await routeAIRequest(secrets, {
                department: 'brain',
                allowFallback,
                jsonMode: true,
                systemInstruction:
                  'You are Sarfealam Auto-Studio architect. Return ONLY valid JSON with keys: appName (string), tagline (string), heroTitle (string), heroSubtitle (string), tabs (array of 4 short labels), items (array of 3 objects with title, subtitle, meta). Keep it concise and domain-specific.',
                prompt: `Prompt: ${initialJob.prompt}\nEngine: ${initialJob.engine}\nEnabled capability skills: ${initialJob.matchedSkills.filter((id) => id.startsWith('cap-')).join(', ')}`,
              });

              if (isAborted()) return;

              if (aiRes.ok && aiRes.text) {
                const usedLabel = `${aiRes.usedKeyLabel || worker} (${aiRes.usedModel || ''})`;
                usedProviders.add(usedLabel);
                if (aiRes.fallbackUsed) {
                  fallbackEvents.push(`Stage 1 fallback → ${usedLabel}`);
                }
                try {
                  const cleanedJson = aiRes.text
                    .replace(/^```json\s*/i, '')
                    .replace(/^```\s*/i, '')
                    .replace(/```$/i, '')
                    .trim();
                  const parsed = JSON.parse(cleanedJson) as Partial<PreviewBlueprint>;
                  currentBlueprint = createBlueprintFromPrompt(
                    initialJob.prompt,
                    initialJob.productType,
                    initialJob.engine,
                    initialJob.matchedSkills,
                    false,
                    { ...parsed, aiGeneratedNote: `Generated by ${usedLabel}` }
                  );
                } catch {
                  currentBlueprint = {
                    ...currentBlueprint,
                    aiGeneratedNote: `Briefed by ${usedLabel}`,
                    isDemoSimulation: false,
                  };
                }
              } else if (aiRes.error) {
                const errMsg = aiRes.error;
                fallbackEvents.push(`Stage 1 API notice: ${errMsg}`);
                updateJob(jobId, (j) => ({
                  ...j,
                  sharedContext: [
                    ...j.sharedContext,
                    {
                      stage: 1,
                      worker,
                      department: 'brain',
                      note: `API error (${errMsg.slice(0, 80)}) — continued with structured blueprint`,
                      timestamp: new Date().toISOString(),
                    },
                  ],
                }));
              }
            } else {
              await sleep(650);
            }

            if (isAborted()) return;

            // Optional Research Bot handoff
            if (useResearch && initialJob.matchedSkills.includes('research-bot')) {
              setStageActive(
                1,
                'chip-bot-research',
                'Research Bot · compiling domain spec',
                'Research Bot',
                `Matched ${initialJob.matchedSkills.length} skills for ${initialJob.engine} build`
              );
              await sleep(420);
              if (isAborted()) return;
              updateJob(jobId, (j) => ({
                ...j,
                researchSummary: `Domain spec prepared for ${currentBlueprint.appName} (${initialJob.engine})`,
              }));
            }
          }

          if (stageNum === 2) {
            const chipId = codeKey ? `chip-key-${codeKey.id}` : 'chip-agent-code-muted';
            const worker = codeKey ? codeKey.name : 'Code AI (Demo)';
            if (codeKey) usedProviders.add(`${codeKey.name} (${codeKey.model})`);
            setStageActive(
              2,
              chipId,
              `${worker} · writing ${initialJob.productType === 'game' ? 'game world & scenes' : 'screens & navigation'}`,
              worker,
              `Wired ${currentBlueprint.tabs.join(' / ')} navigation from Stage 1 blueprint`
            );
            await sleep(750);
          }

          if (stageNum === 3) {
            const chipId = codeKey ? `chip-key-${codeKey.id}` : 'chip-agent-code-muted';
            const worker = codeKey ? codeKey.name : 'Code AI (Demo)';
            setStageActive(
              3,
              chipId,
              `${worker} · assembling hero UI & capability modules`,
              worker,
              `Mounted hero & ${initialJob.matchedSkills.filter((m) => m.startsWith('cap-')).length} capability modules`
            );
            await sleep(800);
          }

          if (stageNum === 4) {
            const chipId = visionKey ? `chip-key-${visionKey.id}` : 'chip-agent-vision-muted';
            const worker = visionKey ? visionKey.name : 'Vision / QA (Demo)';
            if (visionKey) usedProviders.add(`${visionKey.name} (${visionKey.model})`);

            setStageActive(
              4,
              chipId,
              useVisionQa ? `${worker} · auditing controls & HUD contrast` : `${worker} · wiring controls & HUD`,
              worker,
              'Touch targets ≥ 44px and controls bound'
            );
            await sleep(650);
            if (isAborted()) return;

            // Critic / Self-Heal 1-3 Pass if enabled
            if (useCritic) {
              setStageActive(
                4,
                'chip-bot-critic',
                'Critic & Self-Heal · verifying pass 1/2',
                'Critic & Self-Heal',
                'Critic verified stage outputs & Apps Firebase config slot'
              );
              await sleep(550);
              if (isAborted()) return;
              updateJob(jobId, (j) => ({
                ...j,
                criticAttempts: 1,
                criticNote: '1/1 pass clean · ready for test',
              }));
            }
          }

          if (stageNum === 5) {
            if (isAborted()) return;
            const bundle = generateProjectBundle({
              title: currentBlueprint.appName,
              prompt: initialJob.prompt,
              engine: initialJob.engine,
              blueprint: currentBlueprint,
              matchedSkillIds: initialJob.matchedSkills,
              allSkills: skills,
              appsFirebase: secrets.appsFirebase,
              adminBannerText: initialJob.adminControls.bannerText,
              vipNote: initialJob.adminControls.vipNote,
              workflowTemplates,
            });

            updateJob(jobId, (j) => ({
              ...j,
              title: currentBlueprint.appName,
              status: 'testing',
              stageIndex: 5,
              activeChipId: null,
              activeWorkCaption: 'Stage 5 · ready for interactive test',
              blueprint: currentBlueprint,
              usedProviders: Array.from(usedProviders),
              fallbackEvents,
              stages: j.stages.map((st) => ({
                ...st,
                status: 'done',
                completedAt: st.completedAt || new Date().toISOString(),
              })),
              exportArtifacts: {
                ...j.exportArtifacts,
                repoName: bundle.repoSuggestedName,
                workflowPath: bundle.workflowPath,
                appsFirebaseInjected: bundle.appsFirebaseInjected,
                files: bundle.files,
              },
              sharedContext: [
                ...j.sharedContext,
                {
                  stage: 5,
                  worker: 'Assembly Pipeline',
                  department: 'Ready',
                  note: `Stage 5 reached. ${Object.keys(bundle.files).length} ${j.engine} files staged. Press OK to export.`,
                  timestamp: new Date().toISOString(),
                },
              ],
            }));

            const doneNotice =
              lang === 'hi'
                ? `${currentBlueprint.appName} स्टेज 5 तक तैयार है। अब Display A पर टेस्ट करें और एक्सपोर्ट के लिए OK दबाएं।`
                : `${currentBlueprint.appName} reached Stage 5 (Ready to test). Test controls on Display A, then press OK to export.`;
            showToast(doneNotice);
            if (liveOn) speakText(doneNotice, lang);
          }
        }
      } finally {
        if (!isAborted()) {
          setIsJobRunning(false);
        }
      }
    },
    [secrets, skills, workflowTemplates, updateJob, lang, liveOn, showToast]
  );

  // Background Job Survivor on initial mount: if a job was left mid-assembling, resume cleanly
  const resumedOnceRef = useRef(false);
  useEffect(() => {
    if (resumedOnceRef.current) return;
    resumedOnceRef.current = true;
    if (activeJob && activeJob.status === 'assembling' && activeJob.stageIndex < 5) {
      showToast(`Background Job Survivor resumed "${activeJob.title}" at Stage ${activeJob.stageIndex}/5.`);
      runAssemblyPipeline(activeJob.id, activeJob, Math.max(1, activeJob.stageIndex));
    }
  }, [activeJob, runAssemblyPipeline, showToast]);

  const startNewBuild = useCallback(
    (rawPrompt: string) => {
      const prompt = rawPrompt.trim();
      if (!prompt) return;

      const match = matchPromptToSkills(prompt, skills);
      const chosenEngine: EngineType =
        engineOverride === 'auto' ? match.recommendedEngine : engineOverride;
      const productType = chosenEngine === 'godot4' ? 'game' : match.productType;
      const isDemo = !health.hasAnyAiKey;

      const blueprint = createBlueprintFromPrompt(
        prompt,
        productType,
        chosenEngine,
        match.matchedIds,
        isDemo
      );

      const newJob: BuildJob = {
        id: `build-${Date.now()}`,
        title: blueprint.appName,
        prompt,
        productType,
        engine: chosenEngine,
        status: 'assembling',
        stageIndex: 1,
        stages: createInitialStages(),
        matchedSkills: match.matchedIds,
        skippedSkills: match.skippedBecauseOffIds,
        activeChipId: 'chip-prompt',
        activeWorkCaption: 'Prompt matched · starting pipeline',
        usedProviders: [],
        fallbackEvents: [],
        criticAttempts: 0,
        blueprint,
        exportArtifacts: {
          apkStatus: 'not-started',
          appsFirebaseInjected: false,
          files: {},
        },
        adminControls: {
          bannerEnabled: true,
          bannerText: `Welcome to ${blueprint.appName}`,
          vipNote: 'VIP unlocks zero-ad priority features',
          vipPriceLabel: '₹199/mo',
          notifications: [],
        },
        sharedContext: [
          {
            stage: 1,
            worker: 'Engine Picker',
            department: 'Intake',
            note: `Selected ${chosenEngine.toUpperCase()} · ${match.matchedIds.length} skills ON, ${match.skippedBecauseOffIds.length} skipped (OFF)`,
            timestamp: new Date().toISOString(),
          },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isDemoMode: isDemo,
        revisionCount: 0,
      };

      setVault((prev) => {
        const next = [newJob, ...prev];
        pushToStudioFirebaseIfReady(next, newJob.id, lang);
        return next;
      });
      setActiveJobId(newJob.id);
      setAdminBuildId(newJob.id);
      setActiveTab('build');
      setPromptInput('');

      runAssemblyPipeline(newJob.id, newJob, 1);
    },
    [skills, engineOverride, health.hasAnyAiKey, runAssemblyPipeline, pushToStudioFirebaseIfReady, lang]
  );

  const handleApplyFix = useCallback(
    (fixPrompt: string) => {
      if (!activeJob) return;
      const combinedPrompt = `${activeJob.prompt}. Revision: ${fixPrompt}`;
      const match = matchPromptToSkills(combinedPrompt, skills);
      const updatedJob: BuildJob = {
        ...activeJob,
        prompt: combinedPrompt,
        matchedSkills: match.matchedIds,
        skippedSkills: match.skippedBecauseOffIds,
        revisionCount: activeJob.revisionCount + 1,
        status: 'assembling',
        stageIndex: 3,
        blueprint: createBlueprintFromPrompt(
          combinedPrompt,
          activeJob.productType,
          activeJob.engine,
          match.matchedIds,
          !health.hasAnyAiKey
        ),
        sharedContext: [
          ...activeJob.sharedContext,
          {
            stage: 3,
            worker: 'User Fix Request',
            department: 'Revision',
            note: fixPrompt,
            timestamp: new Date().toISOString(),
          },
        ],
      };

      updateJob(activeJob.id, () => updatedJob);
      runAssemblyPipeline(activeJob.id, updatedJob, 3);
    },
    [activeJob, skills, health.hasAnyAiKey, updateJob, runAssemblyPipeline]
  );

  // === BOTTOM BAR: CANCEL ===
  const handleCancelJob = useCallback(() => {
    runTokenRef.current++;
    setIsJobRunning(false);
    if (activeJob) {
      updateJob(activeJob.id, (j) => ({
        ...j,
        status: 'cancelled',
        stageIndex: 0,
        activeChipId: null,
        activeWorkCaption: 'Aborted by user',
        stages: createInitialStages(),
      }));
    }
    showToast(s.build.cancelDone);
    if (liveOn) speakText(s.build.cancelDone, lang);
  }, [activeJob, updateJob, showToast, s.build.cancelDone, liveOn, lang]);

  // === BOTTOM BAR: HOME ===
  const handleGoHome = useCallback(() => {
    setActiveTab('build');
    if (!isJobRunning) {
      setActiveJobId(null);
      showToast(s.build.homeReset);
    }
  }, [isJobRunning, showToast, s.build.homeReset]);

  // === BOTTOM BAR: OK (REAL EXPORT + GITHUB + VAULT/ADMIN LINKS) ===
  const canPressOk = Boolean(
    activeJob &&
      activeJob.stageIndex >= 5 &&
      (activeJob.status === 'testing' || activeJob.status === 'ready') &&
      !isJobRunning
  );

  const handleOkExport = useCallback(async () => {
    if (!activeJob || activeJob.stageIndex < 5) {
      showToast(s.build.okTooltipDisabled);
      return;
    }

    setIsJobRunning(true);
    const publishAdminLink = isSkillEnabled(skills, 'publish-admin-link');
    const githubPushSkill = isSkillEnabled(skills, 'github-connect-push');
    const adminFinalUrl = publishAdminLink
      ? `${window.location.origin}/#admin/${activeJob.id}`
      : undefined;

    // Regenerate fresh files including latest Admin Banner / VIP note, Apps Firebase & managed Workflow YAML
    const bundle = generateProjectBundle({
      title: activeJob.title,
      prompt: activeJob.prompt,
      engine: activeJob.engine,
      blueprint: activeJob.blueprint,
      matchedSkillIds: activeJob.matchedSkills,
      allSkills: skills,
      appsFirebase: secrets.appsFirebase,
      adminBannerText: activeJob.adminControls.bannerText,
      vipNote: activeJob.adminControls.vipNote,
      workflowTemplates,
    });

    updateJob(activeJob.id, (j) => ({
      ...j,
      status: 'exporting',
      activeChipId: 'chip-github',
      activeWorkCaption: health.githubConnected
        ? 'GitHub Bot · creating repo & pushing workflow...'
        : 'Packaging export bundle (GitHub Token1 missing)',
      exportArtifacts: {
        ...j.exportArtifacts,
        repoName: bundle.repoSuggestedName,
        workflowPath: bundle.workflowPath,
        appsFirebaseInjected: bundle.appsFirebaseInjected,
        adminFinalUrl,
        files: bundle.files,
      },
    }));

    try {
      // Honest check: if GitHub Token1 is NOT connected OR github-connect-push skill is OFF
      if (!health.githubConnected || !githubPushSkill) {
        const reason = !githubPushSkill
          ? 'GitHub Connect & Push skill is toggled OFF in Skills.'
          : 'Blocked: GitHub Token1 not validated in Secrets. Source + Workflow ZIP packaged locally — no fake APK link generated.';

        updateJob(activeJob.id, (j) => ({
          ...j,
          status: 'ready',
          activeChipId: 'chip-bot-connect',
          activeWorkCaption: 'Local package ready · GitHub Token1 needed for APK',
          exportArtifacts: {
            ...j.exportArtifacts,
            apkStatus: 'blocked',
            apkSource: 'local-package',
            adminFinalUrl,
            errorReason: reason,
          },
          sharedContext: [
            ...j.sharedContext,
            {
              stage: 5,
              worker: 'Connect Bot',
              department: 'Export',
              note: reason,
              timestamp: new Date().toISOString(),
            },
          ],
        }));

        const msg =
          lang === 'hi'
            ? 'लोकल Flutter/Godot पैकेज तैयार होकर Vault में सेव हो गया है। असली APK लिंक के लिए Secrets में GitHub Token1 जोड़ें।'
            : 'Export files + workflow saved to Vault (ZIP ready). Connect GitHub Token1 in Secrets to trigger real Actions APK builds.';
        showToast(msg);
        if (liveOn) speakText(msg, lang);
        setAdminBuildId(activeJob.id);
        return;
      }

      // REAL GitHub Push Path!
      const pushRes = await pushProjectToGitHub({
        token: secrets.githubToken.token,
        repoName: bundle.repoSuggestedName,
        description: `${activeJob.title} — Generated by Sarfealam Auto-Studio (${activeJob.engine})`,
        files: bundle.files,
      });

      if (!pushRes.ok || !pushRes.owner || !pushRes.repo) {
        updateJob(activeJob.id, (j) => ({
          ...j,
          status: 'error',
          activeChipId: 'chip-github',
          activeWorkCaption: 'GitHub push error',
          errorMessage: pushRes.error || 'GitHub export failed',
          exportArtifacts: {
            ...j.exportArtifacts,
            apkStatus: 'error',
            adminFinalUrl,
            errorReason: pushRes.error || 'GitHub push failed',
          },
        }));
        showToast(`GitHub export failed: ${pushRes.error}`);
        return;
      }

      // Immediately poll once to capture queued Actions run
      let apkUrl: string | undefined;
      let apkStatus: BuildJob['exportArtifacts']['apkStatus'] = 'queued';
      if (isSkillEnabled(skills, 'actions-status-poll')) {
        await sleep(1200);
        const pollRes = await pollGitHubActions({
          token: secrets.githubToken.token,
          owner: pushRes.owner,
          repo: pushRes.repo,
        });
        if (pollRes.ok) {
          if (pollRes.apkUrl && isSkillEnabled(skills, 'publish-apk-link')) {
            apkUrl = pollRes.apkUrl;
            apkStatus = 'ready';
          } else if (pollRes.latestRun?.status === 'in_progress') {
            apkStatus = 'building';
          }
        }
      }

      updateJob(activeJob.id, (j) => ({
        ...j,
        status: 'ready',
        activeChipId: 'chip-github',
        activeWorkCaption: apkUrl
          ? 'APK & Admin links published to Vault'
          : 'Pushed to GitHub · Actions building APK',
        exportArtifacts: {
          ...j.exportArtifacts,
          repoOwner: pushRes.owner,
          repoName: pushRes.repo,
          repoUrl: pushRes.repoUrl,
          actionsUrl: pushRes.actionsUrl,
          commitSha: pushRes.commitSha,
          apkUrl,
          apkStatus,
          apkSource: apkUrl ? 'github-release' : undefined,
          adminFinalUrl,
          errorReason: undefined,
          lastPolledAt: new Date().toISOString(),
        },
        sharedContext: [
          ...j.sharedContext,
          {
            stage: 5,
            worker: 'GitHub Bot',
            department: 'Delivery',
            note: `Pushed ${pushRes.pushedFiles?.length || 0} files to ${pushRes.owner}/${pushRes.repo}. Actions workflow triggered.`,
            timestamp: new Date().toISOString(),
          },
        ],
      }));

      setAdminBuildId(activeJob.id);
      const okMsg =
        lang === 'hi'
          ? `GitHub रेपो ${pushRes.owner}/${pushRes.repo} पर कोड और APK वर्कफ़्लो पुश हो गया! Vault और Admin में लिंक उपलब्ध हैं।`
          : `Pushed to ${pushRes.owner}/${pushRes.repo} with Actions APK workflow! Links published in Vault & Admin.`;
      showToast(okMsg);
      if (liveOn) speakText(okMsg, lang);
    } finally {
      setIsJobRunning(false);
    }
  }, [activeJob, skills, secrets, workflowTemplates, health.githubConnected, updateJob, showToast, s.build.okTooltipDisabled, lang, liveOn]);

  // === POLL GITHUB ACTIONS FOR APK ARTIFACT / RELEASE ===
  const handlePollGitHub = useCallback(
    async (jobId: string) => {
      const target = vault.find((j) => j.id === jobId);
      if (!target || !target.exportArtifacts.repoOwner || !target.exportArtifacts.repoName) return;
      if (!secrets.githubToken.token.trim()) {
        showToast('GitHub Token1 missing in Secrets.');
        return;
      }

      const res = await pollGitHubActions({
        token: secrets.githubToken.token,
        owner: target.exportArtifacts.repoOwner,
        repo: target.exportArtifacts.repoName,
      });

      if (!res.ok) {
        showToast(`Poll error: ${res.error}`);
        return;
      }

      updateJob(jobId, (j) => ({
        ...j,
        exportArtifacts: {
          ...j.exportArtifacts,
          apkUrl: res.apkUrl || j.exportArtifacts.apkUrl,
          apkStatus: res.apkUrl
            ? 'ready'
            : res.latestRun?.conclusion === 'failure'
              ? 'error'
              : res.latestRun?.status === 'in_progress'
                ? 'building'
                : 'queued',
          apkSource:
            res.apkSource === 'release'
              ? 'github-release'
              : res.apkSource === 'artifact'
                ? 'github-artifact'
                : j.exportArtifacts.apkSource,
          lastPolledAt: new Date().toISOString(),
          errorReason:
            res.latestRun?.conclusion === 'failure'
              ? 'GitHub Actions build failed — open Actions link to inspect logs.'
              : undefined,
        },
      }));

      if (res.apkUrl) {
        showToast('APK link published to Vault & Admin.');
      } else {
        showToast(
          `Actions status: ${res.latestRun?.status || 'waiting'} (${res.latestRun?.conclusion || 'running'})`
        );
      }
    },
    [vault, secrets.githubToken.token, updateJob, showToast]
  );

  // === CONNECT BOT DIAGNOSTIC ===
  const buildConnectBotReport = useCallback(
    (targetLang: Language): string => {
      if (health.issues.length === 0) {
        return targetLang === 'hi'
          ? `Connect Bot रिपोर्ट: सभी कनेक्शन स्वस्थ हैं! ${health.activeKeyCount} AI key सक्रिय हैं, GitHub @${secrets.githubToken.username} से जुड़ा है, Studio Firebase और Apps Firebase दोनों तैयार हैं।`
          : `Connect Bot Report: All systems healthy. ${health.activeKeyCount} AI key(s) active, GitHub connected as @${secrets.githubToken.username}, Studio Firebase synced, and Apps Firebase ready for export injection.`;
      }
      const list = health.issues
        .map((iss, i) => `${i + 1}. ${targetLang === 'hi' ? iss.messageHi : iss.message}`)
        .join('\n');
      return targetLang === 'hi'
        ? `Connect Bot जांच (${health.issues.length} सुझाव):\n${list}\n\nसुधार के लिए Secrets टैब खोलें।`
        : `Connect Bot Check (${health.issues.length} item${health.issues.length > 1 ? 's' : ''}):\n${list}\n\nOpen the Secrets tab to configure missing credentials.`;
    },
    [health, secrets.githubToken.username]
  );

  const handleRunConnectBot = useCallback(() => {
    const report = buildConnectBotReport(lang);
    appendMessage({
      role: 'assistant',
      text: report,
      sourceLabel: 'Connect Bot · Secrets Health',
    });
    if (liveOn) speakText(report, lang);
  }, [buildConnectBotReport, lang, appendMessage, liveOn]);

  // === CO-PILOT & LIVE COMMAND DISPATCHER ===
  const handleCoPilotOrLiveInput = useCallback(
    async (rawText: string, viaLive = false) => {
      const text = rawText.trim();
      if (!text) return;

      appendMessage({ role: 'user', text, viaLive });

      const cmd = parseLiveCommand(text);

      if (cmd.type === 'SWITCH_LANG') {
        setLang(cmd.lang);
        const reply =
          cmd.lang === 'hi'
            ? 'भाषा हिंदी में बदल दी गई है। अब मैं हिंदी में जवाब दूँगा।'
            : 'Switched studio Co-Pilot language to English.';
        appendMessage({
          role: 'assistant',
          text: reply,
          sourceLabel: 'Studio Command',
          actionTaken: `Language → ${cmd.lang.toUpperCase()}`,
        });
        if (viaLive || liveOn) speakText(reply, cmd.lang);
        return;
      }

      if (cmd.type === 'NAVIGATE') {
        setActiveTab(cmd.tab);
        const reply =
          lang === 'hi' ? `${cmd.tab} टैब खोल दिया गया है।` : `Opened the ${cmd.tab} tab.`;
        appendMessage({
          role: 'assistant',
          text: reply,
          sourceLabel: 'Studio Command',
          actionTaken: `Navigated → ${cmd.tab}`,
        });
        if (viaLive || liveOn) speakText(reply, lang);
        return;
      }

      if (cmd.type === 'HOME') {
        handleGoHome();
        const reply = lang === 'hi' ? 'बिल्ड होम पर वापस आ गए।' : 'Returned to Build home.';
        appendMessage({
          role: 'assistant',
          text: reply,
          sourceLabel: 'Studio Command',
          actionTaken: 'Returned → Build Home',
        });
        if (viaLive || liveOn) speakText(reply, lang);
        return;
      }

      if (cmd.type === 'CANCEL') {
        handleCancelJob();
        const reply = s.build.cancelDone;
        appendMessage({
          role: 'assistant',
          text: reply,
          sourceLabel: 'Studio Command',
          actionTaken: 'Job Cancelled',
        });
        return;
      }

      if (cmd.type === 'OK_EXPORT') {
        if (!canPressOk) {
          const reply = s.build.okTooltipDisabled;
          appendMessage({
            role: 'assistant',
            text: reply,
            sourceLabel: 'Studio Guard',
          });
          if (viaLive || liveOn) speakText(reply, lang);
        } else {
          appendMessage({
            role: 'assistant',
            text: s.build.exportInProgress,
            sourceLabel: 'Studio Command',
            actionTaken: 'OK Export Triggered',
          });
          handleOkExport();
        }
        return;
      }

      if (cmd.type === 'STATUS') {
        const report = buildConnectBotReport(lang);
        const jobLine = activeJob
          ? lang === 'hi'
            ? `\n\nचालू बिल्ड: "${activeJob.title}" (${activeJob.engine}) — स्टेज ${activeJob.stageIndex}/5 (${activeJob.status})`
            : `\n\nActive Build: "${activeJob.title}" (${activeJob.engine}) — Stage ${activeJob.stageIndex}/5 (${activeJob.status})`
          : '';
        const full = `${report}${jobLine}`;
        appendMessage({
          role: 'assistant',
          text: full,
          sourceLabel: 'Screen-Aware Co-Pilot',
        });
        if (viaLive || liveOn) speakText(full, lang);
        return;
      }

      if (cmd.type === 'BUILD') {
        const reply =
          lang === 'hi'
            ? `ठीक है! "${cmd.prompt}" के लिए Build पाइपलाइन शुरू कर रहा हूँ — Display A और Display B पर लाइव देखें।`
            : `Starting assembly pipeline for "${cmd.prompt}". Switching to Build dual-display view.`;
        appendMessage({
          role: 'assistant',
          text: reply,
          sourceLabel: 'Studio Pipeline',
          actionTaken: 'Started 5-Stage Assembly',
        });
        if (viaLive || liveOn) speakText(reply, lang);
        startNewBuild(cmd.prompt);
        return;
      }

      // General conversation -> route through configured AI keys (if any) with Screen Awareness!
      setIsCopilotThinking(true);
      try {
        const screenAware = isSkillEnabled(skills, 'screen-aware-copilot');
        const screenContext = screenAware
          ? `Current Tab: ${activeTab}\nActive Job: ${activeJob ? `${activeJob.title} (${activeJob.engine}, Stage ${activeJob.stageIndex}/5, Status ${activeJob.status})` : 'None'}\nMap Footer: ${mapState.footerText}\nActive AI Keys: ${health.activeKeyCount}\nGitHub Connected: ${health.githubConnected ? '@' + secrets.githubToken.username : 'NO (Token1 missing)'}\nStudio Firebase: ${health.studioFirebaseConnected ? 'Connected' : 'Local only'}\nApps Firebase: ${health.appsFirebaseConfigured ? secrets.appsFirebase.projectId : 'Not configured'}`
          : 'Screen awareness toggled OFF.';

        const res = await routeAIRequest(secrets, {
          department: 'brain',
          allowFallback: isSkillEnabled(skills, 'rate-limit-fallback'),
          history: messages
            .filter((m) => m.role === 'user' || m.role === 'assistant')
            .slice(-6)
            .map((m) => ({ role: m.role as 'user' | 'assistant', text: m.text })),
          systemInstruction: `You are Sarfealam Auto-Studio Co-Pilot. Respond concisely in ${lang === 'hi' ? 'Hindi (Devanagari)' : 'English'}. Never invent fake connected states or fake APK links. Use the real studio screen state below:\n${screenContext}`,
          prompt: text,
        });

        if (res.ok && res.text) {
          const sourceLabel = `${res.usedKeyLabel || res.usedProvider} · ${res.usedModel || ''}${res.fallbackUsed ? ' (fallback)' : ''}`;
          appendMessage({
            role: 'assistant',
            text: res.text,
            sourceLabel,
          });
          if (viaLive || liveOn) speakText(res.text, lang);
        } else {
          // Honest local Screen-Aware response when 0 keys or key failed
          const errExplain =
            res.code === 'NO_KEYS'
              ? lang === 'hi'
                ? `अभी Secrets में कोई AI API key सेव नहीं है, इसलिए मैं लोकल स्क्रीन-अवेयर मोड में जवाब दे रहा हूँ।\n\nआप अभी भी "Build ..." बोलकर/लिखकर Local Blueprint Preview चला सकते हैं, या Secrets टैब में कम से कम 1 API key (Gemini/Groq/NVIDIA/Qwen) जोड़कर असली AI टीम चालू कर सकते हैं।\n\n${buildConnectBotReport('hi')}`
                : `No AI API key is saved in Secrets yet, so Co-Pilot is operating in honest Local Screen-Aware mode.\n\nYou can still say or type "Build a ..." to run a Local Blueprint Preview, or add at least 1 General API key in Secrets to activate live AI team routing.\n\n${buildConnectBotReport('en')}`
              : lang === 'hi'
                ? `AI कॉल फेल हुआ: ${res.error}\nकृपया Secrets टैब में अपनी API key और मॉडल जांचें।`
                : `AI routing error: ${res.error}\nPlease check your API key, model name, or quota in the Secrets tab.`;

          appendMessage({
            role: 'assistant',
            text: errExplain,
            sourceLabel: res.code === 'NO_KEYS' ? 'Local Screen-Aware Co-Pilot · No AI Key' : 'AI Routing Error',
          });
          if (viaLive || liveOn) speakText(errExplain, lang);
        }
      } finally {
        setIsCopilotThinking(false);
      }
    },
    [
      appendMessage,
      lang,
      liveOn,
      handleGoHome,
      handleCancelJob,
      canPressOk,
      s.build.cancelDone,
      s.build.okTooltipDisabled,
      s.build.exportInProgress,
      handleOkExport,
      buildConnectBotReport,
      activeJob,
      startNewBuild,
      skills,
      activeTab,
      mapState.footerText,
      health,
      secrets,
      messages,
    ]
  );

  // Keep voice controller bound to latest handler
  const latestLiveHandlerRef = useRef(handleCoPilotOrLiveInput);
  useEffect(() => {
    latestLiveHandlerRef.current = handleCoPilotOrLiveInput;
  }, [handleCoPilotOrLiveInput]);

  useEffect(() => {
    voiceControllerRef.current = new LiveVoiceController({
      onInterim: (txt) => setLiveInterim(txt),
      onFinal: (txt) => {
        latestLiveHandlerRef.current(txt, true);
      },
      onStatus: (st) => setLiveStatus(st),
    });
    return () => {
      voiceControllerRef.current?.stop();
      stopSpeaking();
    };
  }, []);

  const handleToggleLive = () => {
    if (!isSkillEnabled(skills, 'live-voice-command')) {
      showToast('Live Voice Command skill is OFF in Skills tab.');
      return;
    }
    if (liveOn) {
      voiceControllerRef.current?.stop();
      stopSpeaking();
      setLiveOn(false);
      setLiveInterim('');
      setLiveStatus('');
    } else {
      setLiveOn(true);
      voiceControllerRef.current?.start(lang);
    }
  };

  // Secrets & Studio Firebase handlers
  const handleUpdateSecrets = (next: StudioSecrets) => {
    const saved = saveSecrets(next);
    setSecrets(saved);
  };

  const handleTestStudioFirebase = async (candidate: StudioSecrets) => {
    const res = await syncStudioFirebase(candidate.studioFirebase, 'push', {
      vault: vault.slice(0, 20),
      activeJobId,
      language: lang,
      mapFooter: mapState.footerText,
    });
    const next: StudioSecrets = {
      ...candidate,
      studioFirebase: {
        ...candidate.studioFirebase,
        status: res.connected ? 'connected' : 'error',
        lastSyncedAt: res.syncedAt,
        lastError: res.connected ? undefined : res.error,
      },
    };
    handleUpdateSecrets(next);
    showToast(res.connected ? 'Studio Firebase connected & synced.' : `Studio Firebase error: ${res.error}`);
  };

  const handlePullStudioFirebase = async () => {
    const res = await syncStudioFirebase(secrets.studioFirebase, 'pull');
    if (res.ok && res.data) {
      if (Array.isArray(res.data.vault)) setVault(res.data.vault);
      if (res.data.activeJobId !== undefined) setActiveJobId(res.data.activeJobId);
      if (res.data.language) setLang(res.data.language);
      showToast('Pulled latest records from Studio Firebase.');
    } else {
      showToast(res.error || 'No remote studio records found yet.');
    }
  };

  // Skills handlers
  const handleToggleSkill = (id: string) => {
    setSkills((prev) => {
      const next = prev.map((sk) => (sk.id === id ? { ...sk, enabled: !sk.enabled } : sk));
      saveSkills(next);
      return next;
    });
  };

  const handleBulkToggleSkills = (category: 'pipeline' | 'capability', enabled: boolean) => {
    setSkills((prev) => {
      const next = prev.map((sk) => (sk.category === category ? { ...sk, enabled } : sk));
      saveSkills(next);
      return next;
    });
  };

  const handleSaveWorkflowTemplate = (
    engine: EngineType,
    filePath: string,
    templateYaml: string
  ) => {
    setWorkflowTemplates((prev) => updateWorkflowTemplate(prev, engine, { filePath, templateYaml }));
    showToast(`Updated ${engine === 'flutter' ? 'Flutter' : 'Godot 4'} GitHub Actions workflow template.`);
  };

  const handleResetWorkflowTemplate = (engine: EngineType) => {
    setWorkflowTemplates((prev) => resetWorkflowTemplate(prev, engine));
    showToast(`Reset ${engine === 'flutter' ? 'Flutter' : 'Godot 4'} workflow YAML to default boilerplate.`);
  };

  // Admin controls update
  const handleUpdateAdminControls = (jobId: string, nextControls: AdminBuildControls) => {
    updateJob(jobId, (j) => ({ ...j, adminControls: nextControls }));
  };

  const handleDeleteVaultJob = (jobId: string) => {
    setVault((prev) => prev.filter((j) => j.id !== jobId));
    if (activeJobId === jobId) setActiveJobId(null);
    if (adminBuildId === jobId) setAdminBuildId(null);
  };

  const navItems: Array<{ id: StudioTab; label: string; icon: React.ReactNode }> = [
    { id: 'copilot', label: s.tabs.copilot, icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'build', label: s.tabs.build, icon: <Hammer className="w-4 h-4" /> },
    { id: 'vault', label: s.tabs.vault, icon: <Archive className="w-4 h-4" /> },
    { id: 'admin', label: s.tabs.admin, icon: <Shield className="w-4 h-4" /> },
    { id: 'skills', label: s.tabs.skills, icon: <Sliders className="w-4 h-4" /> },
    { id: 'secrets', label: s.tabs.secrets, icon: <KeyRound className="w-4 h-4" /> },
  ];

  const handleBuildPromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isJobRunning) return;
    startNewBuild(promptInput);
  };

  const handleLiveSimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveSimInput.trim()) return;
    handleCoPilotOrLiveInput(liveSimInput.trim(), true);
    setLiveSimInput('');
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col">
      {/* Compact Global Header (Single Row) */}
      <header className="sticky top-0 z-30 bg-[#070B14]/95 backdrop-blur border-b border-slate-800/90">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          {/* Brand Logo + Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('build')}
            className="flex items-center gap-2.5 shrink-0 cursor-pointer text-left"
          >
            <svg
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
              aria-hidden="true"
              className="shrink-0"
            >
              <rect x="1" y="1" width="26" height="26" rx="7" fill="#0E1525" stroke="#1E293B" strokeWidth="1.5" />
              <path d="M8 10.5L14 7L20 10.5V17.5L14 21L8 17.5V10.5Z" stroke="#06B6D4" strokeWidth="1.75" />
              <circle cx="14" cy="14" r="2.25" fill="#06B6D4" />
            </svg>
            <span className="text-sm sm:text-base font-bold tracking-tight text-slate-100 whitespace-nowrap">
              {s.brand}
            </span>
          </button>

          {/* Desktop 6-Tab Navigation */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="Studio Sections">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`min-h-[38px] px-3.5 rounded-lg text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                    active
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.id === 'vault' && vault.length > 0 && (
                    <span className="font-mono tabular-nums text-[10px] text-slate-400">
                      ({vault.length})
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Global English | Hindi Toggle */}
          <div
            className="flex items-center p-0.5 rounded-lg bg-[#0E1525] border border-slate-800 shrink-0"
            role="group"
            aria-label="Language"
          >
            <button
              type="button"
              onClick={() => setLang('en')}
              className={`min-h-[34px] px-2.5 rounded-md text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                lang === 'en' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLang('hi')}
              className={`min-h-[34px] px-2.5 rounded-md text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                lang === 'hi' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              हिंदी
            </button>
          </div>
        </div>

        {/* Mobile / Tablet Scrollable Tab Bar */}
        <nav
          className="lg:hidden border-t border-slate-800/80 px-2 py-1.5 flex items-center gap-1 overflow-x-auto"
          aria-label="Mobile Studio Sections"
        >
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`min-h-[38px] px-3 rounded-lg text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  active
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 pt-4 pb-28">
        {toast && (
          <div className="mb-4 px-4 py-2.5 rounded-lg bg-[#0E1525] border border-cyan-500/40 text-xs text-cyan-200 flex items-center justify-between gap-2">
            <span>{toast}</span>
            <button
              type="button"
              onClick={() => setToast('')}
              className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {activeTab === 'copilot' && (
          <CoPilotView
            messages={messages}
            lang={lang}
            liveOn={liveOn}
            liveInterim={liveInterim}
            liveStatus={liveStatus}
            activeTab={activeTab}
            activeJob={activeJob}
            mapState={mapState}
            health={health}
            isThinking={isCopilotThinking}
            onSendMessage={(txt, viaLive) => handleCoPilotOrLiveInput(txt, viaLive)}
            onRunConnectBot={handleRunConnectBot}
            onOpenSecrets={() => setActiveTab('secrets')}
          />
        )}

        {activeTab === 'build' && (
          <div className="space-y-4">
            {/* Build Prompt Bar */}
            <form
              onSubmit={handleBuildPromptSubmit}
              className="bg-[#0E1525] border border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5"
            >
              <input
                type="text"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder={s.build.promptPlaceholder}
                disabled={isJobRunning}
                className="flex-1 min-h-[44px] px-3.5 rounded-lg bg-[#090E1A] border border-slate-800 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
              />
              <div className="flex items-center gap-2 shrink-0">
                <select
                  value={engineOverride}
                  onChange={(e) => setEngineOverride(e.target.value as 'auto' | EngineType)}
                  disabled={isJobRunning}
                  aria-label="Target Engine"
                  className="min-h-[44px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                >
                  <option value="auto">Auto Engine</option>
                  <option value="flutter">Flutter (App)</option>
                  <option value="godot4">Godot 4 (3D/Game)</option>
                </select>

                <button
                  type="submit"
                  disabled={isJobRunning || !promptInput.trim()}
                  className="min-h-[44px] px-5 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold text-sm flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer transition-colors"
                >
                  {isJobRunning ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{s.build.assembling}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      <span>{s.build.startBuild}</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Dual-Display Factory: Display A + Display B */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-stretch">
              <DisplayAAssembly
                job={activeJob}
                lang={lang}
                onStartQuickPrompt={(p) => startNewBuild(p)}
                onApplyFix={handleApplyFix}
                isBusy={isJobRunning}
              />
              <DisplayBSystemMap
                mapState={mapState}
                job={activeJob}
                lang={lang}
                onOpenSecrets={() => setActiveTab('secrets')}
              />
            </div>

            {/* Honest Secret-Driven Status Strip under Displays */}
            <div className="bg-[#0E1525] border border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-x-6 gap-y-2 text-xs">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono">
                <button
                  type="button"
                  onClick={() => setActiveTab('secrets')}
                  className="hover:underline cursor-pointer"
                >
                  <span className="text-slate-400">{s.statusStrip.github}: </span>
                  <span className={health.githubConnected ? 'text-emerald-400' : 'text-amber-300'}>
                    {health.githubConnected
                      ? `@${secrets.githubToken.username}`
                      : secrets.githubToken.status === 'invalid'
                        ? s.statusStrip.error
                        : s.statusStrip.notSet}
                  </span>
                </button>

                <span className="text-slate-700" aria-hidden="true">·</span>

                <button
                  type="button"
                  onClick={() => setActiveTab('secrets')}
                  className="hover:underline cursor-pointer"
                >
                  <span className="text-slate-400">{s.statusStrip.studioFb}: </span>
                  <span className={health.studioFirebaseConnected ? 'text-emerald-400' : 'text-slate-300'}>
                    {health.studioFirebaseConnected ? s.statusStrip.connected : s.statusStrip.notSet}
                  </span>
                </button>

                <span className="text-slate-700" aria-hidden="true">·</span>

                <button
                  type="button"
                  onClick={() => setActiveTab('secrets')}
                  className="hover:underline cursor-pointer"
                >
                  <span className="text-slate-400">{s.statusStrip.appsFb}: </span>
                  <span className={health.appsFirebaseConfigured ? 'text-emerald-400' : 'text-slate-300'}>
                    {health.appsFirebaseConfigured ? s.statusStrip.configured : s.statusStrip.notSet}
                  </span>
                </button>

                <span className="text-slate-700" aria-hidden="true">·</span>

                <button
                  type="button"
                  onClick={handleToggleLive}
                  className="hover:underline cursor-pointer"
                >
                  <span className="text-slate-400">{s.statusStrip.live}: </span>
                  <span className={liveOn ? 'text-cyan-400 font-semibold' : 'text-slate-400'}>
                    {liveOn ? s.statusStrip.on : s.statusStrip.off}
                  </span>
                </button>
              </div>

              {activeJob?.exportArtifacts.adminFinalUrl && (
                <button
                  type="button"
                  onClick={() => {
                    setAdminBuildId(activeJob.id);
                    setActiveTab('vault');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                >
                  View APK &amp; Admin Links in Vault →
                </button>
              )}
            </div>
          </div>
        )}

        {activeTab === 'vault' && (
          <VaultView
            vault={vault}
            activeJobId={activeJobId}
            lang={lang}
            githubConnected={health.githubConnected}
            onResumeJob={(id) => {
              setActiveJobId(id);
              setActiveTab('build');
            }}
            onOpenAdminForJob={(id) => {
              setAdminBuildId(id);
              setActiveTab('admin');
            }}
            onPollGitHub={handlePollGitHub}
            onDeleteJob={handleDeleteVaultJob}
            onGoBuild={() => setActiveTab('build')}
          />
        )}

        {activeTab === 'admin' && (
          <AdminView
            vault={vault}
            selectedBuildId={adminBuildId}
            studioFirebaseConnected={health.studioFirebaseConnected}
            githubConnected={health.githubConnected}
            lang={lang}
            onSelectBuild={setAdminBuildId}
            onUpdateAdminControls={handleUpdateAdminControls}
            onPollGitHub={handlePollGitHub}
            onGoBuild={() => setActiveTab('build')}
          />
        )}

        {activeTab === 'skills' && (
          <SkillsView
            skills={skills}
            activeJob={activeJob}
            lang={lang}
            workflowTemplates={workflowTemplates}
            onToggleSkill={handleToggleSkill}
            onBulkToggle={handleBulkToggleSkills}
            onSaveWorkflowTemplate={handleSaveWorkflowTemplate}
            onResetWorkflowTemplate={handleResetWorkflowTemplate}
          />
        )}

        {activeTab === 'secrets' && (
          <SecretsView
            secrets={secrets}
            health={health}
            lang={lang}
            onUpdateSecrets={handleUpdateSecrets}
            onTestStudioFirebase={handleTestStudioFirebase}
            onPullStudioFirebase={handlePullStudioFirebase}
          />
        )}
      </main>

      {/* Bottom Factory Control Bar (Live | Cancel | OK | Home) + Slim Live Command Input when Live ON */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-[#070B14]/95 backdrop-blur border-t border-slate-800">
        {liveOn && (
          <div className="max-w-7xl mx-auto px-4 pt-2 pb-1 flex flex-col sm:flex-row sm:items-center gap-2 border-b border-slate-800/70">
            <div className="flex items-center gap-2 text-xs text-cyan-300 font-mono min-w-0 flex-1">
              <Mic className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">
                {liveInterim
                  ? `"${liveInterim}"`
                  : liveStatus || (lang === 'hi' ? 'लाइव कमांड सुन रहा है...' : 'Live call active — speak a command')}
              </span>
            </div>
            <form onSubmit={handleLiveSimSubmit} className="flex items-center gap-1.5 sm:w-80">
              <input
                type="text"
                value={liveSimInput}
                onChange={(e) => setLiveSimInput(e.target.value)}
                placeholder={lang === 'hi' ? 'या लाइव कमांड लिखें...' : 'Or type live command (e.g. Open Vault)'}
                className="flex-1 min-h-[34px] px-2.5 rounded-md bg-[#0E1525] border border-slate-700 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
              />
              <button
                type="submit"
                className="min-h-[34px] px-2.5 rounded-md bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 cursor-pointer"
                aria-label="Send Live Command"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}

        <div className="max-w-7xl mx-auto px-3 py-2 grid grid-cols-4 gap-2">
          {/* LIVE */}
          <button
            type="button"
            onClick={handleToggleLive}
            className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              liveOn
                ? 'bg-cyan-500 text-slate-950'
                : 'bg-[#0E1525] hover:bg-slate-800 border border-slate-800 text-slate-200'
            }`}
          >
            {liveOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-slate-400" />}
            <span>{liveOn ? s.bottomBar.liveOn : s.bottomBar.liveOff}</span>
          </button>

          {/* CANCEL */}
          <button
            type="button"
            onClick={handleCancelJob}
            disabled={!activeJob && !isJobRunning}
            className="min-h-[44px] rounded-lg bg-[#0E1525] hover:bg-rose-500/15 hover:border-rose-500/40 hover:text-rose-200 disabled:opacity-40 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <XCircle className="w-4 h-4" />
            <span>{s.bottomBar.cancel}</span>
          </button>

          {/* OK (Strictly disabled until Stage 5 Ready to test) */}
          <button
            type="button"
            onClick={handleOkExport}
            disabled={!canPressOk}
            title={canPressOk ? 'Proceed to Export & GitHub Actions APK' : s.build.okTooltipDisabled}
            className={`min-h-[44px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
              canPressOk
                ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer'
                : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{s.bottomBar.ok}</span>
          </button>

          {/* HOME */}
          <button
            type="button"
            onClick={handleGoHome}
            className="min-h-[44px] rounded-lg bg-[#0E1525] hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>{s.bottomBar.home}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
