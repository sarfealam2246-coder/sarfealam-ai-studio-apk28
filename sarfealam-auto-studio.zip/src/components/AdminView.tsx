import React, { useState } from 'react';
import {
  Bell,
  Check,
  Copy,
  Crown,
  Download,
  ExternalLink,
  Megaphone,
  RefreshCw,
  Shield,
} from 'lucide-react';
import type { AdminBuildControls, BuildJob, Language } from '../types/studio';

interface AdminViewProps {
  vault: BuildJob[];
  selectedBuildId: string | null;
  studioFirebaseConnected: boolean;
  githubConnected: boolean;
  lang: Language;
  onSelectBuild: (id: string) => void;
  onUpdateAdminControls: (jobId: string, next: AdminBuildControls) => void;
  onPollGitHub: (jobId: string) => Promise<void>;
  onGoBuild: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  vault,
  selectedBuildId,
  studioFirebaseConnected,
  githubConnected,
  lang,
  onSelectBuild,
  onUpdateAdminControls,
  onPollGitHub,
  onGoBuild,
}) => {
  const build = vault.find((b) => b.id === selectedBuildId) || vault[0] || null;
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [polling, setPolling] = useState(false);

  const copyText = (key: string, value: string) => {
    if (!value) return;
    navigator.clipboard?.writeText(value).catch(() => {});
    setCopiedField(key);
    setTimeout(() => setCopiedField(null), 1500);
  };

  if (!build) {
    return (
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-10 text-center flex flex-col items-center">
        <Shield className="w-8 h-8 text-slate-600 mb-3" />
        <h2 className="text-sm font-semibold text-slate-100">
          {lang === 'hi' ? 'एडमिन के लिए कोई बिल्ड चुना नहीं गया' : 'No Build Selected for Admin'}
        </h2>
        <p className="text-xs text-slate-400 max-w-sm mt-1">
          {lang === 'hi'
            ? 'पहले Build टैब में कोई ऐप या गेम बनाएं। उसके बाद यहाँ APK लिंक, Admin लिंक और लाइव बैनर कंट्रोल मिलेंगे।'
            : 'Create an app or game in the Build tab first. Once assembled, its APK link, Admin final link, and live controls appear here.'}
        </p>
        <button
          type="button"
          onClick={onGoBuild}
          className="mt-4 min-h-[42px] px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer"
        >
          {lang === 'hi' ? 'Build टैब पर जाएं' : 'Open Build Tab'}
        </button>
      </div>
    );
  }

  const controls = build.adminControls;

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifBody.trim()) return;
    const entry = {
      id: `notif-${Date.now()}`,
      title: notifTitle.trim(),
      body: notifBody.trim(),
      sentAt: new Date().toISOString(),
    };
    onUpdateAdminControls(build.id, {
      ...controls,
      notifications: [entry, ...controls.notifications].slice(0, 15),
    });
    setNotifTitle('');
    setNotifBody('');
  };

  const handlePoll = async () => {
    setPolling(true);
    try {
      await onPollGitHub(build.id);
    } finally {
      setPolling(false);
    }
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Selected Build Header */}
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            {lang === 'hi' ? 'बिल्ड एडमिन कंट्रोल' : 'Build Admin Console'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Persistence:{' '}
            <span className={studioFirebaseConnected ? 'text-emerald-400' : 'text-amber-300'}>
              {studioFirebaseConnected
                ? 'Studio Firebase Synced'
                : 'Local Studio State (mock push until Apps Firebase + FCM wired)'}
            </span>
          </p>
        </div>

        <select
          value={build.id}
          onChange={(e) => onSelectBuild(e.target.value)}
          className="min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-700 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
        >
          {vault.map((item) => (
            <option key={item.id} value={item.id}>
              {item.title} ({item.engine === 'godot4' ? 'Godot 4' : 'Flutter'} · {item.status})
            </option>
          ))}
        </select>
      </div>

      {/* Delivery Links Panel (APK Link + Admin Final Link) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Download className="w-4 h-4 text-cyan-400" />
              Apps APK Download Link
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {build.exportArtifacts.apkStatus}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={
                build.exportArtifacts.apkUrl ||
                (build.exportArtifacts.repoUrl
                  ? 'Building in GitHub Actions — tap Poll APK'
                  : 'Not yet published — run OK export on Build tab')
              }
              className="flex-1 min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-200"
            />
            {build.exportArtifacts.apkUrl && (
              <>
                <button
                  type="button"
                  onClick={() => copyText('apk', build.exportArtifacts.apkUrl || '')}
                  className="min-h-[40px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copiedField === 'apk' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <a
                  href={build.exportArtifacts.apkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[40px] px-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1"
                >
                  Open <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </>
            )}
          </div>

          {build.exportArtifacts.repoUrl && githubConnected && (
            <div className="flex items-center justify-between pt-1 text-xs">
              <a
                href={build.exportArtifacts.actionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-cyan-300 font-mono truncate"
              >
                {build.exportArtifacts.repoOwner}/{build.exportArtifacts.repoName}
              </a>
              <button
                type="button"
                onClick={handlePoll}
                disabled={polling}
                className="px-2.5 py-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/40 text-cyan-200 font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${polling ? 'animate-spin' : ''}`} />
                Poll Actions APK
              </button>
            </div>
          )}
        </div>

        <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-cyan-400" />
              Admin Final Link
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {build.exportArtifacts.appsFirebaseInjected ? 'Apps FB Ready' : 'Local Mode'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={build.exportArtifacts.adminFinalUrl || `${window.location.origin}/#admin/${build.id}`}
              className="flex-1 min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-cyan-300"
            />
            <button
              type="button"
              onClick={() =>
                copyText(
                  'admin',
                  build.exportArtifacts.adminFinalUrl || `${window.location.origin}/#admin/${build.id}`
                )
              }
              className="min-h-[40px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 cursor-pointer"
            >
              {copiedField === 'admin' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy
            </button>
          </div>
          <p className="text-[11px] text-slate-500">
            Changes below save to this build and feed directly into Display A preview and exported `admin_config.dart`.
          </p>
        </div>
      </div>

      {/* Operational Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Banner + VIP Plan Note */}
        <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-slate-100">In-App Banner Control</h3>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateAdminControls(build.id, {
                  ...controls,
                  bannerEnabled: !controls.bannerEnabled,
                })
              }
              className={`min-h-[36px] px-3.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                controls.bannerEnabled
                  ? 'bg-cyan-500 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {controls.bannerEnabled ? 'Banner ON' : 'Banner OFF'}
            </button>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Banner Announcement Copy</label>
            <input
              type="text"
              value={controls.bannerText}
              onChange={(e) =>
                onUpdateAdminControls(build.id, {
                  ...controls,
                  bannerText: e.target.value,
                })
              }
              className="w-full min-h-[42px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <Crown className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-slate-100">VIP / Plan Note</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-2">
                <label className="block text-xs text-slate-400 mb-1">VIP Plan Note</label>
                <input
                  type="text"
                  value={controls.vipNote}
                  onChange={(e) =>
                    onUpdateAdminControls(build.id, {
                      ...controls,
                      vipNote: e.target.value,
                    })
                  }
                  className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Price Label</label>
                <input
                  type="text"
                  value={controls.vipPriceLabel}
                  onChange={(e) =>
                    onUpdateAdminControls(build.id, {
                      ...controls,
                      vipPriceLabel: e.target.value,
                    })
                  }
                  className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Notification Composer (Honest Local Mock) */}
        <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-slate-100">Notification Composer</h3>
            </div>
            <span className="text-[11px] font-mono text-amber-300">Local Mock Queue</span>
          </div>

          <form onSubmit={handleSendNotification} className="space-y-2.5">
            <input
              type="text"
              value={notifTitle}
              onChange={(e) => setNotifTitle(e.target.value)}
              placeholder="Notification title (e.g., Weekend Offer Live)"
              className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <textarea
              rows={2}
              value={notifBody}
              onChange={(e) => setNotifBody(e.target.value)}
              placeholder="Message body for app users..."
              className="w-full p-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none resize-none"
            />
            <button
              type="submit"
              disabled={!notifTitle.trim() || !notifBody.trim()}
              className="min-h-[40px] px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold text-xs cursor-pointer"
            >
              Queue Local Notification
            </button>
          </form>

          <div className="pt-2 border-t border-slate-800 space-y-2 max-h-40 overflow-y-auto">
            {controls.notifications.length === 0 ? (
              <p className="text-xs text-slate-500">No notifications queued for this build yet.</p>
            ) : (
              controls.notifications.map((n) => (
                <div key={n.id} className="p-2.5 rounded-lg bg-[#090E1A] border border-slate-800/80 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-slate-200">{n.title}</span>
                    <span className="font-mono text-[10px] text-slate-500 tabular-nums">
                      {new Date(n.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-slate-400 mt-0.5">{n.body}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
