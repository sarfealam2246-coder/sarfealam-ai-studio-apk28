import React, { useEffect, useRef, useState } from 'react';
import {
  Send,
  Volume2,
  Mic,
  Stethoscope,
  ArrowRight,
  Wrench,
} from 'lucide-react';
import type {
  BuildJob,
  CoPilotMessage,
  Language,
  SecretsHealth,
  StudioTab,
  SystemMapState,
} from '../types/studio';
import { t } from '../i18n/strings';
import { speakText } from '../modules/voiceLive';

interface CoPilotViewProps {
  messages: CoPilotMessage[];
  lang: Language;
  liveOn: boolean;
  liveInterim: string;
  liveStatus: string;
  activeTab: StudioTab;
  activeJob: BuildJob | null;
  mapState: SystemMapState;
  health: SecretsHealth;
  isThinking: boolean;
  onSendMessage: (text: string, viaLive?: boolean) => void;
  onRunConnectBot: () => void;
  onOpenSecrets: () => void;
}

export const CoPilotView: React.FC<CoPilotViewProps> = ({
  messages,
  lang,
  liveOn,
  liveInterim,
  liveStatus,
  activeTab,
  activeJob,
  mapState,
  health,
  isThinking,
  onSendMessage,
  onRunConnectBot,
  onOpenSecrets,
}) => {
  const s = t(lang);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isThinking]);

  const activeChipLabel =
    mapState.chips.find((c) => c.status === 'active')?.label ||
    (activeJob?.activeChipId
      ? mapState.chips.find((c) => c.id === activeJob.activeChipId)?.label
      : null) ||
    'Idle';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isThinking) return;
    onSendMessage(input.trim(), false);
    setInput('');
  };

  return (
    <div className="flex flex-col gap-4 pb-6">
      {/* Screen-Awareness Context Strip (unboxed clean metadata, no pill soup) */}
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-400">
          <span className="font-medium text-slate-200">
            {lang === 'hi' ? 'स्क्रीन अवेयरनेस' : 'Screen Awareness'}
          </span>
          <span aria-hidden="true">·</span>
          <span>Tab: {activeTab}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">
            Stage {activeJob?.stageIndex ?? 0}/5
          </span>
          <span aria-hidden="true">·</span>
          <span>Chip: {activeChipLabel}</span>
          <span aria-hidden="true">·</span>
          <span className={health.issues.length > 0 ? 'text-amber-300' : 'text-emerald-400'}>
            {health.issues.length > 0
              ? `${health.issues.length} secret alert${health.issues.length > 1 ? 's' : ''}`
              : 'Secrets healthy'}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onRunConnectBot}
            className="min-h-[36px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Stethoscope className="w-3.5 h-3.5 text-cyan-400" />
            {s.copilot.diagnoseSecrets}
          </button>
          {health.issues.length > 0 && (
            <button
              type="button"
              onClick={onOpenSecrets}
              className="min-h-[36px] px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-xs font-medium text-cyan-200 flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Wrench className="w-3.5 h-3.5" />
              Secrets
            </button>
          )}
        </div>
      </div>

      {/* Live Call-Style Banner */}
      <div
        className={`rounded-xl border px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs ${
          liveOn
            ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-100'
            : 'bg-[#0E1525] border-slate-800 text-slate-400'
        }`}
      >
        <div className="flex items-start gap-2.5">
          <Mic className={`w-4 h-4 shrink-0 mt-0.5 ${liveOn ? 'text-cyan-400' : 'text-slate-500'}`} />
          <div>
            <div className="font-medium text-slate-100">
              {liveOn ? s.copilot.liveActiveHint : s.copilot.liveInactiveHint}
            </div>
            {liveOn && (liveInterim || liveStatus) && (
              <div className="font-mono text-[11px] text-cyan-300 mt-1">
                {liveInterim ? `Heard: "${liveInterim}"` : liveStatus}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Conversation Feed */}
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl flex flex-col min-h-[380px] max-h-[54vh]">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[90%] sm:max-w-[78%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-cyan-500/15 border border-cyan-500/35 text-slate-100'
                      : 'bg-[#090E1A] border border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.text}</div>

                  {msg.actionTaken && (
                    <div className="mt-2 pt-2 border-t border-slate-800/80 text-xs font-mono text-cyan-300 flex items-center gap-1.5">
                      <ArrowRight className="w-3.5 h-3.5 shrink-0" />
                      <span>{msg.actionTaken}</span>
                    </div>
                  )}

                  <div className="mt-2 flex items-center justify-between gap-4 text-[11px] text-slate-500">
                    <span className="font-mono tabular-nums truncate">
                      {msg.viaLive ? 'Live Voice · ' : ''}
                      {msg.sourceLabel || (isUser ? 'You' : 'Co-Pilot')}
                      {' · '}
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {!isUser && (
                      <button
                        type="button"
                        onClick={() => speakText(msg.text, lang)}
                        className="text-slate-400 hover:text-cyan-300 flex items-center gap-1 shrink-0 cursor-pointer transition-colors"
                        title={s.copilot.speak}
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{s.copilot.speak}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isThinking && (
            <div className="flex items-start">
              <div className="rounded-xl px-4 py-3 bg-[#090E1A] border border-slate-800 text-xs font-mono text-cyan-300">
                {lang === 'hi' ? 'को-पायलट टीम से जुड़ रहा है...' : 'Routing through AI team...'}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick Command Suggestions */}
        <div className="px-4 py-2.5 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
          {s.copilot.quickPrompts.map((qp) => (
            <button
              key={qp}
              type="button"
              onClick={() => onSendMessage(qp, false)}
              disabled={isThinking}
              className="px-3 py-1.5 min-h-[34px] rounded-lg bg-[#090E1A] hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Typed Chat Input */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={s.copilot.placeholder}
            className="flex-1 min-h-[44px] px-3.5 rounded-lg bg-[#090E1A] border border-slate-800 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || isThinking}
            className="min-h-[44px] px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold text-sm flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>{s.copilot.send}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
