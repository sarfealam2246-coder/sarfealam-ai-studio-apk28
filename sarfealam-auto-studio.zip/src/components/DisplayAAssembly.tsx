import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Cpu,
  Gauge,
  Loader2,
  Play,
  ShieldCheck,
  Smartphone,
  Gamepad2,
  AlertTriangle,
  Sparkles,
  Search,
  Wallet,
  Crown,
  MapPin,
  Lock,
} from 'lucide-react';
import type { BuildJob, Language } from '../types/studio';
import { t } from '../i18n/strings';

interface DisplayAAssemblyProps {
  job: BuildJob | null;
  lang: Language;
  onStartQuickPrompt: (prompt: string) => void;
  onApplyFix: (fixPrompt: string) => void;
  isBusy: boolean;
}

export const DisplayAAssembly: React.FC<DisplayAAssemblyProps> = ({
  job,
  lang,
  onStartQuickPrompt,
  onApplyFix,
  isBusy,
}) => {
  const s = t(lang);
  const [activePreviewTab, setActivePreviewTab] = useState(0);
  const [fixInput, setFixInput] = useState('');

  // Interactive App Test State (Stage 5)
  const [walletBalance, setWalletBalance] = useState(12480);
  const [vipUnlocked, setVipUnlocked] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookingConfirmed, setBookingConfirmed] = useState<string | null>(null);
  const [testActionLog, setTestActionLog] = useState<string>('');

  // Interactive Card-Table Test State (Stage 5)
  const [cardPot, setCardPot] = useState(2400);
  const [cardHand, setCardHand] = useState<string[]>(['A♠', 'K♦', 'Q♠']);
  const [cardRound, setCardRound] = useState(1);

  // Interactive Racing / Arcade Canvas Game State (Stage 5)
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameControlsRef = useRef({ left: false, right: false, gas: false, brake: false });
  const [hudSpeed, setHudSpeed] = useState(0);
  const [hudScore, setHudScore] = useState(0);

  // Reset preview local state when switching job
  useEffect(() => {
    setActivePreviewTab(0);
    setBookingConfirmed(null);
    setTestActionLog('');
    setSearchQuery('');
  }, [job?.id]);

  const stage = job?.stageIndex ?? 0;
  const isGame = job?.productType === 'game';
  const isCardGame = isGame && job?.blueprint.gameGenre === 'card-table';
  const isInteractiveGame = isGame && !isCardGame && stage >= 4;
  const canInteract = stage >= 5;

  // Real 60fps HTML5 Canvas game loop for Godot 4 racing/arcade preview
  useEffect(() => {
    if (!isInteractiveGame) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let carX = 140;
    let speed = stage >= 5 ? 48 : 32;
    let roadOffset = 0;
    let score = 0;
    const obstacles = [
      { x: 95, y: -40, w: 28, h: 42 },
      { x: 185, y: -160, w: 28, h: 42 },
    ];
    let frameCount = 0;

    const tick = () => {
      const ctrl = gameControlsRef.current;
      if (canInteract) {
        if (ctrl.gas) speed = Math.min(speed + 2.4, 210);
        else if (ctrl.brake) speed = Math.max(speed - 3.8, 0);
        else speed = Math.max(speed - 0.6, 28);

        if (ctrl.left) carX = Math.max(46, carX - 3.6);
        if (ctrl.right) carX = Math.min(234, carX + 3.6);
      } else {
        // Stage 4 preview auto-cruise
        speed = 64;
        carX = 140 + Math.sin(frameCount * 0.04) * 35;
      }

      roadOffset = (roadOffset + speed * 0.08) % 36;
      score += Math.round(speed * 0.04);

      // Background dark track
      ctx.fillStyle = '#090E1A';
      ctx.fillRect(0, 0, 280, 176);

      // Track surface
      ctx.fillStyle = '#111A2E';
      ctx.fillRect(36, 0, 208, 176);

      // Track edges
      ctx.fillStyle = '#06B6D4';
      ctx.fillRect(36, 0, 3, 176);
      ctx.fillRect(241, 0, 3, 176);

      // Dashed lane dividers
      ctx.fillStyle = '#334155';
      for (let y = -36 + roadOffset; y < 180; y += 36) {
        ctx.fillRect(105, y, 3, 18);
        ctx.fillRect(172, y, 3, 18);
      }

      // Obstacles
      ctx.fillStyle = '#F59E0B';
      for (const ob of obstacles) {
        ob.y += Math.max(1.5, speed * 0.045);
        if (ob.y > 190) {
          ob.y = -50 - Math.random() * 80;
          ob.x = 56 + Math.floor(Math.random() * 3) * 66;
        }
        ctx.fillRect(ob.x - ob.w / 2, ob.y, ob.w, ob.h);
        // Collision check
        if (
          Math.abs(carX - ob.x) < 22 &&
          ob.y + ob.h > 122 &&
          ob.y < 160
        ) {
          speed = Math.max(18, speed * 0.5);
          ob.y = -70;
        }
      }

      // Player vehicle
      ctx.fillStyle = '#06B6D4';
      ctx.fillRect(carX - 13, 124, 26, 38);
      ctx.fillStyle = '#E0F2FE';
      ctx.fillRect(carX - 9, 132, 18, 10);

      frameCount++;
      if (frameCount % 6 === 0) {
        setHudSpeed(Math.round(speed));
        setHudScore(score);
      }

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, [isInteractiveGame, canInteract, stage]);

  const handleDealCards = () => {
    const ranks = ['A', 'K', 'Q', 'J', '10', '9', '8'];
    const suits = ['♠', '♥', '♦', '♣'];
    const nextHand = Array.from({ length: 3 }, () => {
      const r = ranks[Math.floor(Math.random() * ranks.length)];
      const su = suits[Math.floor(Math.random() * suits.length)];
      return `${r}${su}`;
    });
    setCardHand(nextHand);
    setCardPot((p) => p + 400);
    setCardRound((r) => r + 1);
    setTestActionLog(`Dealt round #${cardRound + 1} · Pot updated`);
  };

  const hasSkill = (id: string) => Boolean(job?.matchedSkills.includes(id));

  const stagesList = job?.stages || [
    { index: 1 as const, key: 'shell' as const, label: 'Shell', labelHi: 'शेल', status: 'pending' as const },
    { index: 2 as const, key: 'screens' as const, label: 'Screens / World', labelHi: 'स्क्रीन्स / वर्ल्ड', status: 'pending' as const },
    { index: 3 as const, key: 'hero' as const, label: 'Hero / Main UI', labelHi: 'हीरो / मुख्य UI', status: 'pending' as const },
    { index: 4 as const, key: 'controls' as const, label: 'Controls / HUD', labelHi: 'कंट्रोल्स / HUD', status: 'pending' as const },
    { index: 5 as const, key: 'ready' as const, label: 'Ready to test', labelHi: 'टेस्ट के लिए तैयार', status: 'pending' as const },
  ];

  const handleFixSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fixInput.trim() || isBusy) return;
    onApplyFix(fixInput.trim());
    setFixInput('');
  };

  const filteredItems = (job?.blueprint.items || []).filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return item.title.toLowerCase().includes(q) || item.subtitle.toLowerCase().includes(q);
  });

  return (
    <section className="flex flex-col bg-[#0E1525] border border-slate-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-800/90">
        <div className="flex items-center gap-2 min-w-0">
          {isGame ? (
            <Gamepad2 className="w-4 h-4 text-cyan-400 shrink-0" />
          ) : (
            <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
          )}
          <h2 className="text-sm font-semibold text-slate-100 truncate">{s.build.displayATitle}</h2>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono tabular-nums text-slate-400 shrink-0">
          <span>{job ? (job.engine === 'godot4' ? 'Godot 4' : 'Flutter') : 'Standby'}</span>
          <span aria-hidden="true">·</span>
          <span className={stage >= 5 ? 'text-emerald-400' : 'text-cyan-400'}>{stage}/5</span>
        </div>
      </div>

      {/* 5-Stage Assembly Rail */}
      <div className="grid grid-cols-5 gap-1 px-3 py-2.5 bg-[#090E1A] border-b border-slate-800/80">
        {stagesList.map((st) => {
          const isDone = st.status === 'done';
          const isActive = st.status === 'active';
          const isErr = st.status === 'error';
          return (
            <div
              key={st.index}
              className={`flex flex-col items-center justify-center px-1.5 py-1.5 rounded-lg text-center transition-colors ${
                isActive
                  ? 'bg-cyan-500/15 border border-cyan-500/50 text-cyan-200'
                  : isDone
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                    : isErr
                      ? 'bg-rose-500/10 border border-rose-500/40 text-rose-300'
                      : 'bg-slate-900/60 border border-slate-800/80 text-slate-500'
              }`}
            >
              <div className="flex items-center gap-1 text-[11px] font-mono tabular-nums font-semibold">
                {isDone ? (
                  <Check className="w-3 h-3 text-emerald-400" />
                ) : isActive ? (
                  <Loader2 className="w-3 h-3 text-cyan-400 animate-spin" />
                ) : (
                  <span>{st.index}</span>
                )}
              </div>
              <span className="text-[10px] leading-tight mt-0.5 truncate w-full">
                {lang === 'hi' ? st.labelHi : st.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Honest Demo Banner if built without AI keys */}
      {job?.isDemoMode && (
        <div className="flex items-start gap-2 px-4 py-2 bg-amber-500/10 border-b border-amber-500/25 text-xs text-amber-200">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
          <span>{s.build.demoModeBanner}</span>
        </div>
      )}

      {/* Stage 5 Interactive Ready Notice */}
      {job?.status === 'testing' && (
        <div className="flex items-center justify-between gap-2 px-4 py-2 bg-cyan-500/10 border-b border-cyan-500/25 text-xs text-cyan-200">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            {s.build.readyToTestBanner}
          </span>
        </div>
      )}

      {/* Live Preview Viewport — NEVER an empty void */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-4 min-h-[340px]">
        {!job ? (
          /* Calm Build Home State */
          <div className="flex-1 flex flex-col items-center justify-center text-center py-6 px-4 bg-[#090E1A] rounded-xl border border-slate-800/80">
            <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-3">
              <Cpu className="w-5 h-5 text-cyan-400" />
            </div>
            <h3 className="text-base font-semibold text-slate-100">
              {lang === 'hi' ? 'असेंबली लाइन तैयार है' : 'Assembly Line Ready'}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1.5 leading-relaxed">
              {lang === 'hi'
                ? 'ऊपर अपना ऐप या गेम आइडिया लिखें या Live ON करके बोलें। Display A पर 5 स्टेज में लाइव प्रीव्यू बनेगा।'
                : 'Enter an app or game prompt above or turn Live ON to command by voice. Display A will assemble live across 5 stages.'}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
              <button
                type="button"
                onClick={() =>
                  onStartQuickPrompt('Ride booking app with wallet balance, OTP login, VIP unlock & Hindi support')
                }
                className="px-3 py-2 min-h-[40px] rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                Flutter · Booking + Wallet
              </button>
              <button
                type="button"
                onClick={() =>
                  onStartQuickPrompt('3D highway drift car racing game with touch steering, gas & brake')
                }
                className="px-3 py-2 min-h-[40px] rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                Godot 4 · 3D Drift Racer
              </button>
              <button
                type="button"
                onClick={() => onStartQuickPrompt('Multiplayer Teen Patti & Rummy card table game with pot chips')}
                className="px-3 py-2 min-h-[40px] rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                Godot 4 · Card Table
              </button>
            </div>
          </div>
        ) : (
          /* Active Device Assembly Frame */
          <div className="flex-1 flex flex-col bg-[#090E1A] rounded-xl border border-slate-800 overflow-hidden">
            {/* Stage 1+: Shell Top Bar */}
            <div className="flex items-center justify-between px-3.5 py-2.5 bg-[#0D1424] border-b border-slate-800/90">
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-100 truncate">
                  {job.blueprint.appName}
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  {job.blueprint.tagline}
                </div>
              </div>
              <div className="text-[11px] font-mono tabular-nums text-cyan-400 shrink-0">
                {job.engine === 'godot4' ? 'GODOT 4' : 'FLUTTER'}
              </div>
            </div>

            {/* Stage-by-Stage Body */}
            <div className="p-3.5 flex-1 flex flex-col gap-3">
              {/* Admin banner preview if enabled */}
              {stage >= 3 && job.adminControls.bannerEnabled && (
                <div className="px-3 py-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-[11px] text-cyan-200 flex items-center justify-between">
                  <span className="truncate">{job.adminControls.bannerText}</span>
                  <span className="font-mono text-[10px] text-cyan-400 shrink-0 ml-2">Admin Banner</span>
                </div>
              )}

              {stage === 1 && (
                <div className="flex-1 flex flex-col items-center justify-center py-8 text-center">
                  <Loader2 className="w-6 h-6 text-cyan-400 animate-spin mb-2" />
                  <p className="text-xs font-medium text-slate-200">
                    Stage 1 · Initializing {job.engine === 'godot4' ? 'Godot 4 Mobile Scene Shell' : 'Flutter Material 3 App Shell'}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    {job.matchedSkills.length} active skills bound to pipeline
                  </p>
                </div>
              )}

              {stage >= 2 && isCardGame && (
                /* Interactive Card-Table Game Preview */
                <div className="flex-1 flex flex-col justify-between gap-3">
                  <div className="rounded-xl bg-[#0B2922] border border-emerald-900/80 p-4 flex flex-col items-center justify-between min-h-[180px]">
                    <div className="flex items-center justify-between w-full text-[11px] font-mono tabular-nums text-emerald-200">
                      <span>ROUND #{cardRound}</span>
                      <span>POT: {cardPot.toLocaleString()} CHIPS</span>
                    </div>

                    {stage >= 3 ? (
                      <div className="flex items-center justify-center gap-2.5 my-3">
                        {cardHand.map((card, i) => (
                          <div
                            key={`${card}-${i}`}
                            className="w-12 h-16 rounded-lg bg-slate-100 text-slate-900 font-mono font-bold text-sm flex items-center justify-center shadow"
                          >
                            <span className={card.includes('♥') || card.includes('♦') ? 'text-rose-600' : 'text-slate-900'}>
                              {card}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-xs text-emerald-300/80 my-6">Stage 2 · Building felt table physics...</div>
                    )}

                    <div className="text-[11px] text-emerald-300/90">
                      {job.blueprint.gameGoal}
                    </div>
                  </div>

                  {stage >= 4 && (
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        disabled={!canInteract}
                        onClick={handleDealCards}
                        className="min-h-[42px] rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold text-xs transition-colors cursor-pointer"
                      >
                        Deal Hand
                      </button>
                      <button
                        type="button"
                        disabled={!canInteract}
                        onClick={() => {
                          setCardPot((p) => p + 250);
                          setTestActionLog('Raised pot +250 chips');
                        }}
                        className="min-h-[42px] rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-100 font-medium text-xs transition-colors cursor-pointer"
                      >
                        Raise +250
                      </button>
                      <button
                        type="button"
                        disabled={!canInteract}
                        onClick={() => {
                          setCardPot(500);
                          setTestActionLog('Folded — pot reset');
                        }}
                        className="min-h-[42px] rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 font-medium text-xs transition-colors cursor-pointer"
                      >
                        Fold
                      </button>
                    </div>
                  )}
                </div>
              )}

              {stage >= 2 && isGame && !isCardGame && (
                /* Interactive Godot 4 Racing / Arcade Preview */
                <div className="flex-1 flex flex-col justify-between gap-3">
                  <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-[#090E1A] flex flex-col items-center">
                    {/* HUD strip */}
                    <div className="w-full flex items-center justify-between px-3 py-1.5 bg-[#0D1424] border-b border-slate-800 text-[11px] font-mono tabular-nums">
                      <span className="flex items-center gap-1 text-cyan-400">
                        <Gauge className="w-3.5 h-3.5" />
                        {stage >= 4 ? `${hudSpeed} km/h` : 'World init'}
                      </span>
                      <span className="text-slate-300">SCORE {hudScore}</span>
                    </div>

                    {stage >= 4 ? (
                      <canvas
                        ref={canvasRef}
                        width={280}
                        height={176}
                        className="w-full max-w-[320px] h-[176px] block"
                      />
                    ) : (
                      <div className="h-[176px] flex flex-col items-center justify-center px-4 text-center">
                        <Play className="w-5 h-5 text-cyan-400 mb-2" />
                        <p className="text-xs text-slate-200 font-medium">
                          {stage === 2 ? 'Stage 2 · Generating 3D Track & Skybox' : 'Stage 3 · Spawning Hero Vehicle & Obstacles'}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Stage 4/5 On-screen Game Touch Controls: Steer / Gas / Brake */}
                  {stage >= 4 && (
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        disabled={!canInteract}
                        onPointerDown={() => (gameControlsRef.current.left = true)}
                        onPointerUp={() => (gameControlsRef.current.left = false)}
                        onPointerLeave={() => (gameControlsRef.current.left = false)}
                        className="min-h-[44px] rounded-lg bg-slate-800 active:bg-cyan-500 active:text-slate-950 disabled:opacity-40 text-slate-100 text-xs font-medium flex items-center justify-center gap-1 select-none cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                        Steer
                      </button>
                      <button
                        type="button"
                        disabled={!canInteract}
                        onPointerDown={() => (gameControlsRef.current.right = true)}
                        onPointerUp={() => (gameControlsRef.current.right = false)}
                        onPointerLeave={() => (gameControlsRef.current.right = false)}
                        className="min-h-[44px] rounded-lg bg-slate-800 active:bg-cyan-500 active:text-slate-950 disabled:opacity-40 text-slate-100 text-xs font-medium flex items-center justify-center gap-1 select-none cursor-pointer"
                      >
                        Steer
                        <ChevronRight className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        disabled={!canInteract}
                        onPointerDown={() => (gameControlsRef.current.gas = true)}
                        onPointerUp={() => (gameControlsRef.current.gas = false)}
                        onPointerLeave={() => (gameControlsRef.current.gas = false)}
                        className="min-h-[44px] rounded-lg bg-cyan-500 hover:bg-cyan-400 active:bg-cyan-300 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 text-xs font-bold select-none cursor-pointer"
                      >
                        GAS
                      </button>
                      <button
                        type="button"
                        disabled={!canInteract}
                        onPointerDown={() => (gameControlsRef.current.brake = true)}
                        onPointerUp={() => (gameControlsRef.current.brake = false)}
                        onPointerLeave={() => (gameControlsRef.current.brake = false)}
                        className="min-h-[44px] rounded-lg bg-rose-500/20 border border-rose-500/40 active:bg-rose-500 active:text-white disabled:opacity-40 text-rose-200 text-xs font-semibold select-none cursor-pointer"
                      >
                        BRAKE
                      </button>
                    </div>
                  )}
                </div>
              )}

              {stage >= 2 && !isGame && (
                /* Interactive Flutter App Preview */
                <div className="flex-1 flex flex-col justify-between gap-3">
                  {/* Stage 3+: Hero & KPI Summary */}
                  {stage >= 3 ? (
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg bg-[#0E1525] border border-slate-800">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-slate-100 truncate">
                              {job.blueprint.heroTitle}
                            </div>
                            <div className="text-xs text-slate-400 mt-0.5 line-clamp-2">
                              {job.blueprint.heroSubtitle}
                            </div>
                          </div>
                          {hasSkill('cap-vip-unlock') && (
                            <button
                              type="button"
                              disabled={!canInteract}
                              onClick={() => {
                                setVipUnlocked((v) => !v);
                                setTestActionLog(!vipUnlocked ? 'VIP plan unlocked in preview' : 'VIP plan locked');
                              }}
                              className="px-2.5 py-1.5 rounded-md bg-cyan-500/15 border border-cyan-500/40 text-[11px] font-medium text-cyan-300 shrink-0 flex items-center gap-1 cursor-pointer disabled:opacity-50"
                            >
                              <Crown className="w-3 h-3" />
                              {vipUnlocked ? 'VIP Active' : 'Unlock VIP'}
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3 mt-3 pt-2.5 border-t border-slate-800/80">
                          <div>
                            <div className="text-[11px] text-slate-500">{job.blueprint.primaryMetricLabel}</div>
                            <div className="text-sm font-mono font-semibold tabular-nums text-slate-100">
                              {hasSkill('cap-wallet')
                                ? `₹${walletBalance.toLocaleString()}`
                                : job.blueprint.primaryMetricValue}
                            </div>
                          </div>
                          <div>
                            <div className="text-[11px] text-slate-500">{job.blueprint.secondaryMetricLabel}</div>
                            <div className="text-sm font-mono font-semibold tabular-nums text-cyan-400">
                              {hasSkill('cap-otp-auth')
                                ? otpVerified
                                  ? 'OTP Verified'
                                  : 'OTP Ready'
                                : job.blueprint.secondaryMetricValue}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Search bar if cap-search is enabled & matched */}
                      {hasSkill('cap-search') && stage >= 4 && (
                        <div className="relative">
                          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={searchQuery}
                            disabled={!canInteract}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Test live filter..."
                            className="w-full pl-8 pr-3 py-2 rounded-lg bg-[#0E1525] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
                          />
                        </div>
                      )}

                      {/* Capability interactive buttons in Stage 4/5 */}
                      {stage >= 4 && (
                        <div className="flex flex-wrap gap-2">
                          {hasSkill('cap-wallet') && (
                            <button
                              type="button"
                              disabled={!canInteract}
                              onClick={() => {
                                setWalletBalance((b) => b + 500);
                                setTestActionLog('Wallet top-up +₹500 tested');
                              }}
                              className="px-3 py-2 min-h-[38px] rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-xs font-medium text-cyan-200 flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                            >
                              <Wallet className="w-3.5 h-3.5" />
                              +₹500 Top-Up
                            </button>
                          )}
                          {hasSkill('cap-otp-auth') && (
                            <button
                              type="button"
                              disabled={!canInteract}
                              onClick={() => {
                                setOtpVerified((v) => !v);
                                setTestActionLog(!otpVerified ? 'OTP 482910 verified' : 'OTP reset');
                              }}
                              className="px-3 py-2 min-h-[38px] rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                            >
                              <Lock className="w-3.5 h-3.5" />
                              {otpVerified ? 'Reset OTP' : 'Test OTP'}
                            </button>
                          )}
                          {hasSkill('cap-maps-booking') && (
                            <button
                              type="button"
                              disabled={!canInteract}
                              onClick={() => {
                                setBookingConfirmed('Confirmed · Captain assigned (ETA 4m)');
                                setTestActionLog('Booking flow confirmed');
                              }}
                              className="px-3 py-2 min-h-[38px] rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                            >
                              <MapPin className="w-3.5 h-3.5" />
                              Confirm Booking
                            </button>
                          )}
                        </div>
                      )}

                      {bookingConfirmed && (
                        <div className="text-xs text-emerald-300 font-medium px-2.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                          {bookingConfirmed}
                        </div>
                      )}

                      {/* List Items */}
                      <div className="divide-y divide-slate-800/80 border border-slate-800/80 rounded-lg bg-[#0E1525]">
                        {filteredItems.slice(0, 3).map((item, idx) => (
                          <button
                            key={idx}
                            type="button"
                            disabled={!canInteract}
                            onClick={() => setTestActionLog(`Opened "${item.title}" on tab ${job.blueprint.tabs[activePreviewTab] || 'Home'}`)}
                            className="w-full px-3 py-2.5 flex items-center justify-between gap-2 text-left hover:bg-slate-800/50 transition-colors cursor-pointer disabled:cursor-default"
                          >
                            <div className="min-w-0">
                              <div className="text-xs font-medium text-slate-100 truncate">{item.title}</div>
                              <div className="text-[11px] text-slate-400 truncate">{item.subtitle}</div>
                            </div>
                            <span className="text-xs font-mono tabular-nums text-cyan-400 shrink-0">
                              {item.meta}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center py-6 text-center">
                      <Loader2 className="w-5 h-5 text-cyan-400 animate-spin mb-2" />
                      <p className="text-xs text-slate-200">Stage 2 · Wiring navigation & screen routes...</p>
                    </div>
                  )}

                  {/* Stage 2+: Bottom Navigation inside Device Preview (honors cap-bottom-nav) */}
                  {hasSkill('cap-bottom-nav') && (
                    <div className="grid grid-cols-4 gap-1 pt-2 border-t border-slate-800">
                      {job.blueprint.tabs.map((tabLabel, idx) => (
                        <button
                          key={tabLabel}
                          type="button"
                          disabled={!canInteract}
                          onClick={() => {
                            setActivePreviewTab(idx);
                            setTestActionLog(`Preview tab → ${tabLabel}`);
                          }}
                          className={`min-h-[38px] rounded-lg text-[11px] font-medium transition-colors cursor-pointer disabled:cursor-default ${
                            activePreviewTab === idx
                              ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                              : 'text-slate-400 hover:text-slate-200 bg-slate-900/50'
                          }`}
                        >
                          {tabLabel}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {testActionLog && (
                <div className="text-[11px] font-mono text-cyan-300 flex items-center gap-1.5 pt-1">
                  <Sparkles className="w-3 h-3 shrink-0" />
                  <span className="truncate">{testActionLog}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Stage 5 Fix / Change Bar */}
        {job && (job.status === 'testing' || job.status === 'ready') && (
          <form onSubmit={handleFixSubmit} className="flex items-center gap-2">
            <input
              type="text"
              value={fixInput}
              onChange={(e) => setFixInput(e.target.value)}
              placeholder={s.build.fixPlaceholder}
              disabled={isBusy}
              className="flex-1 min-h-[42px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isBusy || !fixInput.trim()}
              className="min-h-[42px] px-4 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-medium text-slate-100 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
            >
              {s.build.applyFix}
            </button>
          </form>
        )}
      </div>
    </section>
  );
};
