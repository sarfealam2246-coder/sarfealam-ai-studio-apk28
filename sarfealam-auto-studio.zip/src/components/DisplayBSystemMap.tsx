import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  Check,
  GitBranch,
  KeyRound,
  Layers,
  Loader2,
  Network,
  Wrench,
} from 'lucide-react';
import type { BuildJob, Language, SystemMapChip, SystemMapState } from '../types/studio';
import { t } from '../i18n/strings';

interface DisplayBSystemMapProps {
  mapState: SystemMapState;
  job: BuildJob | null;
  lang: Language;
  onOpenSecrets: () => void;
}

export const DisplayBSystemMap: React.FC<DisplayBSystemMapProps> = ({
  mapState,
  job,
  lang,
  onOpenSecrets,
}) => {
  const s = t(lang);
  const [selectedChipId, setSelectedChipId] = useState<string | null>(null);

  const columns = useMemo(() => {
    const cols: Record<0 | 1 | 2 | 3, SystemMapChip[]> = { 0: [], 1: [], 2: [], 3: [] };
    for (const chip of mapState.chips) {
      cols[chip.column].push(chip);
    }
    return cols;
  }, [mapState.chips]);

  const selectedChip = useMemo(
    () => mapState.chips.find((c) => c.id === selectedChipId) || null,
    [mapState.chips, selectedChipId]
  );

  const hasAnyActiveLine = mapState.edges.some((e) => e.active);

  const chipStyles = (status: SystemMapChip['status']) => {
    switch (status) {
      case 'active':
        return 'bg-cyan-500/12 border-cyan-500 text-slate-100';
      case 'done':
        return 'bg-[#090E1A] border-emerald-500/45 text-slate-100';
      case 'warning':
        return 'bg-[#090E1A] border-amber-500/45 text-amber-100';
      case 'error':
        return 'bg-rose-500/10 border-rose-500/50 text-rose-100';
      case 'muted':
        return 'bg-[#090E1A]/70 border-slate-800/80 text-slate-500';
      default:
        return 'bg-[#090E1A] border-slate-700/80 text-slate-200';
    }
  };

  const renderStatusIcon = (status: SystemMapChip['status']) => {
    if (status === 'active') return <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin shrink-0" />;
    if (status === 'done') return <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
    if (status === 'error' || status === 'warning')
      return <AlertCircle className={`w-3.5 h-3.5 shrink-0 ${status === 'error' ? 'text-rose-400' : 'text-amber-400'}`} />;
    if (status === 'muted') return <KeyRound className="w-3 h-3 text-slate-600 shrink-0" />;
    return <Layers className="w-3 h-3 text-slate-400 shrink-0" />;
  };

  const columnMeta: Array<{ col: 0 | 1 | 2 | 3; title: string }> = [
    { col: 0, title: 'Intake' },
    { col: 1, title: 'AI Team' },
    { col: 2, title: 'Bots & QA' },
    { col: 3, title: 'Delivery' },
  ];

  const footerTone =
    mapState.footerState === 'sync'
      ? 'text-emerald-300 border-emerald-500/25 bg-emerald-500/5'
      : mapState.footerState === 'demo'
        ? 'text-amber-200 border-amber-500/25 bg-amber-500/5'
        : mapState.footerState === 'error'
          ? 'text-rose-300 border-rose-500/30 bg-rose-500/10'
          : 'text-slate-300 border-slate-800 bg-[#090E1A]';

  return (
    <section className="flex flex-col bg-[#0E1525] border border-slate-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-800/90">
        <div className="flex items-center gap-2 min-w-0">
          <Network className="w-4 h-4 text-cyan-400 shrink-0" />
          <h2 className="text-sm font-semibold text-slate-100 truncate">{s.build.displayBTitle}</h2>
        </div>
        <div className="text-xs font-mono text-slate-400 shrink-0 truncate max-w-[50%]">
          {job?.activeWorkCaption || (lang === 'hi' ? 'टीम सिंक में' : 'Dynamic key routing')}
        </div>
      </div>

      {/* Connected Pipeline Grid with Calm Flow Lines */}
      <div className="relative p-4 flex-1 flex flex-col justify-between gap-4 min-h-[340px]">
        {/* Calm Horizontal Pipeline Flow SVG Backbone (Desktop/Tablet) */}
        <svg
          aria-hidden="true"
          className="hidden sm:block absolute inset-x-4 top-1/2 -translate-y-1/2 w-[calc(100%-2rem)] h-28 pointer-events-none"
          viewBox="0 0 600 100"
          preserveAspectRatio="none"
        >
          <path
            d="M 85 50 C 135 50, 145 25, 195 25 M 85 50 C 135 50, 145 75, 195 75 M 310 25 C 350 25, 360 50, 400 50 M 310 75 C 350 75, 360 50, 400 50 M 470 50 L 530 22 M 470 50 L 530 50 M 470 50 L 530 78"
            fill="none"
            stroke={hasAnyActiveLine ? '#06B6D4' : '#1E293B'}
            strokeWidth={hasAnyActiveLine ? '1.75' : '1.25'}
            strokeOpacity={hasAnyActiveLine ? '0.65' : '0.8'}
            className={hasAnyActiveLine ? 'pipeline-line-active' : ''}
          />
        </svg>

        {/* 4 Pipeline Columns */}
        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 flex-1 items-start">
          {columnMeta.map(({ col, title }) => (
            <div key={col} className="flex flex-col gap-2">
              <div className="text-[11px] font-medium text-slate-500 px-0.5 flex items-center justify-between">
                <span>{title}</span>
                <span className="font-mono tabular-nums text-[10px] text-slate-600">{columns[col].length}</span>
              </div>

              {columns[col].map((chip) => {
                const isSelected = selectedChipId === chip.id;
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => setSelectedChipId(isSelected ? null : chip.id)}
                    className={`w-full text-left p-2.5 rounded-lg border transition-colors cursor-pointer ${chipStyles(
                      chip.status
                    )} ${isSelected ? 'ring-1 ring-cyan-400' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-xs font-semibold truncate">{chip.label}</span>
                      {renderStatusIcon(chip.status)}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 truncate">{chip.role}</div>
                    <div
                      className={`text-[11px] mt-1.5 leading-snug line-clamp-2 ${
                        chip.status === 'active'
                          ? 'text-cyan-300 font-medium'
                          : chip.status === 'error'
                            ? 'text-rose-300'
                            : chip.status === 'warning'
                              ? 'text-amber-300'
                              : chip.status === 'muted'
                                ? 'text-slate-500'
                                : 'text-slate-400'
                      }`}
                    >
                      {chip.caption}
                    </div>
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Selected Chip Inspector or Shared Context Strip */}
        {selectedChip ? (
          <div className="p-3 rounded-lg bg-[#090E1A] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="min-w-0">
              <div className="font-semibold text-slate-100 flex items-center gap-2">
                <span>{selectedChip.label}</span>
                <span className="text-slate-500 font-normal">·</span>
                <span className="text-slate-400 font-normal">{selectedChip.role}</span>
              </div>
              <p className="text-slate-400 mt-0.5">
                {selectedChip.reason || selectedChip.caption}
                {selectedChip.model ? ` (Model: ${selectedChip.model})` : ''}
              </p>
            </div>
            {(selectedChip.status === 'muted' || selectedChip.status === 'warning' || selectedChip.status === 'error') && (
              <button
                type="button"
                onClick={onOpenSecrets}
                className="min-h-[36px] px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-200 font-medium whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
              >
                <Wrench className="w-3.5 h-3.5" />
                Configure in Secrets
              </button>
            )}
          </div>
        ) : job && job.sharedContext.length > 0 ? (
          <div className="p-3 rounded-lg bg-[#090E1A] border border-slate-800/80">
            <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5">
              <span className="flex items-center gap-1.5 font-medium text-slate-400">
                <GitBranch className="w-3 h-3 text-cyan-400" />
                Shared Team Context Navigation
              </span>
              <span className="font-mono tabular-nums">{job.sharedContext.length} handoffs</span>
            </div>
            <div className="space-y-1 max-h-20 overflow-y-auto pr-1">
              {job.sharedContext.slice(-3).map((entry, idx) => (
                <div key={idx} className="text-[11px] text-slate-300 flex items-baseline gap-2">
                  <span className="font-mono text-cyan-400 shrink-0">S{entry.stage}</span>
                  <span className="font-medium text-slate-200 shrink-0">{entry.worker}:</span>
                  <span className="text-slate-400 truncate">{entry.note}</span>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {/* Honest System Map Footer */}
      <div className={`px-4 py-2.5 border-t text-xs font-mono tabular-nums flex items-center justify-between gap-2 ${footerTone}`}>
        <span className="truncate">{mapState.footerText}</span>
        {job && job.fallbackEvents.length > 0 && (
          <span className="text-amber-300 shrink-0">Fallback ×{job.fallbackEvents.length}</span>
        )}
      </div>
    </section>
  );
};
