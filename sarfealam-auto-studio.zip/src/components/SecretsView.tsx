import React, { useState } from 'react';
import {
  CheckCircle2,
  Database,
  Eye,
  EyeOff,
  GitBranch,
  KeyRound,
  Loader2,
  Mic,
  Plus,
  Save,
  Server,
  Trash2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import type {
  AIProviderId,
  ApiKeySlot,
  KeyTag,
  Language,
  SecretsHealth,
  StudioSecrets,
} from '../types/studio';
import { ALL_KEY_TAGS, PROVIDER_PRESETS } from '../modules/secrets';
import { testSingleApiKey } from '../modules/aiRouter';
import { validateGitHubToken } from '../modules/github';

interface SecretsViewProps {
  secrets: StudioSecrets;
  health: SecretsHealth;
  lang: Language;
  onUpdateSecrets: (next: StudioSecrets) => void;
  onTestStudioFirebase: (nextSecrets: StudioSecrets) => Promise<void>;
  onPullStudioFirebase: () => Promise<void>;
}

export const SecretsView: React.FC<SecretsViewProps> = ({
  secrets,
  health,
  lang,
  onUpdateSecrets,
  onTestStudioFirebase,
  onPullStudioFirebase,
}) => {
  const [draft, setDraft] = useState<StudioSecrets>(secrets);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});
  const [testingKeyId, setTestingKeyId] = useState<string | null>(null);
  const [validatingGithub, setValidatingGithub] = useState(false);
  const [testingStudioFb, setTestingStudioFb] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string>('');

  const flashNotice = (msg: string) => {
    setSaveNotice(msg);
    setTimeout(() => setSaveNotice(''), 2800);
  };

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const commitSecrets = (next: StudioSecrets, notice: string) => {
    setDraft(next);
    onUpdateSecrets(next);
    flashNotice(notice);
  };

  const updateKeySlot = (slotId: string, patch: Partial<ApiKeySlot>) => {
    setDraft((prev) => ({
      ...prev,
      apiKeys: prev.apiKeys.map((k) => (k.id === slotId ? { ...k, ...patch } : k)),
    }));
  };

  const toggleTag = (slotId: string, tag: KeyTag) => {
    setDraft((prev) => ({
      ...prev,
      apiKeys: prev.apiKeys.map((k) => {
        if (k.id !== slotId) return k;
        const exists = k.tags.includes(tag);
        const nextTags = exists ? k.tags.filter((t) => t !== tag) : [...k.tags, tag];
        return { ...k, tags: nextTags };
      }),
    }));
  };

  const handleProviderChange = (slotId: string, provider: AIProviderId) => {
    const preset = PROVIDER_PRESETS[provider];
    updateKeySlot(slotId, {
      provider,
      model: preset.defaultModel,
      baseUrl: preset.defaultBaseUrl,
      lastTestStatus: 'untested',
    });
  };

  const handleSaveSlot = (slotId: string) => {
    const slot = draft.apiKeys.find((k) => k.id === slotId);
    commitSecrets(
      draft,
      `Saved "${slot?.name || slotId}" — System Map updated dynamically.`
    );
  };

  const handleClearSlot = (slotId: string) => {
    const next: StudioSecrets = {
      ...draft,
      apiKeys: draft.apiKeys.map((k) =>
        k.id === slotId
          ? { ...k, apiKey: '', lastTestStatus: 'untested', lastTestMessage: undefined }
          : k
      ),
    };
    commitSecrets(next, 'Cleared API key from slot — System Map recomputed.');
  };

  const handleAddKeySlot = () => {
    const nextIndex = draft.apiKeys.length + 1;
    const newSlot: ApiKeySlot = {
      id: `slot-${Date.now()}`,
      slotIndex: nextIndex,
      name: `Custom AI Agent ${nextIndex}`,
      provider: 'nvidia',
      model: PROVIDER_PRESETS.nvidia.defaultModel,
      baseUrl: PROVIDER_PRESETS.nvidia.defaultBaseUrl,
      apiKey: '',
      tags: ['General'],
      enabled: true,
      lastTestStatus: 'untested',
    };
    const next = { ...draft, apiKeys: [...draft.apiKeys, newSlot] };
    setDraft(next);
    onUpdateSecrets(next);
  };

  const handleRemoveExtraSlot = (slotId: string) => {
    if (draft.apiKeys.length <= 7) {
      handleClearSlot(slotId);
      return;
    }
    const next = {
      ...draft,
      apiKeys: draft.apiKeys.filter((k) => k.id !== slotId),
    };
    commitSecrets(next, 'Removed extra API key slot.');
  };

  const handleTestKey = async (slot: ApiKeySlot) => {
    if (!slot.apiKey.trim()) return;
    setTestingKeyId(slot.id);
    try {
      const res = await testSingleApiKey(slot);
      const next: StudioSecrets = {
        ...draft,
        apiKeys: draft.apiKeys.map((k) =>
          k.id === slot.id
            ? {
                ...k,
                lastTestedAt: new Date().toISOString(),
                lastTestStatus: res.valid ? 'valid' : 'error',
                lastTestMessage: res.valid
                  ? `Verified (${res.detectedModel} · ${res.latencyMs}ms)`
                  : res.error || 'Failed validation',
              }
            : k
        ),
      };
      commitSecrets(next, res.valid ? `${slot.name} verified.` : `${slot.name}: ${res.error}`);
    } finally {
      setTestingKeyId(null);
    }
  };

  const handleValidateGitHub = async () => {
    const token = draft.githubToken.token.trim();
    if (!token) {
      commitSecrets(
        {
          ...draft,
          githubToken: { token: '', status: 'unconfigured', username: undefined, lastError: undefined },
        },
        'GitHub Token1 cleared.'
      );
      return;
    }
    setValidatingGithub(true);
    try {
      const res = await validateGitHubToken(token);
      const next: StudioSecrets = {
        ...draft,
        githubToken: {
          token,
          status: res.valid ? 'valid' : 'invalid',
          username: res.username,
          name: res.name,
          scopes: res.scopes,
          validatedAt: new Date().toISOString(),
          lastError: res.valid ? undefined : res.error,
        },
      };
      commitSecrets(
        next,
        res.valid ? `GitHub connected as @${res.username}` : `GitHub error: ${res.error}`
      );
    } finally {
      setValidatingGithub(false);
    }
  };

  const handleDeleteGitHub = () => {
    commitSecrets(
      {
        ...draft,
        githubToken: { token: '', status: 'unconfigured' },
      },
      'GitHub Token1 deleted.'
    );
  };

  const handleSaveAndTestStudioFb = async () => {
    setTestingStudioFb(true);
    try {
      await onTestStudioFirebase(draft);
      setDraft((prev) => ({ ...prev }));
      flashNotice('Studio Firebase test & sync complete.');
    } finally {
      setTestingStudioFb(false);
    }
  };

  const handleDeleteStudioFb = () => {
    commitSecrets(
      {
        ...draft,
        studioFirebase: { databaseUrl: '', projectId: '', apiKey: '', status: 'unconfigured' },
      },
      'Studio Firebase cleared — using local persistence.'
    );
  };

  const handleSaveAppsFb = () => {
    const configured = Boolean(
      draft.appsFirebase.projectId.trim() &&
        (draft.appsFirebase.apiKey.trim() || draft.appsFirebase.databaseUrl.trim())
    );
    commitSecrets(
      {
        ...draft,
        appsFirebase: { ...draft.appsFirebase, configured },
      },
      configured
        ? 'Apps Firebase saved — will inject into exported Flutter/Godot projects on OK.'
        : 'Apps Firebase saved (enter Project ID + API Key/URL to enable injection).'
    );
  };

  const handleDeleteAppsFb = () => {
    commitSecrets(
      {
        ...draft,
        appsFirebase: {
          projectId: '',
          apiKey: '',
          appId: '',
          databaseUrl: '',
          storageBucket: '',
          messagingSenderId: '',
          configured: false,
        },
      },
      'Apps Firebase cleared.'
    );
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Summary Header */}
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            {lang === 'hi' ? 'सीक्रेट्स और कनेक्शन (डिलीट तक सेव रहेंगे)' : 'Secrets & Credentials'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Persisted across reloads until deleted. Saving immediately updates the Display B System Map and status strip.
          </p>
        </div>
        <div className="text-xs font-mono tabular-nums text-slate-300 flex items-center gap-2 shrink-0">
          <span className={health.hasAnyAiKey ? 'text-emerald-400' : 'text-amber-300'}>
            {health.activeKeyCount} AI Keys
          </span>
          <span aria-hidden="true">·</span>
          <span className={health.githubConnected ? 'text-emerald-400' : 'text-slate-400'}>
            GitHub {health.githubConnected ? `@${secrets.githubToken.username}` : 'Off'}
          </span>
        </div>
      </div>

      {saveNotice && (
        <div className="px-4 py-2.5 rounded-lg bg-cyan-500/15 border border-cyan-500/40 text-xs text-cyan-200 font-medium">
          {saveNotice}
        </div>
      )}

      {/* SECTION A: API KEYS (7+ SLOTS) */}
      <section className="bg-[#0E1525] border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-cyan-400" />
              A. AI API Keys (7+ Dynamic Team Slots)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              One General key is enough to operate. Every saved key appears as a named chip on Display B System Map.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAddKeySlot}
            className="min-h-[38px] px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-xs font-medium text-cyan-200 flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Key Slot
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {draft.apiKeys.map((slot, idx) => {
            const hasVal = slot.apiKey.trim().length > 0;
            const revealed = Boolean(revealedIds[slot.id]);
            const preset = PROVIDER_PRESETS[slot.provider];

            return (
              <div key={slot.id} className="p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="text-slate-500">SLOT {idx + 1}</span>
                    <span aria-hidden="true">·</span>
                    <span className={hasVal ? 'text-emerald-400' : 'text-slate-500'}>
                      {hasVal ? 'Active on System Map' : 'Empty'}
                    </span>
                    {slot.lastTestStatus === 'valid' && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {slot.lastTestMessage}
                        </span>
                      </>
                    )}
                    {slot.lastTestStatus === 'error' && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-rose-400 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" />
                          {slot.lastTestMessage}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleTestKey(slot)}
                      disabled={!hasVal || testingKeyId === slot.id}
                      className="min-h-[34px] px-2.5 rounded-md bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      {testingKeyId === slot.id ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                      )}
                      Test
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaveSlot(slot.id)}
                      className="min-h-[34px] px-3 rounded-md bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveExtraSlot(slot.id)}
                      className="min-h-[34px] px-2.5 rounded-md bg-slate-900 hover:bg-rose-500/20 border border-slate-800 text-slate-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                      title={draft.apiKeys.length > 7 ? 'Delete slot' : 'Clear key'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Chip Name (shown on Map)</label>
                    <input
                      type="text"
                      value={slot.name}
                      onChange={(e) => updateKeySlot(slot.id, { name: e.target.value })}
                      placeholder="e.g., Gemini Brain / NVIDIA Coder"
                      className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Provider</label>
                    <select
                      value={slot.provider}
                      onChange={(e) => handleProviderChange(slot.id, e.target.value as AIProviderId)}
                      className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                    >
                      {Object.entries(PROVIDER_PRESETS).map(([id, info]) => (
                        <option key={id} value={id}>
                          {info.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Model Name</label>
                    <input
                      type="text"
                      value={slot.model}
                      onChange={(e) => updateKeySlot(slot.id, { model: e.target.value })}
                      placeholder={preset.defaultModel}
                      className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">API Key</label>
                    <div className="relative">
                      <input
                        type={revealed ? 'text' : 'password'}
                        value={slot.apiKey}
                        onChange={(e) => updateKeySlot(slot.id, { apiKey: e.target.value })}
                        placeholder={preset.placeholderKey}
                        className="w-full min-h-[40px] pl-3 pr-9 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => toggleReveal(slot.id)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-1 cursor-pointer"
                        aria-label="Toggle key visibility"
                      >
                        {revealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {slot.provider !== 'gemini' && (
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Base URL (OpenAI-Compatible)</label>
                    <input
                      type="text"
                      value={slot.baseUrl}
                      onChange={(e) => updateKeySlot(slot.id, { baseUrl: e.target.value })}
                      placeholder={preset.defaultBaseUrl}
                      className="w-full min-h-[38px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-300 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                )}

                {/* Department Routing Tags */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] text-slate-500 mr-1">Tags:</span>
                  {ALL_KEY_TAGS.map((tag) => {
                    const active = slot.tags.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => toggleTag(slot.id, tag)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${
                          active
                            ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-200'
                            : 'bg-[#090E1A] border border-slate-800 text-slate-500 hover:text-slate-300'
                        }`}
                      >
                        {tag}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION B: TOKENS (Token1 GitHub + Token2 Reserve) */}
      <section className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-cyan-400" />
            B. Tokens (Token1 GitHub · Token2 Reserve)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Token1 connects your real GitHub account (needs `repo` and `workflow` scopes) to create repos, push Flutter/Godot workflows, and poll APK links.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Token1 GitHub */}
          <div className="p-3.5 rounded-lg bg-[#090E1A] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Token1 — GitHub PAT</span>
              <span
                className={`font-mono ${
                  secrets.githubToken.status === 'valid'
                    ? 'text-emerald-400'
                    : secrets.githubToken.status === 'invalid'
                      ? 'text-rose-400'
                      : 'text-slate-500'
                }`}
              >
                {secrets.githubToken.status === 'valid'
                  ? `Connected · @${secrets.githubToken.username}`
                  : secrets.githubToken.status === 'invalid'
                    ? 'Invalid token'
                    : 'Not connected'}
              </span>
            </div>

            <div className="relative">
              <input
                type={revealedIds.github ? 'text' : 'password'}
                value={draft.githubToken.token}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    githubToken: { ...prev.githubToken, token: e.target.value },
                  }))
                }
                placeholder="ghp_... or github_pat_..."
                className="w-full min-h-[42px] pl-3 pr-9 rounded-lg bg-[#0E1525] border border-slate-800 font-mono text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => toggleReveal('github')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-1 cursor-pointer"
              >
                {revealedIds.github ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>

            {secrets.githubToken.lastError && (
              <p className="text-[11px] text-rose-400">{secrets.githubToken.lastError}</p>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleValidateGitHub}
                disabled={validatingGithub}
                className="min-h-[38px] px-3.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                {validatingGithub && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Save &amp; Validate GitHub
              </button>
              <button
                type="button"
                onClick={handleDeleteGitHub}
                className="min-h-[38px] px-3 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-300 text-xs cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>

          {/* Token2 Reserve */}
          <div className="p-3.5 rounded-lg bg-[#090E1A] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Token2 — Reserve (Future)</span>
              <span className="font-mono text-slate-500">
                {draft.reserveToken.token.trim() ? 'Stored' : 'Empty (OK)'}
              </span>
            </div>

            <input
              type="text"
              value={draft.reserveToken.label}
              onChange={(e) =>
                setDraft((prev) => ({
                  ...prev,
                  reserveToken: { ...prev.reserveToken, label: e.target.value },
                }))
              }
              placeholder="Reserve label (optional)"
              className="w-full min-h-[38px] px-3 rounded-lg bg-[#0E1525] border border-slate-800 text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
            />
            <input
              type={revealedIds.reserve ? 'text' : 'password'}
              value={draft.reserveToken.token}
              onChange={(e) =>
                setDraft((prev) => ({
                  ...prev,
                  reserveToken: { ...prev.reserveToken, token: e.target.value },
                }))
              }
              placeholder="Optional future deployment token..."
              className="w-full min-h-[38px] px-3 rounded-lg bg-[#0E1525] border border-slate-800 font-mono text-xs text-slate-100 focus:border-cyan-500 focus:outline-none"
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => commitSecrets(draft, 'Token2 Reserve saved.')}
                className="min-h-[36px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 cursor-pointer"
              >
                Save Reserve
              </button>
              <button
                type="button"
                onClick={() =>
                  commitSecrets(
                    { ...draft, reserveToken: { label: 'Token2 (Reserve)', token: '' } },
                    'Token2 cleared.'
                  )
                }
                className="min-h-[36px] px-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION C: VOICE KEY SLOT */}
      <section className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Mic className="w-4 h-4 text-cyan-400" />
              C. Voice Key Slot (STT / TTS)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live ON/OFF uses native Web Speech API by default with zero key needed. Optionally store a dedicated Voice API key here.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <select
            value={draft.voiceKey.provider}
            onChange={(e) =>
              setDraft((prev) => ({
                ...prev,
                voiceKey: {
                  ...prev.voiceKey,
                  provider: e.target.value as StudioSecrets['voiceKey']['provider'],
                },
              }))
            }
            className="min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100"
          >
            <option value="browser-web-speech">Browser Native Web Speech (Free)</option>
            <option value="openai-whisper">OpenAI Whisper / TTS</option>
            <option value="elevenlabs">ElevenLabs Voice</option>
            <option value="deepgram">Deepgram Live STT</option>
            <option value="custom">Custom Voice Endpoint</option>
          </select>
          <input
            type={revealedIds.voice ? 'text' : 'password'}
            value={draft.voiceKey.apiKey}
            onChange={(e) =>
              setDraft((prev) => ({
                ...prev,
                voiceKey: { ...prev.voiceKey, apiKey: e.target.value },
              }))
            }
            placeholder={
              draft.voiceKey.provider === 'browser-web-speech'
                ? 'Not needed for browser native speech'
                : 'Enter separate voice API key...'
            }
            className="min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
          />
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => commitSecrets(draft, 'Voice slot saved.')}
              className="min-h-[40px] px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-100 cursor-pointer"
            >
              Save Voice
            </button>
            <button
              type="button"
              onClick={() =>
                commitSecrets(
                  {
                    ...draft,
                    voiceKey: { provider: 'browser-web-speech', apiKey: '', model: 'web-speech-native' },
                  },
                  'Voice slot reset to Browser Native.'
                )
              }
              className="min-h-[40px] px-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 cursor-pointer"
            >
              Reset
            </button>
          </div>
        </div>
      </section>

      {/* SECTIONS D & E: DUAL FIREBASES */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* SECTION D: STUDIO FIREBASE */}
        <section className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <Database className="w-4 h-4 text-cyan-400" />
                D. Studio Firebase (Studio Records Only)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Persists studio jobs, vault, stage index, language, and map status across devices.
              </p>
            </div>
            <span
              className={`text-xs font-mono shrink-0 ${
                secrets.studioFirebase.status === 'connected'
                  ? 'text-emerald-400'
                  : secrets.studioFirebase.status === 'error'
                    ? 'text-rose-400'
                    : 'text-slate-500'
              }`}
            >
              {secrets.studioFirebase.status}
            </span>
          </div>

          <div className="space-y-2.5">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Realtime Database URL (recommended)</label>
              <input
                type="text"
                value={draft.studioFirebase.databaseUrl}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    studioFirebase: { ...prev.studioFirebase, databaseUrl: e.target.value },
                  }))
                }
                placeholder="https://my-studio-db-default-rtdb.firebaseio.com"
                className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Project ID (optional for Firestore)</label>
                <input
                  type="text"
                  value={draft.studioFirebase.projectId}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      studioFirebase: { ...prev.studioFirebase, projectId: e.target.value },
                    }))
                  }
                  placeholder="sarfealam-studio"
                  className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">API Key / Auth Secret</label>
                <input
                  type="password"
                  value={draft.studioFirebase.apiKey}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      studioFirebase: { ...prev.studioFirebase, apiKey: e.target.value },
                    }))
                  }
                  placeholder="AIzaSy... or DB secret"
                  className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
                />
              </div>
            </div>

            {secrets.studioFirebase.lastError && (
              <p className="text-[11px] text-rose-400">{secrets.studioFirebase.lastError}</p>
            )}

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleSaveAndTestStudioFb}
                disabled={testingStudioFb}
                className="min-h-[38px] px-3.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                {testingStudioFb && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Save &amp; Sync Studio Firebase
              </button>
              {secrets.studioFirebase.status === 'connected' && (
                <button
                  type="button"
                  onClick={onPullStudioFirebase}
                  className="min-h-[38px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 cursor-pointer"
                >
                  Pull Records
                </button>
              )}
              <button
                type="button"
                onClick={handleDeleteStudioFb}
                className="min-h-[38px] px-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-rose-300 cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </section>

        {/* SECTION E: APPS FIREBASE */}
        <section className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <Server className="w-4 h-4 text-cyan-400" />
                E. Apps Firebase (Injected into Generated Apps)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                On OK export, injected into Flutter `firebase_options.dart` or Godot 4 `apps_firebase_bridge.gd` so published apps use this server.
              </p>
            </div>
            <span className={`text-xs font-mono shrink-0 ${secrets.appsFirebase.configured ? 'text-emerald-400' : 'text-slate-500'}`}>
              {secrets.appsFirebase.configured ? 'Ready to inject' : 'Not set'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Project ID</label>
              <input
                type="text"
                value={draft.appsFirebase.projectId}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    appsFirebase: { ...prev.appsFirebase, projectId: e.target.value },
                  }))
                }
                placeholder="my-published-apps-prod"
                className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Web / Android API Key</label>
              <input
                type="password"
                value={draft.appsFirebase.apiKey}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    appsFirebase: { ...prev.appsFirebase, apiKey: e.target.value },
                  }))
                }
                placeholder="AIzaSy..."
                className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Firebase App ID</label>
              <input
                type="text"
                value={draft.appsFirebase.appId}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    appsFirebase: { ...prev.appsFirebase, appId: e.target.value },
                  }))
                }
                placeholder="1:1234567890:android:abcdef"
                className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Database URL / Storage Bucket</label>
              <input
                type="text"
                value={draft.appsFirebase.databaseUrl}
                onChange={(e) =>
                  setDraft((prev) => ({
                    ...prev,
                    appsFirebase: { ...prev.appsFirebase, databaseUrl: e.target.value },
                  }))
                }
                placeholder="https://my-apps.firebaseio.com"
                className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-slate-100"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleSaveAppsFb}
              className="min-h-[38px] px-3.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer"
            >
              Save Apps Firebase
            </button>
            <button
              type="button"
              onClick={handleDeleteAppsFb}
              className="min-h-[38px] px-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-rose-300 cursor-pointer"
            >
              Delete
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
