import React, { useMemo, useState } from 'react';
import { Search, Sliders } from 'lucide-react';
import type { BuildJob, EngineType, Language, StudioSkill } from '../types/studio';
import type { WorkflowTemplateMap } from '../modules/workflowTemplates';
import { WorkflowTemplatesPanel } from './WorkflowTemplatesPanel';

interface SkillsViewProps {
  skills: StudioSkill[];
  activeJob: BuildJob | null;
  lang: Language;
  workflowTemplates: WorkflowTemplateMap;
  onToggleSkill: (id: string) => void;
  onBulkToggle: (category: 'pipeline' | 'capability', enabled: boolean) => void;
  onSaveWorkflowTemplate: (engine: EngineType, filePath: string, templateYaml: string) => void;
  onResetWorkflowTemplate: (engine: EngineType) => void;
}

export const SkillsView: React.FC<SkillsViewProps> = ({
  skills,
  activeJob,
  lang,
  workflowTemplates,
  onToggleSkill,
  onBulkToggle,
  onSaveWorkflowTemplate,
  onResetWorkflowTemplate,
}) => {
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState<'all' | 'pipeline' | 'capability'>('all');

  const counts = useMemo(() => {
    const pipeline = skills.filter((s) => s.category === 'pipeline');
    const capability = skills.filter((s) => s.category === 'capability');
    return {
      pipelineTotal: pipeline.length,
      pipelineOn: pipeline.filter((s) => s.enabled).length,
      capTotal: capability.length,
      capOn: capability.filter((s) => s.enabled).length,
    };
  }, [skills]);

  const filtered = useMemo(() => {
    return skills.filter((s) => {
      if (catFilter !== 'all' && s.category !== catFilter) return false;
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        s.nameHi.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q)
      );
    });
  }, [skills, catFilter, query]);

  const pipelineList = filtered.filter((s) => s.category === 'pipeline');
  const capabilityList = filtered.filter((s) => s.category === 'capability');

  const renderSection = (title: string, category: 'pipeline' | 'capability', items: StudioSkill[]) => {
    if (items.length === 0) return null;
    return (
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-100">{title}</h3>
            <span className="text-xs font-mono tabular-nums text-slate-400">
              · {items.filter((i) => i.enabled).length}/{items.length} ON
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => onBulkToggle(category, true)}
              className="px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
            >
              Enable All
            </button>
            <button
              type="button"
              onClick={() => onBulkToggle(category, false)}
              className="px-2.5 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 cursor-pointer"
            >
              Disable All
            </button>
          </div>
        </div>

        <div className="divide-y divide-slate-800/80">
          {items.map((skill) => {
            const matchedInActive = activeJob?.matchedSkills.includes(skill.id);
            const skippedInActive = activeJob?.skippedSkills.includes(skill.id);

            return (
              <div
                key={skill.id}
                className="px-4 py-3 flex items-center justify-between gap-4 hover:bg-slate-900/40 transition-colors"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                    <span className={`text-sm font-medium ${skill.enabled ? 'text-slate-100' : 'text-slate-500'}`}>
                      {lang === 'hi' ? skill.nameHi : skill.name}
                    </span>
                    {matchedInActive && (
                      <span className="text-[11px] font-mono text-cyan-400">· Applied to current build</span>
                    )}
                    {skippedInActive && (
                      <span className="text-[11px] font-mono text-amber-400">· Skipped (OFF)</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{skill.description}</p>
                </div>

                <button
                  type="button"
                  role="switch"
                  aria-checked={skill.enabled}
                  onClick={() => onToggleSkill(skill.id)}
                  className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors cursor-pointer ${
                    skill.enabled ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-slate-950 transition-transform ${
                      skill.enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4 pb-6">
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              {lang === 'hi' ? 'स्किल्स रजिस्ट्री (पाइपलाइन द्वारा नियंत्रित)' : 'Skills Registry'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Every switch below is read by the build engine. Turning a skill OFF prevents the pipeline from applying it.
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter skills..."
              className="w-full min-h-[40px] pl-9 pr-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          <button
            type="button"
            onClick={() => setCatFilter('all')}
            className={`min-h-[36px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
              catFilter === 'all'
                ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                : 'bg-[#090E1A] border border-slate-800 text-slate-400'
            }`}
          >
            All ({counts.pipelineOn + counts.capOn}/{counts.pipelineTotal + counts.capTotal})
          </button>
          <button
            type="button"
            onClick={() => setCatFilter('pipeline')}
            className={`min-h-[36px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
              catFilter === 'pipeline'
                ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                : 'bg-[#090E1A] border border-slate-800 text-slate-400'
            }`}
          >
            Pipeline ({counts.pipelineOn}/{counts.pipelineTotal})
          </button>
          <button
            type="button"
            onClick={() => setCatFilter('capability')}
            className={`min-h-[36px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
              catFilter === 'capability'
                ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                : 'bg-[#090E1A] border border-slate-800 text-slate-400'
            }`}
          >
            Product Capabilities ({counts.capOn}/{counts.capTotal})
          </button>
        </div>
      </div>

      <WorkflowTemplatesPanel
        templates={workflowTemplates}
        lang={lang}
        flutterSkillEnabled={Boolean(skills.find((s) => s.id === 'flutter-workflow-path')?.enabled)}
        godotSkillEnabled={Boolean(skills.find((s) => s.id === 'godot4-workflow-path')?.enabled)}
        onSaveTemplate={onSaveWorkflowTemplate}
        onResetTemplate={onResetWorkflowTemplate}
      />

      {renderSection('Pipeline Skills', 'pipeline', pipelineList)}
      {renderSection('Product Capability Skills', 'capability', capabilityList)}
    </div>
  );
};
