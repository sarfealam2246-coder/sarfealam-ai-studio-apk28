import React, { useMemo, useState } from 'react';
import {
  Archive,
  Download,
  ExternalLink,
  FolderOpen,
  Gamepad2,
  RefreshCw,
  Search,
  Shield,
  Smartphone,
  Trash2,
  FileCode2,
} from 'lucide-react';
import type { BuildJob, BuildStatus, Language } from '../types/studio';
import { downloadProjectZip } from '../modules/github';

interface VaultViewProps {
  vault: BuildJob[];
  activeJobId: string | null;
  lang: Language;
  githubConnected: boolean;
  onResumeJob: (jobId: string) => void;
  onOpenAdminForJob: (jobId: string) => void;
  onPollGitHub: (jobId: string) => Promise<void>;
  onDeleteJob: (jobId: string) => void;
  onGoBuild: () => void;
}

const STATUS_FILTERS: Array<{ id: 'all' | BuildStatus; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'assembling', label: 'Assembling' },
  { id: 'testing', label: 'Testing' },
  { id: 'exporting', label: 'Exporting' },
  { id: 'ready', label: 'Ready' },
  { id: 'error', label: 'Error' },
];

export const VaultView: React.FC<VaultViewProps> = ({
  vault,
  activeJobId,
  lang,
  githubConnected,
  onResumeJob,
  onOpenAdminForJob,
  onPollGitHub,
  onDeleteJob,
  onGoBuild,
}) => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | BuildStatus>('all');
  const [pollingId, setPollingId] = useState<string | null>(null);
  const [inspectJobId, setInspectJobId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return vault.filter((job) => {
      if (filter !== 'all' && job.status !== filter) return false;
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return (
        job.title.toLowerCase().includes(q) ||
        job.prompt.toLowerCase().includes(q) ||
        job.engine.toLowerCase().includes(q)
      );
    });
  }, [vault, filter, query]);

  const handlePoll = async (jobId: string) => {
    setPollingId(jobId);
    try {
      await onPollGitHub(jobId);
    } finally {
      setPollingId(null);
    }
  };

  const statusTone = (status: BuildStatus) => {
    if (status === 'ready') return 'text-emerald-400';
    if (status === 'error' || status === 'cancelled') return 'text-rose-400';
    if (status === 'testing' || status === 'ok') return 'text-amber-300';
    return 'text-cyan-400';
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Header & Filters */}
      <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              {lang === 'hi' ? 'बिल्ड वॉल्ट (इतिहास और APK लिंक्स)' : 'Build Vault'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'hi'
                ? 'सभी बिल्ड, Apps APK डाउनलोड लिंक और Admin लिंक सीधे यहाँ दिखते हैं।'
                : 'All builds, Apps APK download links, and Admin final links appear here after OK export.'}
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={lang === 'hi' ? 'बिल्ड खोजें...' : 'Search builds...'}
              className="w-full min-h-[40px] pl-9 pr-3 rounded-lg bg-[#090E1A] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                filter === f.id
                  ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                  : 'bg-[#090E1A] border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {filtered.length === 0 ? (
        <div className="bg-[#0E1525] border border-slate-800 rounded-xl p-10 text-center flex flex-col items-center">
          <Archive className="w-8 h-8 text-slate-600 mb-3" />
          <h3 className="text-sm font-semibold text-slate-200">
            {vault.length === 0
              ? lang === 'hi'
                ? 'वॉल्ट अभी खाली है'
                : 'No builds in Vault yet'
              : 'No builds match your filter'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mt-1">
            {lang === 'hi'
              ? 'Build टैब में जाकर अपना पहला ऐप या गेम असेंबल करें। पूरा होने पर APK और Admin लिंक यहाँ सेव हो जाएंगे।'
              : 'Assemble an app or game in the Build tab. Completed jobs and export links persist here automatically.'}
          </p>
          <button
            type="button"
            onClick={onGoBuild}
            className="mt-4 min-h-[42px] px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer transition-colors"
          >
            {lang === 'hi' ? 'Build टैब खोलें' : 'Go to Build'}
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((job) => {
            const isCurrent = job.id === activeJobId;
            const fileList = Object.keys(job.exportArtifacts.files || {});
            const isInspecting = inspectJobId === job.id;

            return (
              <article
                key={job.id}
                className={`bg-[#0E1525] border rounded-xl p-4 space-y-3 ${
                  isCurrent ? 'border-cyan-500/50' : 'border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      {job.productType === 'game' ? (
                        <Gamepad2 className="w-4 h-4 text-cyan-400 shrink-0" />
                      ) : (
                        <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
                      )}
                      <h3 className="text-sm font-semibold text-slate-100 truncate">{job.title}</h3>
                    </div>

                    {/* Clean unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-400 mt-1 font-mono tabular-nums">
                      <span>{job.productType === 'game' ? 'Game · Godot 4' : 'App · Flutter'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{new Date(job.updatedAt).toLocaleString()}</span>
                      <span aria-hidden="true">·</span>
                      <span className={`font-semibold uppercase ${statusTone(job.status)}`}>
                        {job.status} ({job.stageIndex}/5)
                      </span>
                      {job.isDemoMode && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300">Demo Preview</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onResumeJob(job.id)}
                      className="min-h-[38px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-100 flex items-center gap-1.5 cursor-pointer"
                    >
                      <FolderOpen className="w-3.5 h-3.5 text-cyan-400" />
                      Resume
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenAdminForJob(job.id)}
                      className="min-h-[38px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-100 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Shield className="w-3.5 h-3.5 text-cyan-400" />
                      Admin
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteJob(job.id)}
                      className="min-h-[38px] min-w-[38px] rounded-lg bg-slate-900 hover:bg-rose-500/20 border border-slate-800 text-slate-400 hover:text-rose-300 flex items-center justify-center cursor-pointer"
                      aria-label="Delete build"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Direct APK Link + Admin Final Link Slots */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2 border-t border-slate-800/80">
                  {/* Apps APK Download Link */}
                  <div className="p-3 rounded-lg bg-[#090E1A] border border-slate-800/90 flex flex-col justify-between gap-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-300">Apps APK Download Link</span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {job.exportArtifacts.apkStatus}
                      </span>
                    </div>

                    {job.exportArtifacts.apkUrl ? (
                      <a
                        href={job.exportArtifacts.apkUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 break-all"
                      >
                        <Download className="w-3.5 h-3.5 shrink-0" />
                        <span>{job.exportArtifacts.apkUrl}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    ) : job.exportArtifacts.repoUrl ? (
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                        <span>GitHub Actions building APK...</span>
                        <div className="flex items-center gap-2">
                          {job.exportArtifacts.actionsUrl && (
                            <a
                              href={job.exportArtifacts.actionsUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-cyan-400 hover:underline flex items-center gap-1"
                            >
                              Actions <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                          {githubConnected && (
                            <button
                              type="button"
                              onClick={() => handlePoll(job.id)}
                              disabled={pollingId === job.id}
                              className="px-2.5 py-1 rounded bg-cyan-500/15 border border-cyan-500/40 text-cyan-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                            >
                              <RefreshCw className={`w-3 h-3 ${pollingId === job.id ? 'animate-spin' : ''}`} />
                              Poll APK
                            </button>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-500">
                        {job.exportArtifacts.errorReason ||
                          (job.stageIndex < 5
                            ? 'Complete Stage 5 & press OK to export.'
                            : 'Press OK on Build tab to generate package / push to GitHub Actions.')}
                      </div>
                    )}
                  </div>

                  {/* Admin Final Link */}
                  <div className="p-3 rounded-lg bg-[#090E1A] border border-slate-800/90 flex flex-col justify-between gap-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-300">Admin Final Link</span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {job.exportArtifacts.appsFirebaseInjected ? 'Apps FB Injected' : 'Apps FB Not Set'}
                      </span>
                    </div>

                    {job.exportArtifacts.adminFinalUrl ? (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono text-cyan-400 truncate">
                          {job.exportArtifacts.adminFinalUrl}
                        </span>
                        <button
                          type="button"
                          onClick={() => onOpenAdminForJob(job.id)}
                          className="text-xs font-medium text-slate-200 hover:text-cyan-300 whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          Open Admin →
                        </button>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-500">
                        Published automatically when OK export runs.
                      </div>
                    )}
                  </div>
                </div>

                {/* Package Files & Download ZIP */}
                {fileList.length > 0 && (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
                    <button
                      type="button"
                      onClick={() => setInspectJobId(isInspecting ? null : job.id)}
                      className="text-slate-400 hover:text-slate-200 flex items-center gap-1.5 cursor-pointer"
                    >
                      <FileCode2 className="w-3.5 h-3.5 text-cyan-400" />
                      <span>
                        {isInspecting ? 'Hide' : 'Inspect'} {fileList.length} generated {job.engine === 'godot4' ? 'Godot 4' : 'Flutter'} files
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => downloadProjectZip(job.exportArtifacts.repoName || job.title, job.exportArtifacts.files)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      Download Source + Workflow ZIP
                    </button>
                  </div>
                )}

                {isInspecting && fileList.length > 0 && (
                  <div className="rounded-lg bg-[#090E1A] border border-slate-800 p-3 space-y-2 max-h-64 overflow-y-auto">
                    {fileList.map((fp) => (
                      <details key={fp} className="text-xs">
                        <summary className="font-mono text-cyan-300 cursor-pointer py-1">
                          {fp}
                        </summary>
                        <pre className="mt-1 p-2.5 rounded bg-[#070B14] border border-slate-800/80 text-[11px] font-mono text-slate-300 overflow-x-auto whitespace-pre">
                          {job.exportArtifacts.files[fp]}
                        </pre>
                      </details>
                    ))}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
