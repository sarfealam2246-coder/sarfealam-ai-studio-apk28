import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Check,
  Copy,
  FileCode2,
  RotateCcw,
  Save,
} from 'lucide-react';
import type { EngineType, Language } from '../types/studio';
import {
  renderWorkflowForExport,
  validateWorkflowYaml,
  WORKFLOW_PLACEHOLDERS,
  type WorkflowTemplateMap,
} from '../modules/workflowTemplates';

interface WorkflowTemplatesPanelProps {
  templates: WorkflowTemplateMap;
  lang: Language;
  flutterSkillEnabled: boolean;
  godotSkillEnabled: boolean;
  onSaveTemplate: (engine: EngineType, filePath: string, templateYaml: string) => void;
  onResetTemplate: (engine: EngineType) => void;
}

export const WorkflowTemplatesPanel: React.FC<WorkflowTemplatesPanelProps> = ({
  templates,
  lang,
  flutterSkillEnabled,
  godotSkillEnabled,
  onSaveTemplate,
  onResetTemplate,
}) => {
  const [selectedEngine, setSelectedEngine] = useState<EngineType>('flutter');
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [draftPath, setDraftPath] = useState(templates.flutter.filePath);
  const [draftYaml, setDraftYaml] = useState(templates.flutter.templateYaml);
  const [copied, setCopied] = useState(false);
  const [savedToast, setSavedToast] = useState('');

  const activeTemplate = templates[selectedEngine];
  const skillActive = selectedEngine === 'flutter' ? flutterSkillEnabled : godotSkillEnabled;

  useEffect(() => {
    setDraftPath(activeTemplate.filePath);
    setDraftYaml(activeTemplate.templateYaml);
  }, [selectedEngine, activeTemplate.filePath, activeTemplate.templateYaml]);

  const validation = useMemo(() => validateWorkflowYaml(draftYaml), [draftYaml]);

  const renderedPreview = useMemo(() => {
    const tempMap: WorkflowTemplateMap = {
      ...templates,
      [selectedEngine]: {
        ...activeTemplate,
        filePath: draftPath,
        templateYaml: draftYaml,
      },
    };
    return renderWorkflowForExport(
      selectedEngine,
      {
        appName: selectedEngine === 'flutter' ? 'Sarfealam Commerce' : 'Velocity Drift 3D',
        appSlug: selectedEngine === 'flutter' ? 'sarfealam_commerce' : 'velocity_drift_3d',
        flutterBuildFlags: '--tree-shake-icons',
      },
      tempMap
    );
  }, [templates, selectedEngine, activeTemplate, draftPath, draftYaml]);

  const isDirty =
    draftPath !== activeTemplate.filePath || draftYaml !== activeTemplate.templateYaml;

  const handleSave = () => {
    if (!validation.valid) return;
    onSaveTemplate(selectedEngine, draftPath, draftYaml);
    setSavedToast(
      lang === 'hi'
        ? `${selectedEngine === 'flutter' ? 'Flutter' : 'Godot 4'} वर्कफ़्लो YAML सेव हो गया — अगले एक्सपोर्ट में इंजेक्ट होगा।`
        : `Saved ${selectedEngine === 'flutter' ? 'Flutter' : 'Godot 4'} workflow YAML — will inject into export packages.`
    );
    setTimeout(() => setSavedToast(''), 2800);
  };

  const handleReset = () => {
    onResetTemplate(selectedEngine);
    setSavedToast('Restored default boilerplate YAML.');
    setTimeout(() => setSavedToast(''), 2400);
  };

  const handleCopy = () => {
    const content = viewMode === 'preview' ? renderedPreview.content : draftYaml;
    navigator.clipboard?.writeText(content).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <section className="bg-[#0E1525] border border-slate-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3.5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-cyan-400" />
            {lang === 'hi'
              ? 'GitHub Actions APK वर्कफ़्लो YAML मैनेजर'
              : 'GitHub Actions Workflow YAML Boilerplates'}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Managed templates injected directly into exported Flutter &amp; Godot 4 packages on OK.
          </p>
        </div>

        {/* Engine Switcher */}
        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#090E1A] border border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => setSelectedEngine('flutter')}
            className={`min-h-[36px] px-3 rounded-md text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
              selectedEngine === 'flutter'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Flutter APK
          </button>
          <button
            type="button"
            onClick={() => setSelectedEngine('godot4')}
            className={`min-h-[36px] px-3 rounded-md text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
              selectedEngine === 'godot4'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Godot 4 APK
          </button>
        </div>
      </div>

      <div className="p-4 space-y-3.5">
        {/* Status Metadata Line */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-slate-400 font-mono">
            <span className={skillActive ? 'text-emerald-400' : 'text-amber-300'}>
              {skillActive ? 'Injection ON' : 'Skipped (Workflow skill OFF)'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{activeTemplate.isCustomized ? 'Custom Template' : 'Default Boilerplate'}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              Updated {new Date(activeTemplate.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setViewMode('edit')}
              className={`min-h-[32px] px-2.5 rounded-md text-xs font-medium cursor-pointer ${
                viewMode === 'edit'
                  ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                  : 'bg-[#090E1A] border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Edit Boilerplate
            </button>
            <button
              type="button"
              onClick={() => setViewMode('preview')}
              className={`min-h-[32px] px-2.5 rounded-md text-xs font-medium cursor-pointer ${
                viewMode === 'preview'
                  ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-200'
                  : 'bg-[#090E1A] border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Rendered Output
            </button>
          </div>
        </div>

        <p className="text-xs text-slate-400">{activeTemplate.description}</p>

        {/* Workflow File Path Input */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 items-end">
          <div className="sm:col-span-2">
            <label className="block text-[11px] text-slate-400 mb-1">
              Export Workflow Path (injected into repository)
            </label>
            <input
              type="text"
              value={draftPath}
              onChange={(e) => setDraftPath(e.target.value)}
              disabled={viewMode === 'preview'}
              className="w-full min-h-[40px] px-3 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs text-cyan-300 focus:border-cyan-500 focus:outline-none disabled:opacity-70"
            />
          </div>
          <div className="flex items-center gap-2 justify-end">
            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[40px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="min-h-[40px] px-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 flex items-center gap-1.5 cursor-pointer"
              title="Reset to default boilerplate"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={!validation.valid || !isDirty}
              className="min-h-[40px] px-3.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              Save
            </button>
          </div>
        </div>

        {/* YAML Editor or Rendered Preview */}
        {viewMode === 'edit' ? (
          <textarea
            value={draftYaml}
            onChange={(e) => setDraftYaml(e.target.value)}
            spellCheck={false}
            rows={14}
            className="w-full p-3.5 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs leading-relaxed text-slate-200 focus:border-cyan-500 focus:outline-none resize-y"
          />
        ) : (
          <pre className="w-full p-3.5 rounded-lg bg-[#090E1A] border border-slate-800 font-mono text-xs leading-relaxed text-cyan-100 overflow-x-auto max-h-80 overflow-y-auto whitespace-pre">
            {renderedPreview.content}
          </pre>
        )}

        {/* Validation Feedback */}
        {validation.errors.length > 0 && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/35 text-xs text-rose-200 space-y-1">
            {validation.errors.map((err, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>{err}</span>
              </div>
            ))}
          </div>
        )}

        {validation.warnings.length > 0 && (
          <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 space-y-1">
            {validation.warnings.map((warn, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{warn}</span>
              </div>
            ))}
          </div>
        )}

        {savedToast && (
          <div className="text-xs font-medium text-emerald-300">{savedToast}</div>
        )}

        {/* Available Injection Tokens */}
        <details className="text-xs text-slate-400 pt-1">
          <summary className="cursor-pointer hover:text-slate-200 font-medium">
            Available export template tokens ({WORKFLOW_PLACEHOLDERS.length})
          </summary>
          <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5 p-3 rounded-lg bg-[#090E1A] border border-slate-800/80">
            {WORKFLOW_PLACEHOLDERS.map((item) => (
              <div key={item.token} className="flex items-baseline gap-2">
                <code className="font-mono text-[11px] text-cyan-300 shrink-0">{item.token}</code>
                <span className="text-[11px] text-slate-400 truncate">{item.description}</span>
              </div>
            ))}
          </div>
        </details>
      </div>
    </section>
  );
};
