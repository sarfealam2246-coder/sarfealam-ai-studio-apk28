import type { ApiKeySlot, DepartmentId, StudioSecrets } from '../types/studio';
import { getActiveApiKeys } from './secrets';

export interface RouteAIOptions {
  department: DepartmentId;
  prompt: string;
  systemInstruction?: string;
  history?: Array<{ role: 'user' | 'assistant'; text: string }>;
  jsonMode?: boolean;
  allowFallback?: boolean;
}

export interface RouteAIResult {
  ok: boolean;
  code?: string;
  text?: string;
  usedKeyId?: string;
  usedKeyLabel?: string;
  usedProvider?: string;
  usedModel?: string;
  fallbackUsed?: boolean;
  error?: string;
  attempts: Array<{
    keyId: string;
    label: string;
    provider: string;
    model: string;
    ok: boolean;
    error?: string;
    latencyMs: number;
  }>;
}

const DEPARTMENT_TAG_PREFERENCES: Record<DepartmentId, string[]> = {
  brain: ['Primary', 'General', 'Reason', 'Fast', 'Code', 'Fallback'],
  code: ['Code', 'Primary', 'Reason', 'General', 'Fast', 'Fallback'],
  fast: ['Fast', 'Fallback', 'General', 'Primary', 'Code'],
  vision: ['Vision', 'Primary', 'General', 'Fast'],
  reason: ['Reason', 'Code', 'Primary', 'General', 'Fallback'],
  listen: ['Fast', 'General', 'Primary'],
  speak: ['Fast', 'General', 'Primary'],
};

/**
 * Ranks active keys for a specific department.
 * Rule 5: One API key must be enough to operate — if only 1 key exists,
 * every department routes cleanly through that key.
 */
export function selectKeysForDepartment(secrets: StudioSecrets, department: DepartmentId): ApiKeySlot[] {
  const active = getActiveApiKeys(secrets);
  if (active.length <= 1) return active;

  const prefs = DEPARTMENT_TAG_PREFERENCES[department] || ['Primary', 'General'];

  return [...active].sort((a, b) => {
    const score = (slot: ApiKeySlot) => {
      let s = 0;
      for (let i = 0; i < prefs.length; i++) {
        if (slot.tags.includes(prefs[i] as ApiKeySlot['tags'][number])) {
          s += (prefs.length - i) * 10;
        }
      }
      if (slot.tags.includes('Primary')) s += 5;
      if (slot.tags.includes('Fallback')) s -= 3;
      if (slot.lastTestStatus === 'valid') s += 4;
      if (slot.lastTestStatus === 'error') s -= 15;
      return s;
    };
    return score(b) - score(a);
  });
}

export async function routeAIRequest(
  secrets: StudioSecrets,
  options: RouteAIOptions
): Promise<RouteAIResult> {
  const rankedKeys = selectKeysForDepartment(secrets, options.department);

  if (rankedKeys.length === 0) {
    return {
      ok: false,
      code: 'NO_KEYS',
      error: 'No active API keys saved in Secrets.',
      attempts: [],
    };
  }

  try {
    const res = await fetch('/api/ai/route', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: options.prompt,
        systemInstruction: options.systemInstruction,
        history: options.history,
        jsonMode: options.jsonMode,
        allowFallback: options.allowFallback ?? true,
        keys: rankedKeys.map((k) => ({
          id: k.id,
          label: k.name || `${k.provider} #${k.slotIndex}`,
          provider: k.provider,
          apiKey: k.apiKey.trim(),
          model: k.model.trim(),
          baseUrl: k.baseUrl.trim(),
          tags: k.tags,
        })),
      }),
    });

    const data = (await res.json()) as RouteAIResult;
    return data;
  } catch (err: unknown) {
    const e = err as Error;
    return {
      ok: false,
      code: 'NETWORK_ERROR',
      error: e.message || 'Failed contacting studio AI routing backend.',
      attempts: [],
    };
  }
}

export async function testSingleApiKey(slot: ApiKeySlot): Promise<{
  ok: boolean;
  valid: boolean;
  detectedModel?: string;
  latencyMs?: number;
  error?: string;
}> {
  try {
    const res = await fetch('/api/ai/test-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        keySlot: {
          id: slot.id,
          label: slot.name,
          provider: slot.provider,
          apiKey: slot.apiKey.trim(),
          model: slot.model.trim(),
          baseUrl: slot.baseUrl.trim(),
          tags: slot.tags,
        },
      }),
    });
    return await res.json();
  } catch (err: unknown) {
    const e = err as Error;
    return { ok: false, valid: false, error: e.message || 'Network error' };
  }
}
