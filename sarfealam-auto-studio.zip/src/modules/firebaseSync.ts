import type { BuildJob, CoPilotMessage, Language, StudioFirebaseConfig } from '../types/studio';

const VAULT_KEY = 'sarfealam_studio_vault_v1';
const ACTIVE_JOB_KEY = 'sarfealam_studio_active_job_v1';
const LANG_KEY = 'sarfealam_studio_lang_v1';
const MESSAGES_KEY = 'sarfealam_studio_messages_v1';

export function loadVault(): BuildJob[] {
  try {
    const raw = localStorage.getItem(VAULT_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveVault(jobs: BuildJob[]): void {
  try {
    localStorage.setItem(VAULT_KEY, JSON.stringify(jobs.slice(0, 40)));
  } catch {
    // ignore storage quota
  }
}

export function loadActiveJobId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_JOB_KEY);
  } catch {
    return null;
  }
}

export function saveActiveJobId(jobId: string | null): void {
  try {
    if (!jobId) localStorage.removeItem(ACTIVE_JOB_KEY);
    else localStorage.setItem(ACTIVE_JOB_KEY, jobId);
  } catch {
    // ignore
  }
}

export function loadLanguage(): Language {
  try {
    const raw = localStorage.getItem(LANG_KEY);
    return raw === 'hi' ? 'hi' : 'en';
  } catch {
    return 'en';
  }
}

export function saveLanguage(lang: Language): void {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    // ignore
  }
}

export function loadMessages(): CoPilotMessage[] {
  try {
    const raw = localStorage.getItem(MESSAGES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveMessages(messages: CoPilotMessage[]): void {
  try {
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages.slice(-60)));
  } catch {
    // ignore
  }
}

export interface StudioSyncResponse {
  ok: boolean;
  connected: boolean;
  mode?: 'rtdb' | 'firestore';
  syncedAt?: string;
  data?: {
    vault?: BuildJob[];
    activeJobId?: string | null;
    language?: Language;
  } | null;
  error?: string;
}

export async function syncStudioFirebase(
  config: StudioFirebaseConfig,
  action: 'test' | 'push' | 'pull',
  payload?: {
    vault: BuildJob[];
    activeJobId: string | null;
    language: Language;
    mapFooter: string;
  }
): Promise<StudioSyncResponse> {
  try {
    const res = await fetch('/api/firebase/studio-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        databaseUrl: config.databaseUrl,
        projectId: config.projectId,
        apiKey: config.apiKey,
        action,
        payload,
      }),
    });
    return await res.json();
  } catch (err: unknown) {
    const e = err as Error;
    return {
      ok: false,
      connected: false,
      error: e.message || 'Network error syncing Studio Firebase.',
    };
  }
}
