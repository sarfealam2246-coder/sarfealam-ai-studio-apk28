import JSZip from 'jszip';

export interface GitHubValidateResult {
  ok: boolean;
  valid: boolean;
  username?: string;
  name?: string;
  scopes?: string;
  error?: string;
}

export interface GitHubExportResult {
  ok: boolean;
  owner?: string;
  repo?: string;
  repoUrl?: string;
  actionsUrl?: string;
  releasesUrl?: string;
  commitSha?: string;
  pushedFiles?: string[];
  error?: string;
}

export interface GitHubPollResult {
  ok: boolean;
  latestRun?: {
    id: number;
    name: string;
    status: string;
    conclusion: string | null;
    html_url: string;
    updated_at: string;
  } | null;
  apkUrl?: string | null;
  apkSource?: 'release' | 'artifact' | null;
  artifactCount?: number;
  actionsUrl?: string;
  error?: string;
}

export async function validateGitHubToken(token: string): Promise<GitHubValidateResult> {
  try {
    const res = await fetch('/api/github/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
    return await res.json();
  } catch (err: unknown) {
    const e = err as Error;
    return { ok: false, valid: false, error: e.message || 'Failed contacting GitHub validator.' };
  }
}

export async function pushProjectToGitHub(params: {
  token: string;
  repoName: string;
  description: string;
  files: Record<string, string>;
  isPrivate?: boolean;
}): Promise<GitHubExportResult> {
  try {
    const res = await fetch('/api/github/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (err: unknown) {
    const e = err as Error;
    return { ok: false, error: e.message || 'Network error during GitHub export.' };
  }
}

export async function pollGitHubActions(params: {
  token: string;
  owner: string;
  repo: string;
}): Promise<GitHubPollResult> {
  try {
    const res = await fetch('/api/github/poll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (err: unknown) {
    const e = err as Error;
    return { ok: false, error: e.message || 'Failed polling GitHub Actions.' };
  }
}

export async function downloadProjectZip(repoName: string, files: Record<string, string>): Promise<void> {
  const zip = new JSZip();
  for (const [filePath, content] of Object.entries(files)) {
    zip.file(filePath, content);
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${repoName || 'sarfealam-export'}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
