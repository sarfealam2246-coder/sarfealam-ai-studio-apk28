import type {
  BuildJob,
  Language,
  StudioSecrets,
  StudioSkill,
  SystemMapChip,
  SystemMapEdge,
  SystemMapState,
} from '../types/studio';
import { computeSecretsHealth, getActiveApiKeys, PROVIDER_PRESETS } from './secrets';
import { isSkillEnabled } from './skills';

/**
 * Dynamically builds the Display B System Map from:
 * 1) Real user-configured API keys (new key => new named chip!)
 * 2) Muted department placeholders when keys are missing (with explicit reasons)
 * 3) Auto-on Studio Bots (Research Bot, Critic/Self-Heal, Connect Bot, GitHub Bot)
 * 4) GitHub, Studio Firebase, and Apps Firebase targets
 */
export function buildSystemMap(
  secrets: StudioSecrets,
  skills: StudioSkill[],
  job: BuildJob | null,
  lang: Language
): SystemMapState {
  const health = computeSecretsHealth(secrets);
  const activeKeys = getActiveApiKeys(secrets);
  const chips: SystemMapChip[] = [];
  const edges: SystemMapEdge[] = [];

  const stage = job?.stageIndex ?? 0;
  const isRunning = job?.status === 'assembling' || job?.status === 'exporting';
  const isExportReady = job?.status === 'ready';
  const isTesting = job?.status === 'testing';

  // Column 0: Prompt Entry
  chips.push({
    id: 'chip-prompt',
    label: job ? (job.engine === 'godot4' ? 'Prompt · Godot 4' : 'Prompt · Flutter') : 'Prompt',
    role: 'Intake & Skill Match',
    department: 'Intake',
    status: !job ? 'ready' : stage >= 1 ? 'done' : 'active',
    caption: job
      ? `${job.matchedSkills.length} skills matched`
      : lang === 'hi'
        ? 'आइडिया लिखें या बोलें'
        : 'Waiting for prompt',
    column: 0,
  });

  // Column 1: DYNAMIC AI Team Chips from configured keys!
  const agentChipIds: string[] = [];

  if (activeKeys.length === 0) {
    // Honest muted chips with exact missing reasons
    const placeholders: Array<{ id: string; label: string; role: string; reason: string }> = [
      {
        id: 'chip-agent-brain-muted',
        label: 'Brain AI',
        role: 'General / Spec',
        reason: lang === 'hi' ? 'API key नहीं है (Secrets में जोड़ें)' : 'Missing General API key',
      },
      {
        id: 'chip-agent-code-muted',
        label: 'Code AI',
        role: 'Screens & Logic',
        reason: lang === 'hi' ? 'Code या General key नहीं है' : 'Missing Code / General key',
      },
      {
        id: 'chip-agent-vision-muted',
        label: 'Vision / QA',
        role: 'Preview Audit',
        reason: lang === 'hi' ? 'Vision / General key नहीं है' : 'Missing Vision / General key',
      },
    ];

    for (const ph of placeholders) {
      const activeHere = Boolean(
        job &&
          isRunning &&
          ((ph.id.includes('brain') && stage === 1) ||
            (ph.id.includes('code') && (stage === 2 || stage === 3)) ||
            (ph.id.includes('vision') && stage === 4))
      );
      chips.push({
        id: ph.id,
        label: ph.label,
        role: ph.role,
        department: ph.role,
        status: activeHere ? 'warning' : 'muted',
        caption: activeHere
          ? `${ph.label} · local demo fallback`
          : ph.reason,
        reason: ph.reason,
        column: 1,
      });
      agentChipIds.push(ph.id);
      edges.push({
        from: 'chip-prompt',
        to: ph.id,
        active: activeHere,
      });
    }
  } else {
    // Dynamic chips directly driven by every active key the user saved!
    activeKeys.forEach((slot, idx) => {
      const chipId = `chip-key-${slot.id}`;
      const providerLabel = PROVIDER_PRESETS[slot.provider]?.label || slot.provider;
      const chipLabel = slot.name.trim() || `${providerLabel} · ${slot.model || 'AI'}`;
      const modelShort = slot.model.trim() || PROVIDER_PRESETS[slot.provider]?.defaultModel || '';
      const roleSummary = slot.tags.length > 0 ? slot.tags.join(' / ') : 'General';

      const isActiveChip = job?.activeChipId === chipId;
      const wasUsed = job?.usedProviders.some(
        (u) => u.includes(chipLabel) || u.includes(slot.id) || (modelShort && u.includes(modelShort))
      );

      let status: SystemMapChip['status'] = 'ready';
      if (slot.lastTestStatus === 'error') {
        status = 'error';
      } else if (isActiveChip && isRunning) {
        status = 'active';
      } else if (wasUsed && (stage >= 2 || isTesting || isExportReady)) {
        status = 'done';
      } else if (activeKeys.length === 1 && stage >= 1 && isRunning) {
        status = 'active';
      }

      let caption = `${modelShort || providerLabel} · ready`;
      if (isActiveChip && job?.activeWorkCaption) {
        caption = job.activeWorkCaption;
      } else if (status === 'done') {
        caption = `${modelShort || providerLabel} · synced`;
      } else if (status === 'error') {
        caption = slot.lastTestMessage || 'Key error — check Secrets';
      } else if (activeKeys.length === 1) {
        caption = `${modelShort || providerLabel} · all depts (1-key mode)`;
      }

      chips.push({
        id: chipId,
        label: chipLabel,
        role: roleSummary,
        department: roleSummary,
        provider: providerLabel,
        model: modelShort,
        status,
        caption,
        keySlotId: slot.id,
        column: 1,
        isDynamicKeyChip: true,
      });

      agentChipIds.push(chipId);
      edges.push({
        from: 'chip-prompt',
        to: chipId,
        active: isRunning && (isActiveChip || idx === 0),
      });
    });
  }

  // Column 2: Autonomous Bots & Critic / Self-Heal
  const botChipIds: string[] = [];

  // Critic / Self-Heal node
  const criticEnabled = isSkillEnabled(skills, 'self-heal-critic');
  const criticActive = Boolean(job && isRunning && stage === 4 && criticEnabled);
  const criticDone = Boolean(job && stage >= 5 && criticEnabled);
  chips.push({
    id: 'chip-bot-critic',
    label: 'Critic & Self-Heal',
    role: '1–3 Repair Passes',
    department: 'QA',
    status: !criticEnabled
      ? 'muted'
      : criticActive
        ? 'active'
        : criticDone
          ? 'done'
          : 'ready',
    caption: !criticEnabled
      ? 'Disabled in Skills'
      : job?.criticNote
        ? job.criticNote
        : criticDone
          ? `${job?.criticAttempts || 1} pass verified`
          : 'Standby for Stage 4',
    reason: !criticEnabled ? 'Self-Heal skill toggled OFF' : undefined,
    column: 2,
  });
  botChipIds.push('chip-bot-critic');

  // Research Bot (visible when skill enabled or used)
  const researchEnabled = isSkillEnabled(skills, 'research-bot');
  const researchUsed = Boolean(job?.researchSummary);
  chips.push({
    id: 'chip-bot-research',
    label: 'Research Bot',
    role: 'Domain Spec',
    department: 'Bot',
    status: !researchEnabled
      ? 'muted'
      : job?.activeChipId === 'chip-bot-research'
        ? 'active'
        : researchUsed
          ? 'done'
          : 'ready',
    caption: !researchEnabled
      ? 'Disabled in Skills'
      : researchUsed
        ? 'Spec brief shared with team'
        : 'Auto-on when prompt needs info',
    reason: !researchEnabled ? 'Research Bot skill OFF' : undefined,
    column: 2,
  });
  botChipIds.push('chip-bot-research');

  // Connect Bot (auto-highlights when any secret is missing)
  const hasMissingSecrets = health.issues.length > 0;
  chips.push({
    id: 'chip-bot-connect',
    label: 'Connect Bot',
    role: 'Secrets Guard',
    department: 'Bot',
    status: hasMissingSecrets ? 'warning' : 'done',
    caption: hasMissingSecrets
      ? `${health.issues.length} secret${health.issues.length > 1 ? 's' : ''} need attention`
      : 'All studio endpoints healthy',
    reason: hasMissingSecrets ? health.issues[0]?.message : undefined,
    column: 2,
  });
  botChipIds.push('chip-bot-connect');

  // Connect agents -> bots (shared team navigation)
  for (const aId of agentChipIds) {
    edges.push({
      from: aId,
      to: 'chip-bot-critic',
      active: isRunning && stage >= 3,
    });
  }

  // Column 3: Delivery Infrastructure (GitHub + Studio Firebase + Apps Firebase)
  const ghActive = job?.status === 'exporting' || job?.activeChipId === 'chip-github';
  const ghDone = Boolean(job?.exportArtifacts.repoUrl && job?.exportArtifacts.apkStatus !== 'error');
  const ghBlocked = !health.githubConnected;
  chips.push({
    id: 'chip-github',
    label: health.githubConnected
      ? `GitHub · @${secrets.githubToken.username || 'user'}`
      : 'GitHub Bot',
    role: 'Repo + Actions APK',
    department: 'Delivery',
    status: ghBlocked
      ? 'muted'
      : job?.exportArtifacts.apkStatus === 'error'
        ? 'error'
        : ghActive
          ? 'active'
          : ghDone
            ? 'done'
            : 'ready',
    caption: ghBlocked
      ? 'Missing Token1 — blocked'
      : ghActive
        ? 'Pushing repo & workflow...'
        : ghDone
          ? job?.exportArtifacts.apkUrl
            ? 'APK link published to Vault'
            : 'Repo pushed · Actions building'
          : `Connected as @${secrets.githubToken.username}`,
    reason: ghBlocked ? 'Add & validate GitHub Token1 in Secrets' : job?.exportArtifacts.errorReason,
    column: 3,
  });

  // Studio Firebase
  const studioFbConnected = health.studioFirebaseConnected;
  const studioFbSkillOn = isSkillEnabled(skills, 'studio-firebase-sync');
  chips.push({
    id: 'chip-studio-fb',
    label: 'Studio Firebase',
    role: 'Jobs & Vault DB',
    department: 'Persistence',
    status: !studioFbSkillOn
      ? 'muted'
      : studioFbConnected
        ? 'done'
        : secrets.studioFirebase.status === 'error'
          ? 'error'
          : 'muted',
    caption: !studioFbSkillOn
      ? 'Sync skill OFF'
      : studioFbConnected
        ? 'Synced · studio records live'
        : secrets.studioFirebase.lastError
          ? 'Sync error — local fallback'
          : 'Not set · using localStorage',
    reason: !studioFbConnected ? 'Configure Studio Firebase in Secrets for cloud sync' : undefined,
    column: 3,
  });

  // Apps Firebase
  const appsFbConfigured = health.appsFirebaseConfigured;
  const appsFbSkillOn = isSkillEnabled(skills, 'apps-firebase-inject');
  const appsFbInjected = Boolean(job?.exportArtifacts.appsFirebaseInjected);
  chips.push({
    id: 'chip-apps-fb',
    label: appsFbConfigured
      ? `Apps Firebase · ${secrets.appsFirebase.projectId.slice(0, 14)}`
      : 'Apps Firebase',
    role: 'Export Inject',
    department: 'App Backend',
    status: !appsFbSkillOn
      ? 'muted'
      : appsFbInjected
        ? 'done'
        : appsFbConfigured
          ? 'ready'
          : 'muted',
    caption: !appsFbSkillOn
      ? 'Inject skill OFF'
      : appsFbInjected
        ? 'Injected into export config'
        : appsFbConfigured
          ? 'Ready to inject on OK'
          : 'Not set · placeholder on export',
    reason: !appsFbConfigured ? 'Add Apps Firebase in Secrets to inject user DB' : undefined,
    column: 3,
  });

  // Edges from Critic/Bots -> Delivery Targets
  edges.push({
    from: 'chip-bot-critic',
    to: 'chip-github',
    active: ghActive || (isTesting && !ghBlocked),
  });
  edges.push({
    from: 'chip-bot-connect',
    to: 'chip-studio-fb',
    active: studioFbConnected && isRunning,
  });
  edges.push({
    from: 'chip-bot-critic',
    to: 'chip-apps-fb',
    active: appsFbConfigured && (job?.status === 'exporting' || appsFbInjected),
  });

  // Honest Footer computation
  let footerText = '';
  let footerState: SystemMapState['footerState'] = 'idle';

  if (job?.status === 'error') {
    footerText = `${stage}/5 stages · error · ${job.errorMessage || 'check details'}`;
    footerState = 'error';
  } else if (job?.status === 'exporting') {
    footerText = ghBlocked
      ? `${stage}/5 stages · blocked · missing GitHub Token1`
      : `5/5 stages · exporting to GitHub Actions`;
    footerState = ghBlocked ? 'blocked' : 'sync';
  } else if (job?.status === 'ready') {
    footerText = job.exportArtifacts.apkUrl
      ? `5/5 stages · APK & Admin links ready in Vault`
      : job.exportArtifacts.repoUrl
        ? `5/5 stages · pushed to GitHub · awaiting APK artifact`
        : `5/5 stages · local package exported (GitHub Token1 missing)`;
    footerState = job.exportArtifacts.repoUrl ? 'sync' : 'blocked';
  } else if (job && stage > 0) {
    if (!health.hasAnyAiKey) {
      footerText = `${stage}/5 stages · local demo preview · missing AI API key`;
      footerState = 'demo';
    } else if (!health.githubConnected && stage === 5) {
      footerText = `5/5 stages · ready to test · GitHub Token1 needed for cloud APK`;
      footerState = 'blocked';
    } else {
      footerText = `${stage}/5 stages · team in sync (${activeKeys.length} key${activeKeys.length > 1 ? 's' : ''})`;
      footerState = 'sync';
    }
  } else {
    if (!health.hasAnyAiKey && !health.githubConnected) {
      footerText =
        lang === 'hi'
          ? '0/5 स्टेज · ब्लॉक · AI key और GitHub token नहीं है'
          : '0/5 stages · blocked · missing AI key & GitHub token';
      footerState = 'blocked';
    } else if (!health.hasAnyAiKey) {
      footerText = '0/5 stages · blocked · missing AI API key';
      footerState = 'blocked';
    } else if (!health.githubConnected) {
      footerText = `0/5 stages · AI ready (${activeKeys.length}) · missing GitHub token`;
      footerState = 'blocked';
    } else {
      footerText = `0/5 stages · team in sync · ready to assemble`;
      footerState = 'sync';
    }
  }

  return { chips, edges, footerText, footerState };
}
