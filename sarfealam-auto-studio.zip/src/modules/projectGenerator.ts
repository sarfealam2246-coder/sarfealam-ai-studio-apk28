import type {
  AppsFirebaseConfig,
  EngineType,
  PreviewBlueprint,
  ProductType,
  StudioSkill,
} from '../types/studio';
import {
  renderWorkflowForExport,
  type WorkflowTemplateMap,
} from './workflowTemplates';

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 28) || 'sarfealam_app'
  );
}

function deriveAppName(prompt: string, productType: ProductType): string {
  const cleaned = prompt
    .replace(/^(build|create|make|banao|design|develop)\s+(a|an|me|ek)?\s*/i, '')
    .trim();
  const words = cleaned
    .split(/\s+/)
    .filter((w) => w.length > 1 && !['with', 'and', 'for', 'app', 'game', 'wala', 'ek'].includes(w.toLowerCase()))
    .slice(0, 3);
  if (words.length === 0) {
    return productType === 'game' ? 'Velocity Drift 3D' : 'Sarfealam Commerce';
  }
  return words.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export function createBlueprintFromPrompt(
  prompt: string,
  productType: ProductType,
  engine: EngineType,
  matchedSkillIds: string[],
  isDemoSimulation: boolean,
  aiOverride?: Partial<PreviewBlueprint>
): PreviewBlueprint {
  const lower = prompt.toLowerCase();
  const appName = aiOverride?.appName || deriveAppName(prompt, productType);

  const hasWallet = matchedSkillIds.includes('cap-wallet');
  const hasBooking = matchedSkillIds.includes('cap-maps-booking');
  const hasVip = matchedSkillIds.includes('cap-vip-unlock');
  const hasSearch = matchedSkillIds.includes('cap-search');
  const hasOtp = matchedSkillIds.includes('cap-otp-auth');
  const hasCardTable = matchedSkillIds.includes('cap-card-table');
  const hasProfile = matchedSkillIds.includes('cap-profile');

  if (productType === 'game') {
    const isCard =
      hasCardTable ||
      ['card', 'rummy', 'poker', 'teen patti', 'table', 'ताश'].some((k) => lower.includes(k));
    const isRacing = ['race', 'racing', 'car', 'drift', 'highway', 'bike', 'रेसिंग', 'कार'].some((k) =>
      lower.includes(k)
    );
    const gameGenre: PreviewBlueprint['gameGenre'] = isCard
      ? 'card-table'
      : isRacing
        ? 'racing'
        : 'arcade';

    return {
      appName,
      tagline:
        aiOverride?.tagline ||
        (isCard
          ? 'Real-time felt card table & hand logic'
          : isRacing
            ? 'Touch steer · throttle · nitro drift circuit'
            : '60 FPS Godot 4 touch arcade arena'),
      productType: 'game',
      engine,
      accentHex: '#06B6D4',
      tabs: isCard ? ['Table', 'Lobby', 'Chips', 'Rank'] : ['Play', 'Garage', 'Ranks', 'Store'],
      heroTitle: aiOverride?.heroTitle || appName,
      heroSubtitle:
        aiOverride?.heroSubtitle ||
        (isCard
          ? '3-Card / Rummy table ready for interactive deal & turn tests.'
          : 'Use Steer Left / Right, Gas, and Brake below to test physics loop.'),
      primaryMetricLabel: isCard ? 'Table Pot' : 'Top Speed',
      primaryMetricValue: isCard ? '2,400 Chips' : '184 km/h',
      secondaryMetricLabel: isCard ? 'Players' : 'Target FPS',
      secondaryMetricValue: isCard ? '4 Seated' : '60 FPS',
      items: aiOverride?.items || [
        { title: isCard ? 'Classic Table' : 'Neon Circuit', subtitle: 'Low-latency Android touch input', meta: 'Stage 5' },
        { title: isCard ? 'VIP High Roller' : 'Desert Drift', subtitle: 'Dynamic physics & HUD loop', meta: 'Godot 4' },
      ],
      gameGenre,
      gameGoal: isCard ? 'Win the pot across 3 rounds' : 'Stay on lane & hit checkpoints',
      featuresActive: matchedSkillIds,
      aiGeneratedNote: aiOverride?.aiGeneratedNote,
      isDemoSimulation,
    };
  }

  // Commercial / Utility Flutter App Blueprint
  const tabs: string[] = ['Home'];
  if (hasBooking) tabs.push('Book');
  else if (hasSearch) tabs.push('Explore');
  else tabs.push('Feed');

  if (hasWallet) tabs.push('Wallet');
  else if (hasVip) tabs.push('VIP');
  else tabs.push('Orders');

  tabs.push(hasProfile || hasOtp ? 'Profile' : 'Account');

  const defaultItems = hasBooking
    ? [
        { title: 'Express Pickup · Sector 18', subtitle: 'ETA 4 min · Verified captain', meta: '₹149' },
        { title: 'Airport Transfer · Terminal 3', subtitle: 'Fixed fare · AC Sedan', meta: '₹599' },
        { title: 'Priority VIP Slot', subtitle: 'Zero wait time · Priority dispatch', meta: 'VIP' },
      ]
    : hasWallet
      ? [
          { title: 'Instant UPI Deposit', subtitle: 'Settled to primary balance', meta: '+₹2,500' },
          { title: 'Merchant QR Checkout', subtitle: 'Zero fee transfer', meta: '-₹420' },
          { title: 'Cashback Reward', subtitle: 'Auto-credited loyalty tier', meta: '+₹65' },
        ]
      : [
          { title: `${appName} Core Module`, subtitle: 'Primary interactive workspace list', meta: 'Active' },
          { title: 'Live Customer Request', subtitle: 'Real-time status sync ready', meta: 'New' },
          { title: 'Analytics Overview', subtitle: 'Daily summary & quick actions', meta: 'Today' },
        ];

  return {
    appName,
    tagline:
      aiOverride?.tagline ||
      (hasBooking
        ? 'Instant booking, route ETA & live status'
        : hasWallet
          ? 'Fast wallet ledger, balance & instant checkout'
          : 'Production Flutter mobile application'),
    productType: 'app',
    engine,
    accentHex: '#06B6D4',
    tabs: aiOverride?.tabs && aiOverride.tabs.length >= 2 ? aiOverride.tabs.slice(0, 4) : tabs,
    heroTitle: aiOverride?.heroTitle || appName,
    heroSubtitle:
      aiOverride?.heroSubtitle ||
      (hasBooking
        ? 'Confirm pickup, compare fares, and track live arrival.'
        : hasWallet
          ? 'Track available balance, top up instantly, and manage payouts.'
          : 'Clean mobile-first interface ready for interactive testing.'),
    primaryMetricLabel: hasWallet ? 'Wallet Balance' : hasBooking ? 'Active Bookings' : 'Active Items',
    primaryMetricValue: hasWallet ? '₹12,480' : hasBooking ? '3 Live' : '24 Ready',
    secondaryMetricLabel: hasVip ? 'Membership' : hasOtp ? 'Auth Mode' : 'Target Build',
    secondaryMetricValue: hasVip ? 'VIP Ready' : hasOtp ? 'OTP + Gmail' : 'Android APK',
    items: aiOverride?.items && aiOverride.items.length > 0 ? aiOverride.items : defaultItems,
    featuresActive: matchedSkillIds,
    aiGeneratedNote: aiOverride?.aiGeneratedNote,
    isDemoSimulation,
  };
}

export interface GeneratedProjectBundle {
  files: Record<string, string>;
  workflowPath: string;
  workflowInjected: boolean;
  appsFirebaseInjected: boolean;
  repoSuggestedName: string;
}

/**
 * Generates real, inspectable, GitHub-Actions-ready Flutter or Godot 4 project files.
 * Strictly honors enabled skills, pulls managed GitHub Actions YAML from workflowTemplates,
 * and injects Apps Firebase config only when configured + skill ON.
 */
export function generateProjectBundle(params: {
  title: string;
  prompt: string;
  engine: EngineType;
  blueprint: PreviewBlueprint;
  matchedSkillIds: string[];
  allSkills: StudioSkill[];
  appsFirebase: AppsFirebaseConfig;
  adminBannerText: string;
  vipNote: string;
  workflowTemplates?: WorkflowTemplateMap;
}): GeneratedProjectBundle {
  const {
    title,
    prompt,
    engine,
    blueprint,
    matchedSkillIds,
    appsFirebase,
    adminBannerText,
    vipNote,
    workflowTemplates,
  } = params;
  const slug = slugify(title || blueprint.appName);
  const repoSuggestedName = `sarfealam-${slug.replace(/_/g, '-')}`;
  const hasSkill = (id: string) => matchedSkillIds.includes(id);

  const injectAppsFb = hasSkill('apps-firebase-inject') && appsFirebase.configured;
  const files: Record<string, string> = {};

  const nowIso = new Date().toISOString();

  // Optional Architecture Spec (honors cap-prompt-expand)
  if (hasSkill('cap-prompt-expand')) {
    files['ARCHITECTURE_SPEC.md'] = `# ${blueprint.appName} — Architecture Specification
Generated by Sarfealam Auto-Studio on ${nowIso}

## Original Prompt
${prompt}

## Target Engine
- Engine: ${engine === 'godot4' ? 'Godot 4 (Android Export)' : 'Flutter 3.24+ (Android Release APK)'}
- Product Type: ${blueprint.productType}
- Apps Firebase Injected: ${injectAppsFb ? `YES (${appsFirebase.projectId})` : 'NO (placeholder config — configure Apps Firebase in Secrets)'}

## Applied Skills (${matchedSkillIds.length})
${matchedSkillIds.map((id) => `- ${id}`).join('\n')}
`;
  }

  // Optional Play Store listing draft (honors cap-store-listing)
  if (hasSkill('cap-store-listing')) {
    files['PLAY_STORE_LISTING.md'] = `# Google Play Store Listing Draft
- **App Title**: ${blueprint.appName}
- **Short Description**: ${blueprint.tagline}
- **Category**: ${blueprint.productType === 'game' ? 'Games / Action' : 'Productivity / Lifestyle'}

## Full Description
${blueprint.heroSubtitle}

### Key Highlights
- Mobile-first high-contrast UI optimized for thumb ergonomics
${hasSkill('cap-wallet') ? '- Built-in wallet balance & transaction ledger\n' : ''}${hasSkill('cap-otp-auth') ? '- Phone OTP & Google Sign-In ready architecture\n' : ''}${hasSkill('cap-i18n-hi-en') ? '- Bilingual English & Hindi support\n' : ''}${hasSkill('cap-offline-cache') ? '- Local offline cache support for low-connectivity areas\n' : ''}`;
  }

  // Optional Release notes (honors cap-release-notes)
  if (hasSkill('cap-release-notes')) {
    files['CHANGELOG.md'] = `# Changelog\n\n## v1.0.0 (${nowIso.slice(0, 10)})\n- Initial autonomous assembly via Sarfealam Auto-Studio\n- Engine: ${engine}\n- Matched skills: ${matchedSkillIds.join(', ')}\n`;
  }

  if (engine === 'flutter') {
    const renderedWorkflow = renderWorkflowForExport(
      'flutter',
      {
        appName: blueprint.appName,
        appSlug: slug,
        flutterBuildFlags: hasSkill('cap-perf-budget') ? '--tree-shake-icons' : '',
      },
      workflowTemplates
    );
    const workflowPath = renderedWorkflow.filePath;
    const workflowInjected = hasSkill('flutter-workflow-path');

    files['pubspec.yaml'] = `name: ${slug}
description: "${blueprint.tagline.replace(/"/g, "'")}"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.4.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8
${injectAppsFb ? '  firebase_core: ^3.6.0\n  cloud_firestore: ^5.4.4\n' : ''}${hasSkill('cap-offline-cache') ? '  shared_preferences: ^2.3.2\n' : ''}
dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true
`;

    // Dual Firebase Rule 7: Apps Firebase injected strictly into generated app config
    files['lib/firebase_options.dart'] = `// Generated by Sarfealam Auto-Studio (Apps Firebase Injection)
// Status: ${injectAppsFb ? 'CONFIGURED FROM SECRETS > APPS FIREBASE' : 'PLACEHOLDER (Configure Apps Firebase in Studio Secrets to inject real server)'}

class AppsFirebaseConfig {
  static const bool isConfigured = ${injectAppsFb ? 'true' : 'false'};
  static const String projectId = '${injectAppsFb ? appsFirebase.projectId : 'YOUR_APPS_FIREBASE_PROJECT_ID'}';
  static const String apiKey = '${injectAppsFb ? appsFirebase.apiKey : 'YOUR_APPS_FIREBASE_API_KEY'}';
  static const String appId = '${injectAppsFb ? appsFirebase.appId || '1:000000000000:android:app' : 'YOUR_APPS_FIREBASE_APP_ID'}';
  static const String databaseUrl = '${injectAppsFb ? appsFirebase.databaseUrl : ''}';
  static const String storageBucket = '${injectAppsFb ? appsFirebase.storageBucket : ''}';
  static const String messagingSenderId = '${injectAppsFb ? appsFirebase.messagingSenderId : ''}';
}
`;

    files['lib/admin_config.dart'] = `// Synced from Sarfealam Auto-Studio Admin Tab
class StudioAdminDefaults {
  static const String bannerMessage = '${(adminBannerText || 'Welcome to ' + blueprint.appName).replace(/'/g, "\\'")}';
  static const String vipPlanNote = '${(vipNote || 'VIP plan unlocks priority features').replace(/'/g, "\\'")}';
  static const List<String> enabledCapabilities = [
${matchedSkillIds.filter((s) => s.startsWith('cap-')).map((s) => `    '${s}',`).join('\n')}
  ];
}
`;

    if (hasSkill('cap-i18n-hi-en')) {
      files['lib/l10n/strings.dart'] = `class AppStrings {
  static const Map<String, Map<String, String>> values = {
    'en': {
      'title': '${blueprint.appName.replace(/'/g, "\\'")}',
      'subtitle': '${blueprint.tagline.replace(/'/g, "\\'")}',
      'action': 'Continue',
    },
    'hi': {
      'title': '${blueprint.appName.replace(/'/g, "\\'")}',
      'subtitle': 'सर्फ़ेआलम ऑटो-स्टूडियो द्वारा निर्मित',
      'action': 'आगे बढ़ें',
    },
  };
}
`;
    }

    files['lib/main.dart'] = `import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'admin_config.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GeneratedStudioApp());
}

class GeneratedStudioApp extends StatelessWidget {
  const GeneratedStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '${blueprint.appName.replace(/'/g, "\\'")}',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF070B14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF06B6D4),
          surface: Color(0xFF0E1525),
        ),
      ),
      home: const HomeShellScreen(),
    );
  }
}

class HomeShellScreen extends StatefulWidget {
  const HomeShellScreen({super.key});

  @override
  State<HomeShellScreen> createState() => _HomeShellScreenState();
}

class _HomeShellScreenState extends State<HomeShellScreen> {
  int _tabIndex = 0;
  final List<String> _tabs = const [${blueprint.tabs.map((t) => `'${t.replace(/'/g, "\\'")}'`).join(', ')}];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E1525),
        title: const Text('${blueprint.appName.replace(/'/g, "\\'")}'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF0E1525),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF1E293B)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '${blueprint.heroTitle.replace(/'/g, "\\'")}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                const Text(
                  '${blueprint.heroSubtitle.replace(/'/g, "\\'")}',
                  style: TextStyle(color: Color(0xFF94A3B8)),
                ),
                const SizedBox(height: 12),
                Text(
                  'Apps Firebase: \${AppsFirebaseConfig.isConfigured ? AppsFirebaseConfig.projectId : "Not configured"}',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF06B6D4)),
                ),
                const SizedBox(height: 6),
                Text(
                  StudioAdminDefaults.bannerMessage,
                  style: const TextStyle(fontSize: 12, color: Color(0xFFCBD5E1)),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: _tabs
            .map((label) => NavigationDestination(icon: const Icon(Icons.circle_outlined), label: label))
            .toList(),
      ),
    );
  }
}
`;

    if (workflowInjected) {
      files[workflowPath] = renderedWorkflow.content;
    }

    files['README.md'] = `# ${blueprint.appName}

Generated by **Sarfealam Auto-Studio** (Flutter Android APK Pipeline).

- **Engine**: Flutter 3.24+
- **Apps Firebase Injected**: ${injectAppsFb ? `Yes (${appsFirebase.projectId})` : 'No (placeholder in lib/firebase_options.dart)'}
- **Workflow**: ${workflowInjected ? `\`${workflowPath}\` (${renderedWorkflow.isCustomized ? 'Custom Studio Template' : 'Default Boilerplate'})` : 'Skipped (Flutter Workflow Path skill OFF)'}

Push to \`main\` or run **Build Android Release APK (Flutter)** in GitHub Actions to produce \`app-release.apk\`.
`;

    return { files, workflowPath, workflowInjected, appsFirebaseInjected: injectAppsFb, repoSuggestedName };
  }

  // === GODOT 4 (3D / GAME) EXPORT PATH ===
  const renderedGodotWorkflow = renderWorkflowForExport(
    'godot4',
    {
      appName: blueprint.appName,
      appSlug: slug,
    },
    workflowTemplates
  );
  const workflowPath = renderedGodotWorkflow.filePath;
  const workflowInjected = hasSkill('godot4-workflow-path');

  files['project.godot'] = `; Engine configuration file generated by Sarfealam Auto-Studio
config_version=5

[application]
config/name="${blueprint.appName.replace(/"/g, "'")}"
run/main_scene="res://scenes/main.tscn"
config/features=PackedStringArray("4.3", "Mobile")

[display]
window/size/viewport_width=1080
window/size/viewport_height=1920
window/handheld/orientation=1

[rendering]
renderer/rendering_method="mobile"
`;

  files['scripts/apps_firebase_bridge.gd'] = `# Generated by Sarfealam Auto-Studio (Apps Firebase Injection)
extends Node

const IS_CONFIGURED: bool = ${injectAppsFb ? 'true' : 'false'}
const PROJECT_ID: String = "${injectAppsFb ? appsFirebase.projectId : 'YOUR_APPS_FIREBASE_PROJECT_ID'}"
const API_KEY: String = "${injectAppsFb ? appsFirebase.apiKey : 'YOUR_APPS_FIREBASE_API_KEY'}"
const DATABASE_URL: String = "${injectAppsFb ? appsFirebase.databaseUrl : ''}"

func get_leaderboard_endpoint() -> String:
\tif DATABASE_URL.is_empty():
\t\treturn ""
\treturn DATABASE_URL.rstrip("/") + "/scores.json"
`;

  files['scripts/player_controller.gd'] = `extends Node2D

@export var max_speed: float = 420.0
@export var steer_speed: float = 260.0

var speed: float = 0.0
var steer_input: float = 0.0
var gas_pressed: bool = false
var brake_pressed: bool = false

func _process(delta: float) -> void:
\tif gas_pressed:
\t\tspeed = min(speed + 240.0 * delta, max_speed)
\telif brake_pressed:
\t\tspeed = max(speed - 380.0 * delta, 0.0)
\telse:
\t\tspeed = max(speed - 90.0 * delta, 0.0)

\tposition.x = clamp(position.x + steer_input * steer_speed * delta, 80.0, 1000.0)
`;

  files['scenes/main.tscn'] = `[gd_scene load_steps=2 format=3]

[ext_resource type="Script" path="res://scripts/player_controller.gd" id="1"]

[node name="MainWorld" type="Node2D"]
script = ExtResource("1")
`;

  files['export_presets.cfg'] = `[preset.0]
name="Android"
platform="Android"
runnable=true
export_filter="all_resources"
export_path="build/android/${slug}.apk"

[preset.0.options]
package/unique_name="com.sarfealam.${slug}"
package/name="${blueprint.appName.replace(/"/g, "'")}"
architectures/arm64-v8a=true
`;

  if (workflowInjected) {
    files[workflowPath] = renderedGodotWorkflow.content;
  }

  files['README.md'] = `# ${blueprint.appName} (Godot 4)

Generated by **Sarfealam Auto-Studio** (Godot 4 Android Export Pipeline).

- **Engine**: Godot 4.3 Mobile Renderer
- **Apps Firebase Injected**: ${injectAppsFb ? `Yes (${appsFirebase.projectId})` : 'No (placeholder in scripts/apps_firebase_bridge.gd)'}
- **Workflow**: ${workflowInjected ? `\`${workflowPath}\` (${renderedGodotWorkflow.isCustomized ? 'Custom Studio Template' : 'Default Boilerplate'})` : 'Skipped (Godot 4 Workflow Path skill OFF)'}
`;

  return { files, workflowPath, workflowInjected, appsFirebaseInjected: injectAppsFb, repoSuggestedName };
}
