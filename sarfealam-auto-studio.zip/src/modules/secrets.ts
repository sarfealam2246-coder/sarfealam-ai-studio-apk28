import type {
  AIProviderId,
  ApiKeySlot,
  KeyTag,
  SecretsHealth,
  StudioSecrets,
} from '../types/studio';

const SECRETS_STORAGE_KEY = 'sarfealam_studio_secrets_v1';

export const PROVIDER_PRESETS: Record<
  AIProviderId,
  { label: string; defaultModel: string; defaultBaseUrl: string; placeholderKey: string; hint: string }
> = {
  gemini: {
    label: 'Google Gemini',
    defaultModel: 'gemini-4-hydrogen',
    defaultBaseUrl: '',
    placeholderKey: 'AIzaSy...',
    hint: 'Uses @google/genai SDK on backend. Fast, multimodal, strong code & Hindi.',
  },
  groq: {
    label: 'Groq Cloud',
    defaultModel: 'llama-3.3-70b-versatile',
    defaultBaseUrl: 'https://api.groq.com/openai/v1',
    placeholderKey: 'gsk_...',
    hint: 'Ultra-low latency Fast/Fallback department.',
  },
  nvidia: {
    label: 'NVIDIA NIM',
    defaultModel: 'meta/llama-3.1-70b-instruct',
    defaultBaseUrl: 'https://integrate.api.nvidia.com/v1',
    placeholderKey: 'nvapi-...',
    hint: 'One NIM key can power multiple models (add extra slots with different model names).',
  },
  qwen: {
    label: 'Qwen (DashScope)',
    defaultModel: 'qwen-plus',
    defaultBaseUrl: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
    placeholderKey: 'sk-...',
    hint: 'Strong Code/Builder and multilingual reasoning.',
  },
  openai: {
    label: 'OpenAI',
    defaultModel: 'gpt-4o-mini',
    defaultBaseUrl: 'https://api.openai.com/v1',
    placeholderKey: 'sk-proj-...',
    hint: 'General, Code, and Vision compatible.',
  },
  openrouter: {
    label: 'OpenRouter',
    defaultModel: 'google/gemini-2.0-flash-001',
    defaultBaseUrl: 'https://openrouter.ai/api/v1',
    placeholderKey: 'sk-or-...',
    hint: 'Unified gateway to 100+ models.',
  },
  deepseek: {
    label: 'DeepSeek',
    defaultModel: 'deepseek-chat',
    defaultBaseUrl: 'https://api.deepseek.com/v1',
    placeholderKey: 'sk-...',
    hint: 'Strong Code and Reason/Hard department.',
  },
  mistral: {
    label: 'Mistral',
    defaultModel: 'mistral-small-latest',
    defaultBaseUrl: 'https://api.mistral.ai/v1',
    placeholderKey: '...',
    hint: 'Fast structured output & code generation.',
  },
  custom: {
    label: 'Custom OpenAI-Compatible',
    defaultModel: 'custom-model',
    defaultBaseUrl: 'https://your-endpoint/v1',
    placeholderKey: 'sk-...',
    hint: 'Any OpenAI-compatible inference server.',
  },
};

export const ALL_KEY_TAGS: KeyTag[] = [
  'General',
  'Code',
  'Fast',
  'Vision',
  'Primary',
  'Fallback',
  'Reason',
];

export function createDefaultApiKeySlots(): ApiKeySlot[] {
  return [
    {
      id: 'slot-1',
      slotIndex: 1,
      name: 'Gemini Brain',
      provider: 'gemini',
      model: 'gemini-4-hydrogen',
      baseUrl: '',
      apiKey: '',
      tags: ['General', 'Primary'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-2',
      slotIndex: 2,
      name: 'Qwen Code AI',
      provider: 'qwen',
      model: 'qwen-plus',
      baseUrl: PROVIDER_PRESETS.qwen.defaultBaseUrl,
      apiKey: '',
      tags: ['Code'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-3',
      slotIndex: 3,
      name: 'Groq Fast',
      provider: 'groq',
      model: 'llama-3.3-70b-versatile',
      baseUrl: PROVIDER_PRESETS.groq.defaultBaseUrl,
      apiKey: '',
      tags: ['Fast', 'Fallback'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-4',
      slotIndex: 4,
      name: 'NVIDIA NIM Reason',
      provider: 'nvidia',
      model: 'meta/llama-3.1-70b-instruct',
      baseUrl: PROVIDER_PRESETS.nvidia.defaultBaseUrl,
      apiKey: '',
      tags: ['Reason', 'Code'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-5',
      slotIndex: 5,
      name: 'Vision QA Agent',
      provider: 'gemini',
      model: 'gemini-4-hydrogen',
      baseUrl: '',
      apiKey: '',
      tags: ['Vision'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-6',
      slotIndex: 6,
      name: 'DeepSeek Critic',
      provider: 'deepseek',
      model: 'deepseek-chat',
      baseUrl: PROVIDER_PRESETS.deepseek.defaultBaseUrl,
      apiKey: '',
      tags: ['Reason', 'Fallback'],
      enabled: true,
      lastTestStatus: 'untested',
    },
    {
      id: 'slot-7',
      slotIndex: 7,
      name: 'Custom Slot 7',
      provider: 'openrouter',
      model: 'anthropic/claude-3.5-sonnet',
      baseUrl: PROVIDER_PRESETS.openrouter.defaultBaseUrl,
      apiKey: '',
      tags: ['General', 'Fallback'],
      enabled: true,
      lastTestStatus: 'untested',
    },
  ];
}

export function createDefaultSecrets(): StudioSecrets {
  return {
    apiKeys: createDefaultApiKeySlots(),
    githubToken: {
      token: '',
      status: 'unconfigured',
    },
    reserveToken: {
      label: 'Token2 (Reserve)',
      token: '',
    },
    voiceKey: {
      provider: 'browser-web-speech',
      apiKey: '',
      model: 'web-speech-native',
    },
    studioFirebase: {
      databaseUrl: '',
      projectId: '',
      apiKey: '',
      status: 'unconfigured',
    },
    appsFirebase: {
      projectId: '',
      apiKey: '',
      appId: '',
      databaseUrl: '',
      storageBucket: '',
      messagingSenderId: '',
      configured: false,
    },
  };
}

export function loadSecrets(): StudioSecrets {
  try {
    const raw = localStorage.getItem(SECRETS_STORAGE_KEY);
    if (!raw) return createDefaultSecrets();
    const parsed = JSON.parse(raw) as Partial<StudioSecrets>;
    const defaults = createDefaultSecrets();
    const apiKeys =
      Array.isArray(parsed.apiKeys) && parsed.apiKeys.length >= 7
        ? parsed.apiKeys
        : defaults.apiKeys.map((def, idx) => ({
            ...def,
            ...(parsed.apiKeys?.[idx] || {}),
          }));

    return {
      apiKeys,
      githubToken: { ...defaults.githubToken, ...(parsed.githubToken || {}) },
      reserveToken: { ...defaults.reserveToken, ...(parsed.reserveToken || {}) },
      voiceKey: { ...defaults.voiceKey, ...(parsed.voiceKey || {}) },
      studioFirebase: { ...defaults.studioFirebase, ...(parsed.studioFirebase || {}) },
      appsFirebase: {
        ...defaults.appsFirebase,
        ...(parsed.appsFirebase || {}),
        configured: Boolean(
          (parsed.appsFirebase?.projectId || '').trim() &&
            ((parsed.appsFirebase?.apiKey || '').trim() || (parsed.appsFirebase?.databaseUrl || '').trim())
        ),
      },
    };
  } catch {
    return createDefaultSecrets();
  }
}

export function saveSecrets(secrets: StudioSecrets): StudioSecrets {
  const normalized: StudioSecrets = {
    ...secrets,
    appsFirebase: {
      ...secrets.appsFirebase,
      configured: Boolean(
        secrets.appsFirebase.projectId.trim() &&
          (secrets.appsFirebase.apiKey.trim() || secrets.appsFirebase.databaseUrl.trim())
      ),
    },
  };
  try {
    localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(normalized));
  } catch {
    // ignore
  }
  return normalized;
}

export function getActiveApiKeys(secrets: StudioSecrets): ApiKeySlot[] {
  return secrets.apiKeys.filter((k) => k.enabled && k.apiKey.trim().length > 0);
}

export function computeSecretsHealth(secrets: StudioSecrets): SecretsHealth {
  const activeKeys = getActiveApiKeys(secrets);
  const hasAnyAiKey = activeKeys.length > 0;
  const githubConnected = secrets.githubToken.status === 'valid' && secrets.githubToken.token.trim().length > 0;
  const studioFirebaseConnected =
    secrets.studioFirebase.status === 'connected' &&
    Boolean(secrets.studioFirebase.databaseUrl.trim() || secrets.studioFirebase.projectId.trim());
  const appsFirebaseConfigured = secrets.appsFirebase.configured;
  const voiceConfigured =
    secrets.voiceKey.provider === 'browser-web-speech' || secrets.voiceKey.apiKey.trim().length > 0;

  const issues: SecretsHealth['issues'] = [];

  if (!hasAnyAiKey) {
    issues.push({
      id: 'missing-ai-key',
      severity: 'error',
      message: 'No AI API key configured. Add at least 1 General key in Secrets to activate live AI team routing.',
      messageHi: 'कोई AI API key सेव नहीं है। असली AI टीम रूटिंग के लिए Secrets में कम से कम 1 General key जोड़ें।',
      targetSection: 'api-keys',
    });
  }

  if (!githubConnected) {
    issues.push({
      id: 'missing-github',
      severity: 'warning',
      message: secrets.githubToken.token.trim()
        ? 'GitHub Token1 is saved but not yet validated. Tap Validate in Secrets.'
        : 'Missing GitHub Token1 — real repo push & Actions APK build are blocked until connected.',
      messageHi: secrets.githubToken.token.trim()
        ? 'GitHub Token1 सेव है लेकिन अभी वेरिफाई नहीं हुआ। Secrets में Validate दबाएं।'
        : 'GitHub Token1 नहीं है — असली रेपो पुश और Actions APK बिल्ड के लिए इसे जोड़ें।',
      targetSection: 'tokens',
    });
  }

  if (!studioFirebaseConnected) {
    issues.push({
      id: 'missing-studio-fb',
      severity: 'warning',
      message: 'Studio Firebase not connected — jobs & vault persist in local browser storage only.',
      messageHi: 'Studio Firebase कनेक्ट नहीं है — जॉब्स और वॉल्ट अभी लोकल स्टोरेज में सेव हो रहे हैं।',
      targetSection: 'studio-firebase',
    });
  }

  if (!appsFirebaseConfigured) {
    issues.push({
      id: 'missing-apps-fb',
      severity: 'warning',
      message: 'Apps Firebase not configured — exported Flutter/Godot projects will include placeholder config.',
      messageHi: 'Apps Firebase सेट नहीं है — एक्सपोर्ट प्रोजेक्ट में अभी प्लेसहोल्डर कॉन्फ़िग जाएगा।',
      targetSection: 'apps-firebase',
    });
  }

  return {
    activeKeyCount: activeKeys.length,
    hasAnyAiKey,
    githubConnected,
    studioFirebaseConnected,
    appsFirebaseConfigured,
    voiceConfigured,
    issues,
  };
}
