import type { EngineType, ProductType, StudioSkill } from '../types/studio';

const SKILLS_STORAGE_KEY = 'sarfealam_studio_skills_v1';

export const DEFAULT_SKILLS: StudioSkill[] = [
  // === PIPELINE SKILLS (22) ===
  {
    id: 'prompt-skill-match',
    name: 'Prompt → Skill Match',
    nameHi: 'प्रॉम्प्ट → स्किल मैच',
    category: 'pipeline',
    description: 'Matches incoming user prompts against active capability skills before assembly.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'assembly-stages-a',
    name: 'Assembly Stages (Display A)',
    nameHi: 'असेंबली स्टेज (डिस्प्ले A)',
    category: 'pipeline',
    description: 'Runs progressive 5-stage visual assembly (Shell → Ready to test) on Display A.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'system-map-b',
    name: 'System Map Team Navigation (Display B)',
    nameHi: 'सिस्टम मैप टीम नेविगेशन (डिस्प्ले B)',
    category: 'pipeline',
    description: 'Routes agents across connected Display B chips with shared stage context.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'background-job-survivor',
    name: 'Background Job Survivor',
    nameHi: 'बैकग्राउंड जॉब सर्वाइवर',
    category: 'pipeline',
    description: 'Persists active build stage & vault state across browser refresh or app switch.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'live-voice-command',
    name: 'Live Voice Command',
    nameHi: 'लाइव वॉइस कमांड',
    category: 'pipeline',
    description: 'Enables call-style continuous Live ON/OFF voice commands driving studio UI.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'screen-aware-copilot',
    name: 'Screen-Aware Co-Pilot',
    nameHi: 'स्क्रीन-अवेयर को-पायलट',
    category: 'pipeline',
    description: 'Feeds current tab, stage index, active chip, and secrets health into Co-Pilot.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'secrets-health',
    name: 'Secrets Health Diagnostics',
    nameHi: 'सीक्रेट्स हेल्थ जांच',
    category: 'pipeline',
    description: 'Audits API keys, GitHub token, and Dual Firebases on startup and every save.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'rate-limit-fallback',
    name: 'Rate-Limit Fallback',
    nameHi: 'रेट-लिमिट फॉलबैक',
    category: 'pipeline',
    description: 'Automatically rotates to the next eligible tagged key on 429 or provider errors.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'self-heal-critic',
    name: 'Self-Heal / Critic (1–3 Pass)',
    nameHi: 'सेल्फ-हील / क्रिटिक (1–3 पास)',
    category: 'pipeline',
    description: 'Runs 1–3 critic verification passes during Stage 4 and surfaces repairs on Display B.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'checkpoint-rollback',
    name: 'Checkpoint & Rollback',
    nameHi: 'चेकपॉइंट और रोलबैक',
    category: 'pipeline',
    description: 'Saves stage snapshots so Cancel or Fix rolls back cleanly without losing history.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'vision-qa-preview',
    name: 'Vision QA on Preview',
    nameHi: 'प्रीव्यू पर विज़न QA',
    category: 'pipeline',
    description: 'Audits contrast, touch targets, and layout completeness before Stage 5 unlock.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'engine-picker',
    name: 'Engine Picker (Flutter vs Godot 4)',
    nameHi: 'इंजन पिकर (Flutter बनाम Godot 4)',
    category: 'pipeline',
    description: 'Auto-selects Flutter for commercial apps and Godot 4 for 3D/arcade/table games.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'flutter-workflow-path',
    name: 'Flutter Project + Workflow Path',
    nameHi: 'Flutter प्रोजेक्ट + वर्कफ़्लो पाथ',
    category: 'pipeline',
    description: 'Generates pubspec.yaml, Dart screens, Android gradle, and Flutter APK GitHub Action.',
    enabled: true,
    keywords: ['flutter', 'app', 'store', 'booking', 'wallet', 'chat', 'tracker'],
    engineHint: 'flutter',
  },
  {
    id: 'godot4-workflow-path',
    name: 'Godot 4 Project + Workflow Path',
    nameHi: 'Godot 4 प्रोजेक्ट + वर्कफ़्लो पाथ',
    category: 'pipeline',
    description: 'Generates project.godot, GDScript controllers, export presets, and Godot 4 APK Action.',
    enabled: true,
    keywords: ['game', '3d', 'racing', 'car', 'drift', 'arcade', 'shooter', 'godot', 'card', 'rummy', 'poker', 'गेम', 'रेसिंग'],
    engineHint: 'godot4',
  },
  {
    id: 'github-connect-push',
    name: 'GitHub Connect & Push',
    nameHi: 'GitHub कनेक्ट और पुश',
    category: 'pipeline',
    description: 'Creates/updates a real GitHub repo via Token1 and commits generated files on OK.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'actions-status-poll',
    name: 'Actions Status Poll',
    nameHi: 'Actions स्टेटस पोल',
    category: 'pipeline',
    description: 'Polls GitHub Actions runs, artifacts, and releases for real APK output.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'publish-apk-link',
    name: 'Publish APK Link to Vault/Admin',
    nameHi: 'APK लिंक वॉल्ट/एडमिन में पब्लिश',
    category: 'pipeline',
    description: 'Surfaces the Apps APK download link directly inside Vault and Admin panels.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'publish-admin-link',
    name: 'Publish Admin Final Link to Vault/Admin',
    nameHi: 'एडमिन फाइनल लिंक पब्लिश',
    category: 'pipeline',
    description: 'Generates and links the build-specific Admin control route inside Vault & Admin.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'studio-firebase-sync',
    name: 'Studio Firebase Sync',
    nameHi: 'स्टूडियो Firebase सिंक',
    category: 'pipeline',
    description: 'Syncs studio jobs, vault records, stage state, and language to Studio Firebase.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'apps-firebase-inject',
    name: 'Apps Firebase Inject',
    nameHi: 'ऐप्स Firebase इंजेक्ट',
    category: 'pipeline',
    description: 'Injects Apps Firebase config into generated Flutter/Godot exports on OK.',
    enabled: true,
    keywords: [],
  },
  {
    id: 'research-bot',
    name: 'Research Bot',
    nameHi: 'रिसर्च बॉट',
    category: 'pipeline',
    description: 'Auto-activates when a prompt requests domain benchmarks, rules, or market specs.',
    enabled: true,
    keywords: ['research', 'compare', 'market', 'benchmark', 'rules', 'spec', 'compliance', 'gst', 'upi'],
  },
  {
    id: 'oss-asset-hint',
    name: 'Open-Source Asset Hint',
    nameHi: 'ओपन-सोर्स एसेट हिंट',
    category: 'pipeline',
    description: 'Suggests CC0 / MIT open-source icons, fonts, and Kenney/Polyhaven game assets.',
    enabled: true,
    keywords: ['3d', 'icon', 'sprite', 'audio', 'sound', 'asset', 'texture', 'game'],
  },

  // === PRODUCT CAPABILITY SKILLS (19) ===
  {
    id: 'cap-otp-auth',
    name: 'Gmail / Phone OTP Auth',
    nameHi: 'Gmail / फ़ोन OTP लॉगिन',
    category: 'capability',
    description: 'Adds Phone OTP + Google sign-in screen and auth service stub.',
    enabled: true,
    keywords: ['otp', 'login', 'auth', 'signup', 'gmail', 'phone', 'account', 'लॉगिन'],
  },
  {
    id: 'cap-bottom-nav',
    name: 'Bottom Navigation',
    nameHi: 'बॉटम नेविगेशन',
    category: 'capability',
    description: 'Adds thumb-friendly 4-tab bottom navigation bar in preview & Flutter code.',
    enabled: true,
    keywords: ['app', 'tabs', 'navigation', 'home', 'dashboard', 'store', 'booking', 'wallet', 'ऐप'],
  },
  {
    id: 'cap-profile',
    name: 'User Profile',
    nameHi: 'यूज़र प्रोफ़ाइल',
    category: 'capability',
    description: 'Adds profile details, KYC/account status, and settings screen.',
    enabled: true,
    keywords: ['profile', 'account', 'user', 'member', 'kyc', 'driver', 'customer'],
  },
  {
    id: 'cap-search',
    name: 'Search & Filter',
    nameHi: 'सर्च और फ़िल्टर',
    category: 'capability',
    description: 'Adds instant search bar and category filters to Display A & generated screens.',
    enabled: true,
    keywords: ['search', 'filter', 'catalog', 'shop', 'directory', 'find', 'listing', 'menu', 'store'],
  },
  {
    id: 'cap-lists-forms',
    name: 'Lists & Forms',
    nameHi: 'लिस्ट और फ़ॉर्म',
    category: 'capability',
    description: 'Adds structured data lists and interactive input/booking forms.',
    enabled: true,
    keywords: ['form', 'list', 'order', 'booking', 'register', 'entry', 'expense', 'ledger', 'crm', 'task'],
  },
  {
    id: 'cap-wallet',
    name: 'Wallet / Balance',
    nameHi: 'वॉलेट / बैलेंस',
    category: 'capability',
    description: 'Adds balance card, top-up simulation, and transaction ledger module.',
    enabled: true,
    keywords: ['wallet', 'balance', 'upi', 'pay', 'payment', 'coins', 'credit', 'withdraw', 'वॉलेट'],
  },
  {
    id: 'cap-vip-unlock',
    name: 'VIP-Plan Unlock',
    nameHi: 'VIP प्लान अनलॉक',
    category: 'capability',
    description: 'Adds VIP tier banner, unlock gate, and Admin-linked VIP plan note.',
    enabled: true,
    keywords: ['vip', 'pro', 'premium', 'subscription', 'plan', 'membership', 'unlock'],
  },
  {
    id: 'cap-maps-booking',
    name: 'Maps / Booking Style',
    nameHi: 'मैप्स / बुकिंग स्टाइल',
    category: 'capability',
    description: 'Adds pickup/drop route selector, ETA estimate, and live booking card.',
    enabled: true,
    keywords: ['map', 'ride', 'taxi', 'cab', 'delivery', 'booking', 'route', 'salon', 'hotel', 'बुकिंग', 'टैक्सी'],
  },
  {
    id: 'cap-3d-game-controls',
    name: '3D / Game Preview Controls',
    nameHi: '3D / गेम प्रीव्यू कंट्रोल्स',
    category: 'capability',
    description: 'Enables playable steering, throttle, brake, and HUD loop on Display A + Godot 4 scripts.',
    enabled: true,
    keywords: ['3d', 'game', 'race', 'racing', 'car', 'drift', 'bike', 'steer', 'gas', 'brake', 'arcade', 'shooter', 'गेम', 'रेसिंग'],
    engineHint: 'godot4',
  },
  {
    id: 'cap-card-table',
    name: 'Card-Table Logic',
    nameHi: 'कार्ड-टेबल लॉजिक',
    category: 'capability',
    description: 'Adds felt card-table layout, hand dealing, pot/turn state, and Godot/Flutter deck engine.',
    enabled: true,
    keywords: ['card', 'rummy', 'teen patti', 'poker', 'blackjack', 'table', 'deck', 'ludo', 'ताश'],
    engineHint: 'godot4',
  },
  {
    id: 'cap-i18n-hi-en',
    name: 'i18n Hindi-English Strings',
    nameHi: 'हिंदी-इंग्लिश भाषा सपोर्ट',
    category: 'capability',
    description: 'Generates bilingual Hindi/English string tables inside the exported project.',
    enabled: true,
    keywords: ['hindi', 'hinglish', 'bilingual', 'india', 'indian', 'language', 'i18n', 'हिंदी'],
  },
  {
    id: 'cap-ads-iap',
    name: 'Ads / IAP Hook',
    nameHi: 'ऐड्स / IAP हुक',
    category: 'capability',
    description: 'Adds AdMob banner/rewarded placeholder hook and Play Billing IAP stub.',
    enabled: true,
    keywords: ['ads', 'admob', 'iap', 'monetize', 'purchase', 'coins', 'store', 'vip', 'game'],
  },
  {
    id: 'cap-theme-variants',
    name: 'Theme Variants',
    nameHi: 'थीम वेरिएंट्स',
    category: 'capability',
    description: 'Exports dark/light theme tokens and accent palette switcher.',
    enabled: true,
    keywords: ['theme', 'dark', 'light', 'brand', 'custom', 'ui', 'style'],
  },
  {
    id: 'cap-store-listing',
    name: 'Store Listing Draft',
    nameHi: 'प्ले स्टोर लिस्टिंग ड्राफ्ट',
    category: 'capability',
    description: 'Generates PLAY_STORE_LISTING.md with title, short/full copy, and feature bullets.',
    enabled: true,
    keywords: ['store', 'publish', 'play store', 'release', 'launch', 'apk'],
  },
  {
    id: 'cap-accessibility',
    name: 'Accessibility Pass',
    nameHi: 'एक्सेसिबिलिटी पास',
    category: 'capability',
    description: 'Enforces 44px touch targets, semantic labels, and high-contrast tokens.',
    enabled: true,
    keywords: ['accessible', 'senior', 'a11y', 'contrast', 'large text'],
  },
  {
    id: 'cap-offline-cache',
    name: 'Offline Cache Hint',
    nameHi: 'ऑफ़लाइन कैश हिंट',
    category: 'capability',
    description: 'Adds local persistence/cache layer so the exported app works cleanly offline.',
    enabled: true,
    keywords: ['offline', 'cache', 'local', 'sync', 'village', 'low network'],
  },
  {
    id: 'cap-perf-budget',
    name: 'Performance Budget Hint',
    nameHi: 'परफ़ॉर्मेंस बजट हिंट',
    category: 'capability',
    description: 'Adds frame-time / APK size budget notes and tree-shake flags in workflow.',
    enabled: true,
    keywords: ['fast', 'lightweight', '60fps', 'fps', 'performance', 'lite', '3d', 'game'],
  },
  {
    id: 'cap-release-notes',
    name: 'Release Notes Auto',
    nameHi: 'ऑटो रिलीज़ नोट्स',
    category: 'capability',
    description: 'Generates CHANGELOG.md and GitHub Release notes automatically on OK.',
    enabled: true,
    keywords: ['release', 'version', 'changelog', 'apk'],
  },
  {
    id: 'cap-prompt-expand',
    name: 'Prompt Expand / Spec',
    nameHi: 'प्रॉम्प्ट एक्सपैंड / स्पेक',
    category: 'capability',
    description: 'Expands short prompts into structured ARCHITECTURE_SPEC.md before coding.',
    enabled: true,
    keywords: [],
  },
];

export function loadSkills(): StudioSkill[] {
  try {
    const raw = localStorage.getItem(SKILLS_STORAGE_KEY);
    if (!raw) return DEFAULT_SKILLS;
    const saved = JSON.parse(raw) as Array<{ id: string; enabled: boolean }>;
    const map = new Map(saved.map((s) => [s.id, s.enabled]));
    return DEFAULT_SKILLS.map((skill) => ({
      ...skill,
      enabled: map.has(skill.id) ? Boolean(map.get(skill.id)) : skill.enabled,
    }));
  } catch {
    return DEFAULT_SKILLS;
  }
}

export function saveSkills(skills: StudioSkill[]): void {
  try {
    const compact = skills.map((s) => ({ id: s.id, enabled: s.enabled }));
    localStorage.setItem(SKILLS_STORAGE_KEY, JSON.stringify(compact));
  } catch {
    // ignore storage quota failures
  }
}

export function isSkillEnabled(skills: StudioSkill[], id: string): boolean {
  const found = skills.find((s) => s.id === id);
  return found ? found.enabled : false;
}

export interface SkillMatchResult {
  matchedIds: string[];
  skippedBecauseOffIds: string[];
  recommendedEngine: EngineType;
  productType: ProductType;
  needsResearchBot: boolean;
}

/**
 * Engine strictly honors enabled toggles.
 * If a capability matches the prompt keywords BUT its skill toggle is OFF,
 * it is placed in `skippedBecauseOffIds` and MUST NOT be applied to preview or export!
 */
export function matchPromptToSkills(prompt: string, skills: StudioSkill[]): SkillMatchResult {
  const lower = prompt.toLowerCase();
  const promptMatchActive = isSkillEnabled(skills, 'prompt-skill-match');

  const gameSignals = [
    'game',
    '3d',
    'racing',
    'racer',
    'car',
    'drift',
    'bike',
    'arcade',
    'shooter',
    'godot',
    'steer',
    'card',
    'rummy',
    'poker',
    'teen patti',
    'ludo',
    'arena',
    'गेम',
    'रेसिंग',
    'कार',
    'ताश',
  ];
  const isGamePrompt = gameSignals.some((kw) => lower.includes(kw));

  const enginePickerOn = isSkillEnabled(skills, 'engine-picker');
  const godotPathOn = isSkillEnabled(skills, 'godot4-workflow-path');
  const flutterPathOn = isSkillEnabled(skills, 'flutter-workflow-path');

  let productType: ProductType = isGamePrompt ? 'game' : 'app';
  let recommendedEngine: EngineType = 'flutter';

  if (enginePickerOn) {
    if (isGamePrompt && godotPathOn) {
      recommendedEngine = 'godot4';
    } else if (!flutterPathOn && godotPathOn) {
      recommendedEngine = 'godot4';
    } else {
      recommendedEngine = 'flutter';
    }
  } else {
    // If engine-picker is OFF, default strictly to Flutter unless only Godot path is enabled
    recommendedEngine = !flutterPathOn && godotPathOn ? 'godot4' : 'flutter';
  }

  const matchedIds: string[] = [];
  const skippedBecauseOffIds: string[] = [];

  for (const skill of skills) {
    if (skill.category === 'pipeline') {
      if (skill.id === 'flutter-workflow-path' && recommendedEngine !== 'flutter') continue;
      if (skill.id === 'godot4-workflow-path' && recommendedEngine !== 'godot4') continue;

      if (skill.enabled) {
        matchedIds.push(skill.id);
      } else {
        skippedBecauseOffIds.push(skill.id);
      }
      continue;
    }

    // Capability skills
    let keywordHit = skill.keywords.some((kw) => lower.includes(kw));

    // Reasonable baseline capability matches when Prompt->Skill Match is ON
    if (promptMatchActive) {
      if (skill.id === 'cap-bottom-nav' && productType === 'app') keywordHit = true;
      if (skill.id === 'cap-3d-game-controls' && productType === 'game') keywordHit = true;
      if (skill.id === 'cap-prompt-expand') keywordHit = true;
      if (skill.id === 'cap-release-notes') keywordHit = true;
      if (skill.id === 'cap-lists-forms' && productType === 'app') keywordHit = true;
    }

    if (keywordHit) {
      if (skill.enabled && promptMatchActive) {
        matchedIds.push(skill.id);
      } else if (!skill.enabled) {
        skippedBecauseOffIds.push(skill.id);
      }
    }
  }

  const researchSkill = skills.find((s) => s.id === 'research-bot');
  const needsResearchBot =
    Boolean(researchSkill?.enabled) &&
    (researchSkill?.keywords.some((kw) => lower.includes(kw)) || lower.split(/\s+/).length >= 10);

  return {
    matchedIds,
    skippedBecauseOffIds,
    recommendedEngine,
    productType,
    needsResearchBot,
  };
}
