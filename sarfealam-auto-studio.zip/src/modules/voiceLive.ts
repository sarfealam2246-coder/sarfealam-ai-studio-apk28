import type { Language, StudioTab } from '../types/studio';

export type LiveCommandAction =
  | { type: 'BUILD'; prompt: string }
  | { type: 'CANCEL' }
  | { type: 'OK_EXPORT' }
  | { type: 'NAVIGATE'; tab: StudioTab }
  | { type: 'HOME' }
  | { type: 'SWITCH_LANG'; lang: Language }
  | { type: 'STATUS' }
  | { type: 'CHAT'; text: string };

/**
 * Parses English, Hindi, and Hinglish live voice commands into concrete studio UI actions.
 */
export function parseLiveCommand(rawText: string): LiveCommandAction {
  const text = rawText.trim();
  const lower = text.toLowerCase();

  // Language switching
  if (
    /\b(switch to hindi|hindi mode|hindi mein|हिंदी में|हिंदी चालू|hindi)\b/i.test(lower) &&
    !/\b(build|create|banao|app|game)\b/i.test(lower)
  ) {
    return { type: 'SWITCH_LANG', lang: 'hi' };
  }
  if (
    /\b(switch to english|english mode|english mein|इंग्लिश में|english)\b/i.test(lower) &&
    !/\b(build|create|banao|app|game)\b/i.test(lower)
  ) {
    return { type: 'SWITCH_LANG', lang: 'en' };
  }

  // Cancel / abort
  if (/^(cancel|stop|abort|reset|roko|band karo|कैंसिल|रोको|रद्द)/i.test(lower)) {
    return { type: 'CANCEL' };
  }

  // OK / Export
  if (
    /^(ok|okay|approve|export|continue|proceed|ship it|aage badho|एक्सपोर्ट|ओके)$/i.test(lower) ||
    /\b(press ok|tap ok|export apk|start export|ok export)\b/i.test(lower)
  ) {
    return { type: 'OK_EXPORT' };
  }

  // Home
  if (/^(home|go home|build home|होम)$/i.test(lower) || /\b(go to home|return home)\b/i.test(lower)) {
    return { type: 'HOME' };
  }

  // Tab navigation
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(vault|वॉल्ट)\b/i.test(lower) || lower === 'vault' || lower === 'वॉल्ट') {
    return { type: 'NAVIGATE', tab: 'vault' };
  }
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(admin|एडमिन)\b/i.test(lower) || lower === 'admin' || lower === 'एडमिन') {
    return { type: 'NAVIGATE', tab: 'admin' };
  }
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(skills|skill|स्किल्स)\b/i.test(lower) || lower === 'skills' || lower === 'स्किल्स') {
    return { type: 'NAVIGATE', tab: 'skills' };
  }
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(secrets|secret|keys|सीक्रेट्स)\b/i.test(lower) || lower === 'secrets' || lower === 'सीक्रेट्स') {
    return { type: 'NAVIGATE', tab: 'secrets' };
  }
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(build|factory|बिल्ड)\b/i.test(lower) || lower === 'build' || lower === 'बिल्ड') {
    return { type: 'NAVIGATE', tab: 'build' };
  }
  if (/\b(open|go to|show|kholo|खोलो)\s+(the\s+)?(co-?pilot|chat|को-?पायलट)\b/i.test(lower) || lower === 'copilot' || lower === 'co-pilot') {
    return { type: 'NAVIGATE', tab: 'copilot' };
  }

  // Status / health query
  if (
    /\b(status|check status|check secrets|what is missing|health|kya haal|स्टेटस|सीक्रेट्स चेक|missing)\b/i.test(lower)
  ) {
    return { type: 'STATUS' };
  }

  // Build command
  if (
    /^(start build|build|create|make|assemble|generate)\b/i.test(lower) ||
    /(बनाओ|बना दो|banao|bana do)/i.test(lower)
  ) {
    return { type: 'BUILD', prompt: text };
  }

  return { type: 'CHAT', text };
}

export function speakText(text: string, lang: Language): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 320));
    utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
    utterance.rate = 1.03;
    window.speechSynthesis.speak(utterance);
  } catch {
    // ignore speech synthesis restrictions
  }
}

export function stopSpeaking(): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
  } catch {
    // ignore
  }
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<{
    isFinal: boolean;
    0: { transcript: string };
  }>;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

export function isBrowserSpeechSupported(): boolean {
  if (typeof window === 'undefined') return false;
  const w = window as unknown as Record<string, unknown>;
  return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export class LiveVoiceController {
  private recognition: SpeechRecognitionLike | null = null;
  private active = false;
  private lang: Language = 'en';
  private onInterim: (text: string) => void;
  private onFinal: (text: string) => void;
  private onStatus: (status: string) => void;

  constructor(callbacks: {
    onInterim: (text: string) => void;
    onFinal: (text: string) => void;
    onStatus: (status: string) => void;
  }) {
    this.onInterim = callbacks.onInterim;
    this.onFinal = callbacks.onFinal;
    this.onStatus = callbacks.onStatus;
  }

  public setLanguage(lang: Language): void {
    this.lang = lang;
    if (this.active && this.recognition) {
      this.recognition.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
    }
  }

  public start(lang: Language): boolean {
    this.lang = lang;
    if (!isBrowserSpeechSupported()) {
      this.onStatus('Browser mic SpeechRecognition unavailable — use Live Voice Command input bar.');
      return false;
    }

    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return false;

    this.stop();
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = lang === 'hi' ? 'hi-IN' : 'en-US';

    rec.onresult = (event) => {
      let interim = '';
      let finalChunk = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalChunk += transcript;
        } else {
          interim += transcript;
        }
      }
      if (interim.trim()) {
        this.onInterim(interim.trim());
      }
      if (finalChunk.trim()) {
        this.onInterim('');
        this.onFinal(finalChunk.trim());
      }
    };

    rec.onerror = (ev) => {
      if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
        this.active = false;
        this.onStatus('Mic permission denied — type command in Live bar or allow microphone.');
      } else if (ev.error !== 'no-speech') {
        this.onStatus(`Mic notice: ${ev.error}`);
      }
    };

    rec.onend = () => {
      // Call-style continuous loop: auto-restart while Live is ON
      if (this.active) {
        try {
          rec.start();
        } catch {
          // ignore rapid restart lock
        }
      }
    };

    try {
      rec.start();
      this.recognition = rec;
      this.active = true;
      this.onStatus(lang === 'hi' ? 'माइक सुन रहा है...' : 'Listening live...');
      return true;
    } catch {
      this.onStatus('Could not start microphone.');
      return false;
    }
  }

  public stop(): void {
    this.active = false;
    if (this.recognition) {
      try {
        this.recognition.onend = null;
        this.recognition.stop();
      } catch {
        // ignore
      }
      this.recognition = null;
    }
    this.onInterim('');
  }
}
