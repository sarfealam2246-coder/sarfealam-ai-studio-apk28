import type { EngineType } from '../types/studio';

const WORKFLOW_STORAGE_KEY = 'sarfealam_studio_workflow_templates_v1';

export interface WorkflowTemplate {
  id: string;
  engine: EngineType;
  name: string;
  filePath: string;
  description: string;
  templateYaml: string;
  isCustomized: boolean;
  updatedAt: string;
}

export type WorkflowTemplateMap = Record<EngineType, WorkflowTemplate>;

export interface WorkflowRenderContext {
  appName: string;
  appSlug: string;
  flutterVersion?: string;
  javaVersion?: string;
  flutterBuildFlags?: string;
  godotImage?: string;
  godotExportPreset?: string;
  artifactName?: string;
  releasePrefix?: string;
}

export interface WorkflowValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export const WORKFLOW_PLACEHOLDERS: Array<{ token: string; description: string }> = [
  { token: '{{APP_NAME}}', description: 'Human-readable app or game title' },
  { token: '{{APP_SLUG}}', description: 'Sanitized lowercase slug for APK & artifact naming' },
  { token: '{{ARTIFACT_NAME}}', description: 'GitHub Actions uploaded artifact name' },
  { token: '{{FLUTTER_VERSION}}', description: 'Flutter SDK version (e.g. 3.24.3)' },
  { token: '{{JAVA_VERSION}}', description: 'Temurin JDK version for Gradle (e.g. 17)' },
  { token: '{{FLUTTER_BUILD_FLAGS}}', description: 'Extra flutter build flags (e.g. --tree-shake-icons)' },
  { token: '{{GODOT_IMAGE}}', description: 'Godot 4 CI container image (e.g. barichello/godot-ci:4.3)' },
  { token: '{{GODOT_EXPORT_PRESET}}', description: 'Godot export preset name (e.g. Android)' },
];

export const DEFAULT_FLUTTER_WORKFLOW_YAML = `name: Build Android Release APK (Flutter)

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Java {{JAVA_VERSION}}
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '{{JAVA_VERSION}}'

      - name: Setup Flutter {{FLUTTER_VERSION}}
        uses: subosito/flutter-action@v2
        with:
          flutter-version: '{{FLUTTER_VERSION}}'
          channel: 'stable'

      - name: Ensure Android platform scaffold
        run: |
          if [ ! -d "android" ]; then
            flutter create --platforms=android .
          fi

      - name: Install dependencies
        run: flutter pub get

      - name: Build Android Release APK
        run: flutter build apk --release{{FLUTTER_BUILD_FLAGS}}

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: {{ARTIFACT_NAME}}
          path: build/app/outputs/flutter-apk/app-release.apk

      - name: Publish GitHub Release with APK
        uses: softprops/action-gh-release@v2
        with:
          tag_name: {{RELEASE_PREFIX}}.\${{ github.run_number }}
          name: "{{APP_NAME}} APK #\${{ github.run_number }}"
          files: build/app/outputs/flutter-apk/app-release.apk
`;

export const DEFAULT_GODOT4_WORKFLOW_YAML = `name: Build Android APK (Godot 4)

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  export-android:
    runs-on: ubuntu-latest
    container:
      image: {{GODOT_IMAGE}}
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Prepare export directory
        run: mkdir -p build/android

      - name: Export Godot 4 Android APK
        run: godot --headless --verbose --export-debug "{{GODOT_EXPORT_PRESET}}" build/android/{{APP_SLUG}}.apk

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: {{ARTIFACT_NAME}}
          path: build/android/{{APP_SLUG}}.apk

      - name: Publish GitHub Release with APK
        uses: softprops/action-gh-release@v2
        with:
          tag_name: {{RELEASE_PREFIX}}.\${{ github.run_number }}
          name: "{{APP_NAME}} Godot 4 APK #\${{ github.run_number }}"
          files: build/android/{{APP_SLUG}}.apk
`;

export function createDefaultWorkflowTemplates(): WorkflowTemplateMap {
  const now = new Date().toISOString();
  return {
    flutter: {
      id: 'flutter-android-apk',
      engine: 'flutter',
      name: 'Flutter Android Release APK',
      filePath: '.github/workflows/flutter-apk.yml',
      description:
        'Sets up JDK + Flutter stable, scaffolds Android if absent, compiles release APK, uploads Actions artifact, and publishes a GitHub Release.',
      templateYaml: DEFAULT_FLUTTER_WORKFLOW_YAML,
      isCustomized: false,
      updatedAt: now,
    },
    godot4: {
      id: 'godot4-android-apk',
      engine: 'godot4',
      name: 'Godot 4 Android Export APK',
      filePath: '.github/workflows/godot-android-apk.yml',
      description:
        'Runs headless Godot 4.3 CI container export using export_presets.cfg, uploads the Android APK artifact, and attaches it to GitHub Releases.',
      templateYaml: DEFAULT_GODOT4_WORKFLOW_YAML,
      isCustomized: false,
      updatedAt: now,
    },
  };
}

export function validateWorkflowYaml(yaml: string): WorkflowValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const trimmed = yaml.trim();

  if (!trimmed) {
    return { valid: false, errors: ['Workflow YAML cannot be empty.'], warnings: [] };
  }
  if (!/^name\s*:/m.test(trimmed)) {
    errors.push('Missing top-level "name:" field.');
  }
  if (!/^on\s*:/m.test(trimmed)) {
    errors.push('Missing top-level "on:" trigger definition.');
  }
  if (!/^jobs\s*:/m.test(trimmed)) {
    errors.push('Missing top-level "jobs:" block.');
  }
  if (!/steps\s*:/m.test(trimmed)) {
    errors.push('Missing "steps:" sequence inside job.');
  }

  if (!/upload-artifact/i.test(trimmed) && !/action-gh-release/i.test(trimmed)) {
    warnings.push('No artifact upload or GitHub Release step detected — Vault APK polling may not find an .apk link.');
  }
  if (!/\.apk/i.test(trimmed)) {
    warnings.push('No .apk output path referenced in workflow.');
  }

  return { valid: errors.length === 0, errors, warnings };
}

export function loadWorkflowTemplates(): WorkflowTemplateMap {
  const defaults = createDefaultWorkflowTemplates();
  try {
    const raw = localStorage.getItem(WORKFLOW_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<WorkflowTemplateMap>;
    return {
      flutter: parsed.flutter
        ? {
            ...defaults.flutter,
            ...parsed.flutter,
            engine: 'flutter',
          }
        : defaults.flutter,
      godot4: parsed.godot4
        ? {
            ...defaults.godot4,
            ...parsed.godot4,
            engine: 'godot4',
          }
        : defaults.godot4,
    };
  } catch {
    return defaults;
  }
}

export function saveWorkflowTemplates(templates: WorkflowTemplateMap): WorkflowTemplateMap {
  try {
    localStorage.setItem(WORKFLOW_STORAGE_KEY, JSON.stringify(templates));
  } catch {
    // ignore storage quota failures
  }
  return templates;
}

export function updateWorkflowTemplate(
  current: WorkflowTemplateMap,
  engine: EngineType,
  patch: Partial<Pick<WorkflowTemplate, 'filePath' | 'templateYaml' | 'name'>>
): WorkflowTemplateMap {
  const existing = current[engine];
  const cleanPath = (patch.filePath ?? existing.filePath).trim().replace(/^\/+/, '');
  const normalizedPath = cleanPath.startsWith('.github/workflows/')
    ? cleanPath
    : `.github/workflows/${cleanPath.replace(/^.*\//, '') || (engine === 'godot4' ? 'godot-android-apk.yml' : 'flutter-apk.yml')}`;

  const next: WorkflowTemplateMap = {
    ...current,
    [engine]: {
      ...existing,
      ...patch,
      filePath: normalizedPath,
      isCustomized: true,
      updatedAt: new Date().toISOString(),
    },
  };
  return saveWorkflowTemplates(next);
}

export function resetWorkflowTemplate(
  current: WorkflowTemplateMap,
  engine: EngineType
): WorkflowTemplateMap {
  const defaults = createDefaultWorkflowTemplates();
  const next: WorkflowTemplateMap = {
    ...current,
    [engine]: defaults[engine],
  };
  return saveWorkflowTemplates(next);
}

function escapeYamlDoubleQuotes(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/"/g, "'");
}

/**
 * Renders the managed boilerplate workflow YAML for the target engine,
 * substituting build-specific tokens cleanly for direct injection into the export package.
 */
export function renderWorkflowForExport(
  engine: EngineType,
  ctx: WorkflowRenderContext,
  templates?: WorkflowTemplateMap
): {
  filePath: string;
  content: string;
  templateId: string;
  isCustomized: boolean;
  validation: WorkflowValidationResult;
} {
  const activeMap = templates ?? loadWorkflowTemplates();
  const tpl = activeMap[engine];

  const safeAppName = escapeYamlDoubleQuotes(ctx.appName || 'Sarfealam App');
  const safeSlug = (ctx.appSlug || 'sarfealam_app').replace(/[^a-z0-9_-]/gi, '_');
  const defaultArtifact = engine === 'godot4' ? `${safeSlug}-godot4-apk` : `${safeSlug}-android-apk`;

  const replacements: Record<string, string> = {
    '{{APP_NAME}}': safeAppName,
    '{{APP_SLUG}}': safeSlug,
    '{{ARTIFACT_NAME}}': ctx.artifactName || defaultArtifact,
    '{{FLUTTER_VERSION}}': ctx.flutterVersion || '3.24.3',
    '{{JAVA_VERSION}}': ctx.javaVersion || '17',
    '{{FLUTTER_BUILD_FLAGS}}': ctx.flutterBuildFlags ? ` ${ctx.flutterBuildFlags.trim()}` : '',
    '{{GODOT_IMAGE}}': ctx.godotImage || 'barichello/godot-ci:4.3',
    '{{GODOT_EXPORT_PRESET}}': ctx.godotExportPreset || 'Android',
    '{{RELEASE_PREFIX}}': ctx.releasePrefix || 'v1.0',
  };

  let rendered = tpl.templateYaml;
  for (const [token, value] of Object.entries(replacements)) {
    rendered = rendered.split(token).join(value);
  }

  return {
    filePath: tpl.filePath,
    content: rendered,
    templateId: tpl.id,
    isCustomized: tpl.isCustomized,
    validation: validateWorkflowYaml(rendered),
  };
}
