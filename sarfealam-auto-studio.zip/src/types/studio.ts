export type Language = 'en' | 'hi';

export type StudioTab = 'copilot' | 'build' | 'vault' | 'admin' | 'skills' | 'secrets';

export type AIProviderId =
  | 'gemini'
  | 'groq'
  | 'nvidia'
  | 'qwen'
  | 'openai'
  | 'openrouter'
  | 'deepseek'
  | 'mistral'
  | 'custom';

export type KeyTag =
  | 'General'
  | 'Code'
  | 'Fast'
  | 'Vision'
  | 'Primary'
  | 'Fallback'
  | 'Reason';

export type DepartmentId =
  | 'brain'
  | 'code'
  | 'fast'
  | 'vision'
  | 'reason'
  | 'listen'
  | 'speak';

export interface ApiKeySlot {
  id: string;
  slotIndex: number;
  name: string;
  provider: AIProviderId;
  model: string;
  baseUrl: string;
  apiKey: string;
  tags: KeyTag[];
  enabled: boolean;
  lastTestedAt?: string;
  lastTestStatus?: 'untested' | 'valid' | 'error';
  lastTestMessage?: string;
}

export interface GitHubTokenConfig {
  token: string;
  username?: string;
  name?: string;
  scopes?: string;
  validatedAt?: string;
  status: 'unconfigured' | 'valid' | 'invalid';
  lastError?: string;
}

export interface ReserveTokenConfig {
  label: string;
  token: string;
}

export interface VoiceKeyConfig {
  provider: 'browser-web-speech' | 'openai-whisper' | 'elevenlabs' | 'deepgram' | 'custom';
  apiKey: string;
  model: string;
}

export interface StudioFirebaseConfig {
  databaseUrl: string;
  projectId: string;
  apiKey: string;
  status: 'unconfigured' | 'connected' | 'error';
  lastSyncedAt?: string;
  lastError?: string;
}

export interface AppsFirebaseConfig {
  projectId: string;
  apiKey: string;
  appId: string;
  databaseUrl: string;
  storageBucket: string;
  messagingSenderId: string;
  configured: boolean;
}

export interface StudioSecrets {
  apiKeys: ApiKeySlot[];
  githubToken: GitHubTokenConfig;
  reserveToken: ReserveTokenConfig;
  voiceKey: VoiceKeyConfig;
  studioFirebase: StudioFirebaseConfig;
  appsFirebase: AppsFirebaseConfig;
}

export type SkillCategory = 'pipeline' | 'capability';

export interface StudioSkill {
  id: string;
  name: string;
  nameHi: string;
  category: SkillCategory;
  description: string;
  enabled: boolean;
  keywords: string[];
  engineHint?: 'flutter' | 'godot4';
}

export type EngineType = 'flutter' | 'godot4';
export type ProductType = 'app' | 'game';

export type BuildStatus =
  | 'idle'
  | 'assembling'
  | 'testing'
  | 'ok'
  | 'exporting'
  | 'ready'
  | 'error'
  | 'cancelled';

export interface StageRecord {
  index: 1 | 2 | 3 | 4 | 5;
  key: 'shell' | 'screens' | 'hero' | 'controls' | 'ready';
  label: string;
  labelHi: string;
  status: 'pending' | 'active' | 'done' | 'error';
  workerName?: string;
  summary?: string;
  completedAt?: string;
}

export interface PreviewBlueprint {
  appName: string;
  tagline: string;
  productType: ProductType;
  engine: EngineType;
  accentHex: string;
  tabs: string[];
  heroTitle: string;
  heroSubtitle: string;
  primaryMetricLabel: string;
  primaryMetricValue: string;
  secondaryMetricLabel: string;
  secondaryMetricValue: string;
  items: Array<{ title: string; subtitle: string; meta: string }>;
  gameGenre?: 'racing' | 'arcade' | 'card-table' | 'arena';
  gameGoal?: string;
  featuresActive: string[];
  aiGeneratedNote?: string;
  isDemoSimulation: boolean;
}

export interface ExportArtifacts {
  repoOwner?: string;
  repoName?: string;
  repoUrl?: string;
  actionsUrl?: string;
  apkUrl?: string;
  apkStatus: 'not-started' | 'blocked' | 'queued' | 'building' | 'ready' | 'local-zip-only' | 'error';
  apkSource?: 'github-release' | 'github-artifact' | 'local-package';
  adminFinalUrl?: string;
  commitSha?: string;
  workflowPath?: string;
  appsFirebaseInjected: boolean;
  files: Record<string, string>;
  lastPolledAt?: string;
  errorReason?: string;
}

export interface AdminBuildControls {
  bannerEnabled: boolean;
  bannerText: string;
  vipNote: string;
  vipPriceLabel: string;
  notifications: Array<{ id: string; title: string; body: string; sentAt: string }>;
}

export interface SharedContextEntry {
  stage: number;
  worker: string;
  department: string;
  note: string;
  timestamp: string;
  criticRepair?: boolean;
}

export interface BuildJob {
  id: string;
  title: string;
  prompt: string;
  productType: ProductType;
  engine: EngineType;
  status: BuildStatus;
  stageIndex: number; // 0 = not started, 1..5
  stages: StageRecord[];
  matchedSkills: string[];
  skippedSkills: string[];
  activeChipId: string | null;
  activeWorkCaption: string;
  usedProviders: string[];
  fallbackEvents: string[];
  criticAttempts: number;
  criticNote?: string;
  researchSummary?: string;
  blueprint: PreviewBlueprint;
  exportArtifacts: ExportArtifacts;
  adminControls: AdminBuildControls;
  sharedContext: SharedContextEntry[];
  createdAt: string;
  updatedAt: string;
  isDemoMode: boolean;
  errorMessage?: string;
  revisionCount: number;
}

export type MapChipStatus = 'ready' | 'active' | 'done' | 'muted' | 'warning' | 'error';

export interface SystemMapChip {
  id: string;
  label: string;
  role: string;
  department: string;
  provider?: string;
  model?: string;
  status: MapChipStatus;
  caption: string;
  reason?: string;
  keySlotId?: string;
  column: 0 | 1 | 2 | 3; // 0: Prompt, 1: AI Team Agents, 2: Bots / Critic, 3: GitHub & Firebases
  isDynamicKeyChip?: boolean;
}

export interface SystemMapEdge {
  from: string;
  to: string;
  active: boolean;
  label?: string;
}

export interface SystemMapState {
  chips: SystemMapChip[];
  edges: SystemMapEdge[];
  footerText: string;
  footerState: 'sync' | 'blocked' | 'demo' | 'idle' | 'error';
}

export interface CoPilotMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  viaLive?: boolean;
  sourceLabel?: string; // e.g., "Gemini Primary · gemini-4-hydrogen" or "Local Connect Bot · No AI Key"
  actionTaken?: string;
}

export interface SecretsHealth {
  activeKeyCount: number;
  hasAnyAiKey: boolean;
  githubConnected: boolean;
  studioFirebaseConnected: boolean;
  appsFirebaseConfigured: boolean;
  voiceConfigured: boolean;
  issues: Array<{ id: string; severity: 'error' | 'warning'; message: string; messageHi: string; targetSection: string }>;
}
